# MockMaxxing Brand Guidelines & Strategy
*Version 1.0 (May 2026)*

> [!IMPORTANT]
> **Unified Mandate for the Executive & Marketing Teams**:
> The MockMaxxing Brand Guidelines represent our corporate identity and design system. They must be treated as a **first principle** in all product development, marketing initiatives, presentations, and designs. Every page, slide, or banner we produce must align flawlessly with this design framework.

---

## 1. Corporate Identity & Vision

**MockMaxxing** is the premier high-fidelity analytics suite for fantasy sports drafting. By utilizing custom genetic algorithms, bot-draft simulations, and real-time value-tracking telemetry, we empower drafters to "max out" their roster efficiency. Our brand represents **analytical precision, elite competitiveness, and high-fidelity tech elegance**.

---

## 2. The Unified Triple-Core Design & QA Framework

To maintain elite engineering and aesthetic standard, every MockMaxxing application must strictly implement our **Triple-Core Framework**:

### Core Pillar 1: Apple Human Interface Guidelines (HIG)
- **Fluid Motion**: All active user states must use spring-based physics for transitions. Avoid abrupt layout snaps.
- **Visual Depth**: Use light overlays, subtle flat borders (`1px` solid slate), and native visual hierarchies to establish clear contextual focus.
- **Haptic Feedback**: Utilize standard light impact triggers for primary layout switches and success feedback states.

### Core Pillar 2: Google Material Design 3 (M3)
- **Rigid Containment**: Layout elements (tab controls, cards, dashboards) must have clear physical boundaries.
- **Interaction States**: All clickable elements must display clear visual states:
  - *Default*: Soft border, flat elevation.
  - *Hovered*: Slightly darker outline, micro-scale transition (`scale(1.02)`).
  - *Pressed*: Soft inward shadow, micro-scale compression (`scale(0.98)`).
  - *Disabled*: `30%` opacity, non-reactive.

### Core Pillar 3: WCAG 2.2 AAA Accessibility Standards
- **Mathematical Legibility**: All critical typography must guarantee a minimum **7:1 contrast ratio** against background surfaces:
  - *Dark Slate Blue-on-White*: Dark Slate Blue (`#2D3142`) on White (`#FFFFFF`) cards offers an elite **12.77:1 contrast ratio** (exceeds AAA compliant standards).
  - *Black-on-White*: Slate Black (`#0C0C0C` / `#2D3142` in light mode text) on White (`#FFFFFF`) offers a **15:1+ contrast ratio**.
  - *Coral Badge Overlays*: Vibrant Coral (`#EF8354`) is highly energetic but cannot support white or light text overlays (2.62:1). **All text on coral backgrounds must be solid black (`#000000`)**, ensuring a compliant **8.0:1 contrast ratio** (exceeds the 7:1 AAA standard).
- **Opaque Backdrop Mandate**: Sticky sub-tab bars, headers, and modal overlays must utilize **100% solid, fully opaque backgrounds** to completely prevent dynamic scrolling text from bleeding underneath and causing contrast failures.

---

## 3. Brand Design System Tokens

Our colors are selected for extreme visual harmony and accessibility compliance:

| Color Token | Hex Code | Role in Design | Contrast (on White) | Contrast (on Dark Slate Blue) |
| :--- | :--- | :--- | :--- | :--- |
| **Dark Slate Blue** | `#2D3142` | Primary Brand Color, Signature Headers, Sidebar background, primary Light Mode text | 12.77:1 (AAA) | - |
| **Muted Blue-Grey** | `#4F5D75` | Secondary accent, active indicators, and Dark Mode borders | 4.8:1 (AA) | 2.6:1 (Low - graphics only) |
| **Cool Silver** | `#BFC0C0` | Sleek Light Mode borders, Dark Mode secondary text labels | 1.6:1 (border only) | 8.0:1 (AAA) |
| **Vibrant Coral** | `#EF8354` | Energetic Highlight Accent, setup wizard capsules, badges, buttons, active icons | 2.62:1 (background only) | 4.88:1 (AA - large text / icons) |
| **Solid Black** | `#000000` | Mandatory text overlay on Coral, positional details, active tabs | 21:1 (AAA) | 1.6:1 (Low - not used) |
| **Pure White** | `#FFFFFF` | High-contrast text on Dark Slate Blue, card background surfaces | - | 12.77:1 (AAA) |
| **Soft Background** | `#F8FAFC` | Premium light off-white background surface | - | - |
| **Card Surface** | `#FFFFFF` | Solid white raised card blocks and dashboard containers | - | - |
| **Elevated Surface** | `#F1F2F4` | Slightly darker raised containers and search bars (blended silver/grey) | - | - |

---

## 4. Typography Hierarchy

MockMaxxing uses a curated font-family pairing to establish clean structural pacing:

1. **Primary Headings: Oswald**
   - *Role*: Signature action titles, scorecard grades, section headings, and primary CTA buttons.
   - *Aesthetics*: Bold, condensed, aggressive, and highly legible.
2. **Body & Interface: Inter**
   - *Role*: Main roster names, coach feedback descriptions, details, and forms.
   - *Aesthetics*: Modern, highly structured, balanced geometric spacing.
3. **Telemetry & Numeric Stats: JetBrains Mono**
   - *Role*: Draft pick numbers, projected records, playoff percentages, rankings, and mathematical calculations.
   - *Aesthetics*: Highly legible monospaced letters that align numbers into clean, tabular grids.

---

## 5. UI Implementation Layout Examples (CSS Spec)

For developers building components, the following CSS rules must be declared:

### Core Page Structure
```css
body {
  background-color: #F8FAFC;
  color: #0F172A;
  font-family: 'Inter', sans-serif;
}
```

### Signature Dark Slate Blue Sidebar (Desktop Viewports)
```css
.sidebar {
  background-color: #2D3142;
  color: #FFFFFF;
  border-right: 1px solid rgba(255, 255, 255, 0.1);
}
.sidebar .active-item {
  border-left: 4px solid #EF8354;
  background-color: rgba(255, 255, 255, 0.08);
}
```

### Premium White Dashboard Card
```css
.dashboard-card {
  background-color: #FFFFFF;
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.04);
}
```

### Vibrant Coral Highlight Badge (WCAG AAA Legible)
```css
.coral-badge {
  background-color: #EF8354;
  color: #000000; /* Mandatory black overlay text */
  font-weight: 800;
  font-family: 'JetBrains Mono', monospace;
  border-radius: 6px;
  padding: 4px 8px;
}
```

### Signature Primary Button (Vibrant Coral CTA)
```css
.btn-primary {
  background-color: #EF8354;
  color: #000000; /* Mandatory black overlay text for maximum contrast (8.0:1) */
  font-family: 'Oswald', sans-serif;
  text-transform: uppercase;
  border: 1.5px solid #EF8354;
  border-radius: 8px;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}
.btn-primary:active {
  transform: scale(0.98);
  opacity: 0.9;
}
```
