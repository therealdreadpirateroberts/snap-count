import React, { useState, useRef } from 'react';
import { StyleSheet, View, Text, Pressable, Platform, Animated, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, usePathname } from 'expo-router';
import Svg, { Path, G } from 'react-native-svg';
import { Colors, Fonts, Spacing, useColors } from '@/constants/theme';
import { useThemeStore } from '@/store/useThemeStore';
import { useAuthStore } from '@/store/useAuthStore';
import * as Haptics from 'expo-haptics';

interface AppHeaderProps {
  title?: string;
  subtitle?: string;
  showBack?: boolean;
  backAction?: () => void;
  backText?: string;
  rightElement?: React.ReactNode;
  centerElement?: React.ReactNode;
  isLanding?: boolean;
}

export default function AppHeader({
  title,
  subtitle,
  showBack = false,
  backAction,
  backText = 'BACK',
  rightElement,
  centerElement,
  isLanding = false,
}: AppHeaderProps) {
  const Colors = useColors();
  const router = useRouter();
  const pathname = usePathname();
  const { user } = useAuthStore();
  
  const shouldShowBack = showBack && !isLanding;

  const triggerHaptic = async () => {
    if (Platform.OS !== 'web') {
      try {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      } catch (err) {}
    }
  };

  const handleBack = async () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    }
    if (backAction) {
      backAction();
    } else {
      router.back();
    }
  };

  const renderFootballIcon = (size: number) => {
    return (
      <Svg width={size} height={size} viewBox="-3 -3 30 30" fill="none" style={{ overflow: 'visible' }}>
        <G rotation={-30} originX={12} originY={12}>
          <Path
            d="M 2 12 C 6 5, 18 5, 22 12 C 18 19, 6 19, 2 12 Z"
            stroke={Colors.hofYellow}
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <Path d="M 7 12 H 17" stroke={Colors.hofYellow} strokeWidth={1.5} strokeLinecap="round" />
          <Path d="M 9.5 9.5 V 14.5" stroke={Colors.hofYellow} strokeWidth={1.2} strokeLinecap="round" />
          <Path d="M 12 9.5 V 14.5" stroke={Colors.hofYellow} strokeWidth={1.2} strokeLinecap="round" />
          <Path d="M 14.5 9.5 V 14.5" stroke={Colors.hofYellow} strokeWidth={1.2} strokeLinecap="round" />
        </G>
      </Svg>
    );
  };

  const getAccountLabel = () => {
    if (!user) return 'LOGIN';
    return user.firstName ? user.firstName.toUpperCase() : 'B';
  };

  return (
    <View style={styles.headerWrapper}>
      {/* 1. TOP BRANDING BANNER (Same on all pages) */}
      <View style={styles.brandBanner}>
        {/* Left container (Empty placeholder for visual symmetry / perfect title centering) */}
        <View style={styles.brandLeftContainer} />

        {/* Center branding */}
        <View style={styles.brandCenter}>
          {renderFootballIcon(38)}
          <View style={styles.brandTitleContainer}>
            <Text style={styles.brandTitle}>
              MOCK
              <Text style={styles.cursiveGoldText}>Maxxing</Text>
            </Text>
          </View>
        </View>

        {/* Right symmetric container (Empty placeholder for visual symmetry) */}
        <View style={styles.brandRightContainer} />
      </View>

      {/* 2. PERSISTENT NAV & COMPACT QUICK ACTIONS STRIP (Back, Title, Inbox & Account) */}
      <View style={styles.quickActionsStrip}>
        {/* Left Section: Back Button (Only on non-landing pages) */}
        <View style={styles.quickActionLeftSection}>
          {!isLanding && shouldShowBack ? (
            <Pressable
              style={({ pressed }) => [
                styles.quickBackBtn,
                pressed && styles.btnPressed
              ]}
              onPress={handleBack}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              accessibilityLabel="Go back"
            >
              <Svg width={16} height={16} viewBox="0 0 24 24" fill="none">
                <Path
                  d="M15 19L8 12L15 5"
                  stroke={Colors.secondaryAccent}
                  strokeWidth={2.5}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </Svg>
              {backText ? <Text style={styles.quickBackBtnText}>{backText}</Text> : null}
            </Pressable>
          ) : null}
        </View>

        {/* Center Section is completely removed per Universal Header Strip Mandate (Back, Inbox, and Account ONLY) */}

        {/* Right Section: Inbox & Account Actions */}
        <View style={styles.quickActionRightSection}>
          {/* Inbox Quick Action */}
          <Pressable
            style={({ pressed }) => [
              styles.quickActionItem,
              pressed && { opacity: 0.8 }
            ]}
            onPress={() => {
              triggerHaptic();
              if (pathname === '/settings') {
                router.setParams({ tab: 'inbox' });
              } else {
                router.push('/settings?tab=inbox');
              }
            }}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            accessibilityLabel="Inbox Messages"
          >
            <View style={styles.quickActionIconWrapper}>
              <Svg width={12} height={12} viewBox="0 0 24 24" fill="none">
                <Path d="M22 6C22 4.9 21.1 4 20 4H4C2.9 4 2 4.9 2 6M22 6V18C22 19.1 21.1 20 20 20H4C2.9 20 2 19.1 2 18V6M22 6L12 13L2 6" stroke={Colors.secondaryAccent} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
              </Svg>
              <View style={styles.inboxIndicatorDot} />
            </View>
            <Text style={styles.quickActionLabel}>INBOX</Text>
          </Pressable>

          {/* Vertical Divider */}
          <View style={styles.quickActionsDivider} />

          {/* Account Quick Action */}
          <Pressable
            style={({ pressed }) => [
              styles.quickActionItem,
              pressed && { opacity: 0.8 }
            ]}
            onPress={() => {
              triggerHaptic();
              if (pathname === '/settings') {
                router.setParams({ tab: 'settings' });
              } else {
                router.push('/settings?tab=settings');
              }
            }}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            accessibilityLabel="Account Settings"
          >
            <View style={styles.quickActionIconWrapper}>
              <Svg width={12} height={12} viewBox="0 0 24 24" fill="none">
                <Path d="M20 21V19C20 17.94 19.58 16.92 18.83 16.17C18.08 15.42 17.06 15 16 15H8C6.94 15 5.92 15.42 5.17 16.17C4.42 16.92 4 17.94 4 19V21" stroke={Colors.secondaryAccent} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
                <Path d="M12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z" stroke={Colors.secondaryAccent} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
              </Svg>
            </View>
            <Text style={styles.quickActionLabel}>{getAccountLabel()}</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

function createStyles(Colors: typeof import('@/constants/theme').LightColors) {
  return StyleSheet.create({
    headerWrapper: {
      width: '100%',
    },
    brandBanner: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingBottom: Spacing.three,
      paddingTop: Spacing.three,
      backgroundColor: '#2c2c2c', // Hardcoded stable brand navy/graphite backdrop
      borderBottomWidth: 1,
      borderBottomColor: 'rgba(255, 255, 255, 0.1)',
      width: '100%',
      paddingHorizontal: Spacing.three,
    },
    brandLeftContainer: {
      width: 44,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'flex-start',
    },
    brandRightContainer: {
      width: 44,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'flex-end',
    },
    themeToggleBtn: {
      width: 44,
      height: 44,
      borderRadius: 22,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: 'rgba(255, 255, 255, 0.05)',
      borderWidth: 1,
      borderColor: 'rgba(255, 255, 255, 0.15)',
    },
    themeTogglePressed: {
      backgroundColor: 'rgba(255, 255, 255, 0.12)',
    },
    brandCenter: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      flex: 1,
    },
    brandTitleContainer: {
      justifyContent: 'center',
    },
    brandTitle: {
      fontFamily: 'Inter-Bold',
      fontSize: 32,
      fontWeight: 'bold',
      color: '#ffffff', // High contrast white on Colts Navy (12.6:1 contrast)
      letterSpacing: -1,
    },
    cursiveGoldText: {
      color: Colors.hofYellow, // High contrast yellow on Colts Navy (6.1:1 contrast)
      fontFamily: Platform.select({
        web: "'Caveat', 'Dancing Script', 'Brush Script MT', cursive",
        default: 'System',
      }),
      fontSize: 38,
      fontWeight: 'bold',
      letterSpacing: 0,
      textTransform: 'none',
    },

    quickActionLeftSection: {
      flex: 1,
      flexDirection: 'row',
      justifyContent: 'flex-start',
      alignItems: 'center',
    },
    quickActionRightSection: {
      flex: 1,
      flexDirection: 'row',
      justifyContent: 'flex-end',
      alignItems: 'center',
    },
    quickBackBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 4,
      height: 36,
      justifyContent: 'center',
    },
    quickBackBtnText: {
      fontFamily: Fonts.stats,
      fontSize: 10,
      fontWeight: '600',
      color: Colors.secondaryAccent,
      letterSpacing: 0.5,
    },
    quickTitleWrapper: {
      alignItems: 'center',
      justifyContent: 'center',
    },
    quickHeaderTitle: {
      fontFamily: Fonts.headings,
      fontSize: 12,
      fontWeight: 'bold',
      color: Colors.primaryAccent,
      letterSpacing: 0.5,
      textAlign: 'center',
    },
    quickHeaderSubtitle: {
      fontFamily: Fonts.stats,
      fontSize: 8,
      color: Colors.secondaryAccent,
      letterSpacing: 1,
      textAlign: 'center',
      marginTop: 1,
    },
    btnPressed: {
      opacity: 0.6,
    },

    // Account Popover & Persistent Avatar Styles
    accountMenuContainer: {
      width: 44,
      height: 44,
      justifyContent: 'center',
      alignItems: 'center',
    },
    avatarTouchArea: {
      width: 44, // 44pt HIG Target Minimum
      height: 44,
      borderRadius: 22,
      borderWidth: 2,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: 'rgba(255, 255, 255, 0.05)',
    },
    avatarEmoji: {
      fontSize: 20,
      lineHeight: Platform.OS === 'ios' ? 24 : 26,
      textAlign: 'center',
    },
    avatarLetter: {
      fontFamily: Fonts.headings || 'Inter-Bold',
      fontSize: 15,
      fontWeight: 'bold',
      color: '#ffffff',
      textAlign: 'center',
    },
    popoverBackdrop: {
      ...StyleSheet.absoluteFillObject,
      backgroundColor: 'rgba(9, 9, 11, 0.4)',
    },
    popoverSafeArea: {
      flex: 1,
      alignItems: 'flex-end',
    },
    popoverCard: {
      position: 'absolute',
      top: Platform.OS === 'ios' ? 56 : 60,
      right: 16,
      width: 270,
      backgroundColor: Colors.surface,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: Colors.glassBorder,
      shadowColor: Colors.shadows.shadowColor,
      shadowOffset: Colors.shadows.shadowOffset,
      shadowOpacity: Colors.shadows.shadowOpacity,
      shadowRadius: Colors.shadows.shadowRadius,
      elevation: Colors.shadows.elevation,
      padding: 14,
      gap: 12,
    },
    popoverArrow: {
      position: 'absolute',
      top: -6,
      right: 16,
      width: 12,
      height: 12,
      backgroundColor: Colors.surface,
      borderLeftWidth: 1,
      borderTopWidth: 1,
      borderColor: Colors.glassBorder,
      transform: [{ rotate: '45deg' }],
    },
    tierBanner: {
      padding: 10,
      borderRadius: 8,
      borderWidth: 1,
      gap: 4,
    },
    tierBannerPro: {
      backgroundColor: 'rgba(255, 224, 102, 0.04)',
      borderColor: Colors.glassBorderGold,
    },
    tierBannerFree: {
      backgroundColor: 'rgba(148, 163, 184, 0.04)',
      borderColor: 'rgba(148, 163, 184, 0.12)',
    },
    tierBannerHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
    },
    tierEmoji: {
      fontSize: 14,
    },
    tierTitle: {
      fontFamily: Fonts.headings,
      fontSize: 11,
      fontWeight: 'bold',
      letterSpacing: 0.5,
    },
    tierSubtext: {
      fontFamily: Fonts.stats,
      fontSize: 8,
      color: Colors.secondaryAccent,
      letterSpacing: 0.2,
    },
    popoverProfileInfo: {
      paddingHorizontal: 4,
      gap: 2,
    },
    popoverProfileLabel: {
      fontFamily: Fonts.stats,
      fontSize: 7,
      color: Colors.secondaryAccent,
      letterSpacing: 1,
      fontWeight: 'bold',
    },
    popoverProfileName: {
      fontFamily: Fonts.headings,
      fontSize: 14,
      fontWeight: 'bold',
      color: Colors.primaryAccent,
    },
    popoverProfileSub: {
      fontFamily: Fonts.stats,
      fontSize: 9,
      color: Colors.secondaryAccent,
      marginTop: 1,
    },
    dividerLight: {
      height: 1,
      backgroundColor: Colors.coltsNavyLight,
      marginHorizontal: -14,
    },
    popoverOptions: {
      gap: 4,
    },
    popoverItem: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingVertical: 10,
      paddingHorizontal: 8,
      borderRadius: 6,
      minHeight: 44, // Apple's minimum vertical touch height
    },
    popoverItemPressed: {
      backgroundColor: 'rgba(0, 0, 0, 0.04)',
    },
    popoverItemLeft: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
    },
    popoverItemText: {
      fontFamily: Fonts.headings,
      fontSize: 12,
      fontWeight: '600',
      color: Colors.primaryAccent,
    },
    popoverLogoutBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      paddingVertical: 10,
      borderRadius: 8,
      backgroundColor: 'rgba(239, 68, 68, 0.05)',
      borderWidth: 1,
      borderColor: 'rgba(239, 68, 68, 0.15)',
      marginTop: 2,
      minHeight: 44, // HIG touch compliant
    },
    popoverLogoutBtnPressed: {
      backgroundColor: 'rgba(239, 68, 68, 0.12)',
    },
    popoverLogoutText: {
      fontFamily: Fonts.stats,
      fontSize: 10,
      fontWeight: 'bold',
      color: '#ef4444',
      letterSpacing: 0.5,
    },

    // Compact persistent quick actions strip styles (50% size / Starbucks inspired)
    quickActionsStrip: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: Colors.surface, // Solid background striped from left to right
      paddingVertical: 6,
      paddingHorizontal: 16,
      width: '100%',
      height: 44, // Enforced exact height across all pages for pixel parity
    },
    quickActionItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 8,
      height: 36,
      gap: 6,
    },
    quickActionIconWrapper: {
      width: 24,
      height: 24,
      borderRadius: 12,
      backgroundColor: Colors.surfaceLifted,
      borderWidth: 1,
      borderColor: Colors.coltsNavyLight,
      justifyContent: 'center',
      alignItems: 'center',
      position: 'relative',
    },
    quickActionLabel: {
      fontFamily: Fonts.headings,
      fontSize: 11,
      fontWeight: '600',
      color: Colors.secondaryAccent,
      letterSpacing: 0.5,
    },
    quickActionsStripDivider: {
      width: 1,
      height: 16,
      backgroundColor: Colors.coltsNavyLight,
    },
    quickActionsDivider: {
      width: 1,
      height: 16,
      backgroundColor: Colors.coltsNavyLight,
      marginHorizontal: 4,
    },
    inboxIndicatorDot: {
      position: 'absolute',
      top: 1,
      right: 1,
      width: 6,
      height: 6,
      borderRadius: 3,
      backgroundColor: '#ef4444',
      borderWidth: 1,
      borderColor: Colors.surfaceLifted,
    },
  });
}

// Precompile lightStyles and darkStyles at module evaluation time
const lightStyles = createStyles(require('@/constants/theme').LightColors);
const darkStyles = createStyles(require('@/constants/theme').DarkColors);

// Create the dynamic Proxy styles dispatcher
const styles = new Proxy({}, {
  get(target, prop) {
    const theme = useThemeStore.getState().theme;
    return theme === 'dark' ? darkStyles[prop as keyof typeof darkStyles] : lightStyles[prop as keyof typeof lightStyles];
  }
}) as ReturnType<typeof createStyles>;

