import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useColors } from '@/constants/theme';

export default function BackgroundTexture() {
  const Colors = useColors();
  return (
    <View style={[StyleSheet.absoluteFill, styles.container, { backgroundColor: Colors.background }]} />
  );
}

const styles = StyleSheet.create({
  container: {
    zIndex: -10,
  },
});
