# MockMaxxing Architecture & QA Suite Overview
*Prepared dynamically on 2026-05-21 21:47:54*

This package contains the complete source code, structural markdown books, session artifacts, automation scripts, and telemetry data for **MockMaxxing** to enable an external LLM model to perform a comprehensive code, design, and QA analysis.

---

## 📂 Package Folder Taxonomy

1. **/src**: Full application source code.
   * /app/wizard: active draft room layouts (ctive.tsx), setup flows (setup.tsx), summaries (summary.tsx).
   * /store: Zustand state containers (useMockMaxxingStore.ts, useAuthStore.ts, useThemeStore.ts).
   * /components: Reusable elements, including background textures and the brand-new layout ErrorBoundary.tsx.
   * /constants/theme.ts: Unified design system tokens, typography scales, and HSL palettes.
2. **/scripts**: High-fidelity automation, draft simulation engines, and developer-level QA tools.
   * un_50k_bot_stress.js / un_draft_simulations.js: Large-scale draft simulators to benchmark CPU archetype drafting strategies.
   * obotic_ui_explorer.js / ackground_simulator.js: Web automation, clickpath explorers, and headless simulation loops.
   * optimize_strategies.js: Dynamic strategy optimization script.
3. **/docs**: Corporate strategy, rules, and branding guides.
   * MOCKMAXXING_BIBLE.md: Official CEO corporate mandate detailing visual aesthetics, Google M3 containment, WCAG 2.2 AAA rules, and the Starbucks UX inspiration directive.
   * AGENTS.md: Coding mandate for agents and sub-agents detailing Triple-Core compliance.
   * PROJECT_CONTEXT.md: System capabilities, file trees, and environment metadata.
4. **/artifacts**: Session design documentation, checklist logs, and progression updates.
   * implementation_plan.md: Structural designs for gesture clamps and safe navigations.
   * 	ask.md: Living checklist showing exactly what was implemented and verified.
   * walkthrough.md: Detailed engineering changes, validation results, and simulation transcript logs.
5. **/qa_metrics**: High-density simulator runs, audit reports, and live concurrent run metrics.
   * scratch_live_metrics.json: Telemetry metrics, total concurrency records, and strategy win/loss ratios.
   * scratch_explorer_coverage_matrix.json: Headless explorer routes and UI interactive states.
   * udit_miss_report.html / udit_miss_report.pdf: Layout validation reports.

---

## ⚡ Active QA Processes & Telemetry Mechanics

1. **Genetic Bot-Draft Simulators**:
   * The store (useMockMaxxingStore.ts) features an automated simulation module running multi-threaded Monte Carlo draft sequences (up to 100,000 runs) to benchmark strategy win rates across draft slots and archetype parameters.
2. **Proactive Error Boundary & Trace Telemetry**:
   * Layout-level style exceptions are intercepted in src/components/ErrorBoundary.tsx to prevent blank reloads.
   * Console telemetry tracers in useMockMaxxingStore.ts's esetDraft() log strict call-stack frames to identify reset sources.
3. **TypeScript Type Safety**:
   * All changes are validated under a strict non-emitting compiler pass to guarantee absolute structural integrity.
