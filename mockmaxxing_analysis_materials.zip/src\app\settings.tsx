import React, { useState } from 'react';
import { StyleSheet, View, Text, Pressable, ScrollView, Platform, Image, Switch, TextInput, ActivityIndicator, Animated, Easing } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useColors, Fonts, Spacing, MaxContentWidth } from '@/constants/theme';
import { useThemeStore } from '@/store/useThemeStore';
import { useAuthStore } from '@/store/useAuthStore';
import BackgroundTexture from '@/components/BackgroundTexture';
import AppHeader from '@/components/AppHeader';
import AppTabBar from '@/components/AppTabBar';
import * as Haptics from 'expo-haptics';
import Svg, { Path } from 'react-native-svg';
import { useCronSyncStore, AppFeature } from '@/store/useCronSyncStore';

export default function SettingsScreen() {
  const router = useRouter();
  const { tab } = useLocalSearchParams<{ tab?: string }>();
  const Colors = useColors();
  const { theme, toggleTheme } = useThemeStore();
  const { user, updatePreferences, updateProfile } = useAuthStore();
  const [activeTab, setActiveTab] = useState<'inbox' | 'settings'>(tab === 'inbox' ? 'inbox' : 'settings');
  const [isStrategyExpanded, setIsStrategyExpanded] = useState(false);
  const [highlightedFeatureId, setHighlightedFeatureId] = useState<string | null>(null);

  // Modal Edit Profile Form State
  const [isEditModalVisible, setIsEditModalVisible] = useState(false);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editError, setEditError] = useState<string | null>(null);
  const [editSuccess, setEditSuccess] = useState<boolean>(false);
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  const handleOpenEditProfile = () => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    setEditName(user?.name ? user.name.replace(/^@/, '') : '');
    setEditEmail(user?.email || '');
    setEditPhone(user?.phoneNumber || '');
    setEditError(null);
    setEditSuccess(false);
    setIsSavingProfile(false);
    setIsEditModalVisible(true);
  };

  const handleSaveProfile = async () => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    setEditError(null);
    setEditSuccess(false);

    if (!editName.trim()) {
      setEditError('Coach username cannot be empty.');
      return;
    }

    if (!editEmail.trim()) {
      setEditError('Email address cannot be empty.');
      return;
    }

    setIsSavingProfile(true);

    try {
      const response = await updateProfile(editName.trim(), editEmail.trim(), editPhone.trim());
      if (response.success) {
        setEditSuccess(true);
        triggerNotificationHaptic(Haptics.NotificationFeedbackType.Success);
        setTimeout(() => {
          setIsEditModalVisible(false);
        }, 1200);
      } else {
        setEditError(response.error || 'Failed to update profile.');
        triggerNotificationHaptic(Haptics.NotificationFeedbackType.Error);
      }
    } catch (err: any) {
      setEditError(err?.message || 'An unexpected error occurred.');
      triggerNotificationHaptic(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleMilestonePress = (featureId: string) => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    setHighlightedFeatureId(featureId);
    setTimeout(() => {
      setHighlightedFeatureId(prev => prev === featureId ? null : prev);
    }, 2500);
  };

  const strategiesList = [
    'Late QB/TE Focus',
    'Hero RB',
    'Zero RB',
    'Balanced',
    'Robust RB',
    'Elite QB/TE Premium',
  ] as const;

  // React to search parameter changes
  React.useEffect(() => {
    if (tab === 'inbox') {
      setActiveTab('inbox');
    } else if (tab === 'settings') {
      setActiveTab('settings');
    }
  }, [tab]);
  
  // Centralized Cron Sync telemetry state subscription
  const {
    features,
    mostImpactfulFeature,
    isSyncing,
    lastSyncTime,
    nextSyncCountdown,
    runCronSync,
    toggleLikeFeature,
  } = useCronSyncStore();

  // Custom high-fidelity scrolling stock ticker animated states
  const [containerWidth, setContainerWidth] = useState(0);
  const [textWidth, setTextWidth] = useState(0);
  const translateX = React.useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    if (textWidth > 0) {
      translateX.setValue(0);
      const toVal = -textWidth / 2;
      const duration = Math.abs(toVal) * 35; // Custom premium speed control
      
      const anim = Animated.loop(
        Animated.timing(translateX, {
          toValue: toVal,
          duration: duration,
          easing: Easing.linear,
          useNativeDriver: true,
        })
      );
      anim.start();
      return () => anim.stop();
    }
  }, [textWidth, translateX, mostImpactfulFeature?.id]);

  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const triggerHaptic = async (style = Haptics.ImpactFeedbackStyle.Light) => {
    if (Platform.OS !== 'web') {
      try {
        await Haptics.impactAsync(style);
      } catch (err) {}
    }
  };

  const triggerNotificationHaptic = async (type: Haptics.NotificationFeedbackType) => {
    if (Platform.OS !== 'web') {
      try {
        await Haptics.notificationAsync(type);
      } catch (err) {}
    }
  };

  const handleTabChange = (tab: 'inbox' | 'settings') => {
    triggerHaptic();
    setActiveTab(tab);
  };

  const handleLikeFeature = (id: string) => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    toggleLikeFeature(id);
  };

  const handleActionPress = (feature: AppFeature) => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    if (feature.routePath.includes('tab=settings')) {
      handleTabChange('settings');
    } else {
      router.push(feature.routePath as any);
    }
  };

  const renderFeatureIcon = (type: string) => {
    switch (type) {
      case 'database':
        return (
          <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
            <Path d="M12 2C6.48 2 2 4 2 6.5s4.48 4.5 10 4.5 10-2 10-4.5S17.52 2 12 2zm0 18c-5.52 0-10-2-10-4.5v3c0 2.5 4.48 4.5 10 4.5s10-2 10-4.5v-3c0 2.5-4.48 4.5-10 4.5zm0-6c-5.52 0-10-2-10-4.5v3c0 2.5 4.48 4.5 10 4.5s10-2 10-4.5v-3c0 2.5-4.48 4.5-10 4.5z" fill={Colors.coltsNavy} />
          </Svg>
        );
      case 'palette':
        return (
          <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
            <Path d="M12 2C6.49 2 2 6.49 2 12s4.49 10 10 10c1.25 0 2.5-.5 3.32-1.39.42-.45.33-1.17-.18-1.5-.28-.18-.6-.28-.94-.28H13c-2.21 0-4-1.79-4-4 0-.74.2-1.43.55-2.03.26-.45.17-1.03-.23-1.4C8.5 10.74 8 9.93 8 9c0-2.21 1.79-4 4-4h.06c2.94 0 5.43 2.12 5.86 5.04.14.95.96 1.66 1.92 1.66h1.22c.79 0 1.48-.48 1.76-1.22.42-1.1.68-2.27.68-3.48C22 6.49 17.51 2 12 2zm-4.5 9c-.83 0-1.5-.67-1.5-1.5S6.67 8 7.5 8 9 8.67 9 9.5 8.33 11 7.5 11zm3-3C9.67 8 9 7.33 9 6.5S9.67 5 10.5 5s1.5.67 1.5 1.5S11.33 8 10.5 8zm4 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 3c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z" fill={Colors.coltsNavy} />
          </Svg>
        );
      case 'route':
        return (
          <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
            <Path d="M9 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm0 2c-4 0-7 2-7 6v2h14v-2c0-4-3-6-7-6zm11.85-3.15L19 7v3h-4v2h4v3l1.85-1.85a1 1 0 0 0 0-1.41l-.05-.05a1 1 0 0 0-.05-1.41l.1-.28z" fill={Colors.coltsNavy} />
          </Svg>
        );
      case 'trophy':
        return (
          <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
            <Path d="M19 12h-1c0 2.21-1.79 4-4 4h-4c-2.21 0-4-1.79-4-4H5c0 3.04 2.22 5.56 5.16 5.92L10 20H8v2h8v-2h-2l-.16-2.08C16.78 17.56 19 15.04 19 12z" fill={Colors.coltsNavy} />
          </Svg>
        );
      case 'refresh':
        return (
          <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
            <Path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z" fill={Colors.coltsNavy} />
          </Svg>
        );
      default:
        return (
          <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
            <Path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z" fill={Colors.coltsNavy} />
          </Svg>
        );
    }
  };

  const getCoachInitials = () => {
    if (!user) return 'C';
    const name = user.name || user.email || 'Coach';
    const cleanName = name.startsWith('@') ? name.substring(1) : name;
    return cleanName.substring(0, 1).toUpperCase();
  };

  return (
    <View style={styles.container}>
      <BackgroundTexture />
      <SafeAreaView style={styles.safeArea} edges={['top', 'bottom']}>
        
        {/* Unified Sub-page header with back action - Conditioned by activeTab */}
        <AppHeader
          title={activeTab === 'settings' ? "COACH PROFILE" : "INBOX"}
          subtitle={activeTab === 'settings' ? "Manage your profile & preferences" : "Latest updates & feature logs"}
          showBack={true}
          backText="BACK"
        />

        {/* Main Content Area */}
        <ScrollView 
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {activeTab === 'inbox' ? (
            <View style={styles.tabPanel}>
              {features.length === 0 ? (
                <View style={styles.emptyInboxCard}>
                  <Svg width={32} height={32} viewBox="0 0 24 24" fill="none">
                    <Path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z" fill={Colors.secondaryAccent} />
                  </Svg>
                  <Text style={styles.emptyInboxText}>No features recorded in the release stream yet.</Text>
                </View>
              ) : (
                features.map((feature) => {
                  return (
                    /* Starbucks-Style Inbox Card Overhauled for Feature Progress Changelog */
                    <View key={feature.id} style={[
                      styles.inboxCard,
                      highlightedFeatureId === feature.id && styles.inboxCardHighlighted
                    ]}>
                      <View style={styles.inboxCardHeader}>
                        <View style={styles.alertIconCircle}>
                          {renderFeatureIcon(feature.iconType)}
                        </View>
                        <View style={styles.inboxCardTitleBlock}>
                          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 4 }}>
                            <Text style={styles.inboxCardKicker}>{feature.category}</Text>
                          </View>
                          <Text style={styles.inboxCardSender}>{feature.title}</Text>
                        </View>
                      </View>

                      {/* Feature Description Paragraph Block */}
                      <Text style={styles.featureDescription}>{feature.description}</Text>

                      <View style={styles.cardDivider} />

                      {/* Interactive Dual CTA Buttons (Like feature + TRY IT NOW) */}
                      <View style={styles.dualCtaRow}>
                        <Pressable 
                          style={({ pressed }) => [
                            styles.likeBtn,
                            feature.hasLiked && styles.likeBtnActive,
                            pressed && styles.declineBtnPressed
                          ]}
                          onPress={() => handleLikeFeature(feature.id)}
                        >
                          <Text style={[
                            styles.likeBtnText,
                            feature.hasLiked && styles.likeBtnTextActive
                          ]}>
                            {feature.hasLiked ? 'LIKED' : 'LIKE'} ({feature.likes})
                          </Text>
                        </Pressable>

                        <Pressable 
                          style={({ pressed }) => [
                            styles.acceptBtn,
                            pressed && styles.acceptBtnPressed
                          ]}
                          onPress={() => handleActionPress(feature)}
                        >
                          <Text style={styles.acceptBtnText}>{feature.actionText}</Text>
                        </Pressable>
                      </View>
                    </View>
                  );
                })
              )}
            </View>
          ) : (
            <View style={styles.tabPanel}>
              
              {/* Profile Card Summary Row */}
              <View style={styles.profileSummaryCard}>
                <View style={styles.profileInitialsCircle}>
                  <Text style={styles.profileInitialsText}>{getCoachInitials()}</Text>
                </View>
                <View style={styles.profileDetailsBlock}>
                  <Text style={styles.profileCoachName}>{user?.name || '@Drafter'}</Text>
                  <Text style={styles.profileCoachEmail}>{user?.email || 'coach@mockmaxxing.com'}</Text>
                  {user?.phoneNumber ? (
                    <Text style={styles.profileCoachPhone}>📱 {user.phoneNumber}</Text>
                  ) : null}
                </View>
              </View>

              {/* Starbucks-Style settings list pattern (rows + chevrons sectioned by headers) */}
              
              {/* SECTION 1: ACCOUNT PREFERENCES */}
              <View style={styles.settingsSection}>
                <Text style={styles.settingsSectionHeader}>ACCOUNT PREFERENCES</Text>
                
                <Pressable 
                  style={({ pressed }) => [styles.settingsRow, pressed && styles.settingsRowPressed]}
                  onPress={handleOpenEditProfile}
                >
                  <View style={styles.settingsRowLeft}>
                    <Text style={styles.settingsRowTitle}>Update Profile</Text>
                    <Text style={styles.settingsRowSubtitle}>Change username, email, or phone number</Text>
                  </View>
                  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
                    <Path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" fill={Colors.secondaryAccent} />
                  </Svg>
                </Pressable>

                <Pressable 
                  style={({ pressed }) => [styles.settingsRow, pressed && styles.settingsRowPressed]}
                  onPress={() => triggerHaptic()}
                >
                  <View style={styles.settingsRowLeft}>
                    <Text style={styles.settingsRowTitle}>League Sync Credentials</Text>
                    <Text style={styles.settingsRowSubtitle}>Manage Sleeper or Yahoo integrations</Text>
                  </View>
                  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
                    <Path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" fill={Colors.secondaryAccent} />
                  </Svg>
                </Pressable>
              </View>

              {/* SECTION 2: SYSTEM ENGINE CONFIG */}
              <View style={styles.settingsSection}>
                <Text style={styles.settingsSectionHeader}>SIM ENGINE CONFIGURATION</Text>

                <Pressable 
                  style={({ pressed }) => [styles.settingsRow, pressed && styles.settingsRowPressed]}
                  onPress={() => triggerHaptic()}
                >
                  <View style={styles.settingsRowLeft}>
                    <Text style={styles.settingsRowTitle}>Draft Simulation Speed</Text>
                    <Text style={styles.settingsRowSubtitle}>Default delay interval for computer picks</Text>
                  </View>
                  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
                    <Path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" fill={Colors.secondaryAccent} />
                  </Svg>
                </Pressable>

                <Pressable 
                  style={({ pressed }) => [styles.settingsRow, pressed && styles.settingsRowPressed]}
                  onPress={() => triggerHaptic()}
                >
                  <View style={styles.settingsRowLeft}>
                    <Text style={styles.settingsRowTitle}>Waiver Wire Rules</Text>
                    <Text style={styles.settingsRowSubtitle}>Set FAAB preferences and priority lists</Text>
                  </View>
                  <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
                    <Path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" fill={Colors.secondaryAccent} />
                  </Svg>
                </Pressable>
              </View>

              {/* SECTION 2.5: DRAFT PREFERENCES */}
              <View style={styles.settingsSection}>
                <Text style={styles.settingsSectionHeader}>DRAFT PREFERENCES</Text>
                
                <Pressable 
                  style={({ pressed }) => [styles.settingsRow, pressed && styles.settingsRowPressed]}
                  onPress={() => {
                    triggerHaptic();
                    setIsStrategyExpanded(!isStrategyExpanded);
                  }}
                >
                  <View style={styles.settingsRowLeft}>
                    <Text style={styles.settingsRowTitle}>Default Draft Strategy</Text>
                    <Text style={styles.settingsRowSubtitle}>
                      Active: {user?.preferences?.draftStrategy || 'Late QB/TE Focus'}
                    </Text>
                  </View>
                  <Svg 
                    width={18} 
                    height={18} 
                    viewBox="0 0 24 24" 
                    fill="none"
                    style={{ transform: [{ rotate: isStrategyExpanded ? '90deg' : '0deg' }] }}
                  >
                    <Path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" fill={Colors.secondaryAccent} />
                  </Svg>
                </Pressable>

                {isStrategyExpanded && (
                  <View style={styles.strategyExpandableContainer}>
                    <Text style={styles.strategyPanelDesc}>
                      Set the default drafting camp pre-populated when launching the Mock Draft Wizard setup screen.
                    </Text>
                    <View style={styles.strategyCapsuleRow}>
                      {strategiesList.map((strategy) => {
                        const active = (user?.preferences?.draftStrategy || 'Late QB/TE Focus') === strategy;
                        return (
                          <Pressable
                            key={strategy}
                            style={({ pressed }) => [
                              styles.strategyCapsuleChip,
                              active && styles.strategyCapsuleChipActive,
                              pressed && styles.btnPressed
                            ]}
                            onPress={async () => {
                              triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                              await updatePreferences({ draftStrategy: strategy });
                            }}
                          >
                            <Text style={[
                              styles.strategyCapsuleText,
                              active && styles.strategyCapsuleTextActive
                            ]}>
                              {strategy.toUpperCase()}
                            </Text>
                          </Pressable>
                        );
                      })}
                    </View>
                  </View>
                )}
              </View>

              {/* EXECUTIVE DASHBOARD FOR CEO */}
              {(user?.firstName?.toLowerCase() === 'brad' ||
                user?.name?.toLowerCase().includes('brad') ||
                user?.email?.toLowerCase().includes('brad') ||
                user?.email === 'lou.bradstafford@gmail.com') && (
                <View style={styles.settingsSection}>
                  <Text style={styles.settingsSectionHeader}>EXECUTIVE CONTROL PANEL</Text>
                  
                  <Pressable 
                    style={({ pressed }) => [styles.settingsRow, pressed && styles.settingsRowPressed]}
                    onPress={() => {
                      triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
                      router.push('/executive-dashboard');
                    }}
                  >
                    <View style={styles.settingsRowLeft}>
                      <Text style={styles.settingsRowTitle}>
                        Executive IT Dashboard
                      </Text>
                      <Text style={styles.settingsRowSubtitle}>
                        Pin Slot 1 promoted tile, cap homepage feed, and oversee simulation lab
                      </Text>
                    </View>
                    <Svg width={18} height={18} viewBox="0 0 24 24" fill="none">
                      <Path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" fill={Colors.secondaryAccent} />
                    </Svg>
                  </Pressable>
                </View>
              )}

              {/* SECTION 3: THEME PREFERENCES */}
              <View style={styles.settingsSection}>
                <Text style={styles.settingsSectionHeader}>VISUAL THEME SYSTEM</Text>

                {/* THEME TOGGLE SWITCH ROW (Dynamic Theme Control) */}
                <View style={styles.settingsSwitchRow}>
                  <View style={styles.settingsRowLeft}>
                    <Text style={styles.settingsRowTitle}>Dark Mode Interface</Text>
                    <Text style={styles.settingsRowSubtitle}>Switch layouts into high-contrast obsidian dark</Text>
                  </View>
                  <Switch
                    value={theme === 'dark'}
                    onValueChange={() => {
                      triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
                      toggleTheme();
                    }}
                    trackColor={{ false: '#CBD5E1', true: Colors.coltsNavy }}
                    thumbColor={Platform.OS === 'ios' ? undefined : '#FFFFFF'}
                  />
                </View>
              </View>

            </View>
          )}
        </ScrollView>

      </SafeAreaView>
      <AppTabBar />

      {/* Modal Profile Edit overlay */}
      {isEditModalVisible && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContentCard}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <Text style={styles.modalTitle}>UPDATE COACH PROFILE</Text>
              <Pressable
                onPress={() => {
                  triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                  setIsEditModalVisible(false);
                }}
                disabled={isSavingProfile}
              >
                <Text style={{ color: Colors.secondaryAccent, fontSize: 20, fontWeight: 'bold' }}>×</Text>
              </Pressable>
            </View>

            <Text style={styles.modalDesc}>
              Modify your account credentials. Changing your email address updates your offline database key automatically.
            </Text>

            {editError && (
              <View style={styles.modalErrorBox}>
                <Text style={styles.modalErrorText}>⚠️ {editError}</Text>
              </View>
            )}

            {editSuccess && (
              <View style={styles.modalSuccessBox}>
                <Text style={styles.modalSuccessText}>✅ Profile updated successfully!</Text>
              </View>
            )}

            <View style={styles.modalFormGroup}>
              <Text style={styles.modalFormLabel}>COACH USERNAME</Text>
              <TextInput
                style={styles.modalSingleLineInput}
                placeholder="e.g. Brad_Drafter"
                placeholderTextColor={Colors.secondaryAccent + '80'}
                value={editName}
                onChangeText={(text) => {
                  setEditError(null);
                  setEditName(text);
                }}
                editable={!isSavingProfile && !editSuccess}
                autoCapitalize="none"
              />
            </View>

            <View style={styles.modalFormGroup}>
              <Text style={styles.modalFormLabel}>EMAIL ADDRESS</Text>
              <TextInput
                style={styles.modalSingleLineInput}
                placeholder="e.g. brad@mockmax.com"
                placeholderTextColor={Colors.secondaryAccent + '80'}
                value={editEmail}
                onChangeText={(text) => {
                  setEditError(null);
                  setEditEmail(text);
                }}
                editable={!isSavingProfile && !editSuccess}
                autoCapitalize="none"
                keyboardType="email-address"
              />
            </View>

            <View style={styles.modalFormGroup}>
              <Text style={styles.modalFormLabel}>PHONE NUMBER (PASSWORD RESET)</Text>
              <TextInput
                style={styles.modalSingleLineInput}
                placeholder="e.g. 123-456-7890"
                placeholderTextColor={Colors.secondaryAccent + '80'}
                value={editPhone}
                onChangeText={(text) => {
                  setEditError(null);
                  setEditPhone(text);
                }}
                editable={!isSavingProfile && !editSuccess}
                keyboardType="phone-pad"
              />
            </View>

            <View style={styles.modalActionRow}>
              <Pressable
                style={styles.modalBtn}
                onPress={() => {
                  triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                  setIsEditModalVisible(false);
                }}
                disabled={isSavingProfile || editSuccess}
              >
                <Text style={styles.modalBtnText}>CANCEL</Text>
              </Pressable>

              <Pressable
                style={[
                  styles.modalBtn,
                  styles.modalBtnPrimary,
                  isSavingProfile && { opacity: 0.7 }
                ]}
                onPress={handleSaveProfile}
                disabled={isSavingProfile || editSuccess}
              >
                {isSavingProfile ? (
                  <ActivityIndicator size="small" color="#ffffff" />
                ) : (
                  <Text style={styles.modalBtnTextPrimary}>SAVE CHANGES</Text>
                )}
              </Pressable>
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

/* ========================================================== */
/*                 DYNAMIC PROXY STYLESHEET                   */
/* ========================================================== */
function createStyles(Colors: typeof import('@/constants/theme').LightColors) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: Colors.background,
    },
    safeArea: {
      flex: 1,
      alignSelf: 'center',
      width: '100%',
      maxWidth: MaxContentWidth,
    },
    largeTitleContainer: {
      paddingHorizontal: Spacing.four,
      paddingTop: Spacing.two,
      paddingBottom: Spacing.one,
    },
    largeTitleText: {
      fontFamily: Fonts.headings,
      fontSize: 34,
      fontWeight: 'bold',
      color: Colors.primaryAccent,
      letterSpacing: -0.5,
    },
    tabContainer: {
      flexDirection: 'row',
      borderBottomWidth: 1,
      borderBottomColor: Colors.coltsNavyLight,
      paddingHorizontal: Spacing.four,
      backgroundColor: Colors.background,
    },
    tabItem: {
      paddingVertical: Spacing.three,
      marginRight: Spacing.four,
      position: 'relative',
    },
    tabText: {
      fontFamily: Fonts.headings,
      fontSize: 15,
      fontWeight: 'bold',
      letterSpacing: 0.5,
    },
    tabTextActive: {
      color: Colors.coltsNavy,
    },
    tabTextInactive: {
      color: Colors.secondaryAccent,
      opacity: 0.7,
    },
    activeTabUnderline: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      height: 3,
      backgroundColor: Colors.coltsNavy,
      borderRadius: 1.5,
    },
    scrollView: {
      flex: 1,
    },
    scrollContent: {
      paddingHorizontal: Spacing.four,
      paddingTop: Spacing.four,
      paddingBottom: 140, // Deep padding bottom to clear the Tab Bar
    },
    tabPanel: {
      gap: Spacing.four,
    },
    sectionHeader: {
      fontFamily: Fonts.stats,
      fontSize: 10,
      fontWeight: '800',
      color: Colors.coltsNavy,
      letterSpacing: 1.5,
      marginBottom: Spacing.one,
    },
    emptyInboxCard: {
      backgroundColor: Colors.surface,
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1,
      borderRadius: 12,
      padding: Spacing.five,
      alignItems: 'center',
      justifyContent: 'center',
      gap: Spacing.two,
    },
    emptyInboxText: {
      fontFamily: Fonts.body,
      fontSize: 12,
      color: Colors.secondaryAccent,
      textAlign: 'center',
      lineHeight: 18,
      opacity: 0.8,
    },
    
    // Inbox alert card styles
    inboxCard: {
      backgroundColor: Colors.surface,
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1,
      borderRadius: 12,
      padding: Spacing.four,
      gap: Spacing.three,
      ...Colors.shadows,
    },
    inboxCardHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: Spacing.three,
    },
    alertIconCircle: {
      width: 36,
      height: 36,
      borderRadius: 18,
      backgroundColor: Colors.surfaceLifted,
      justifyContent: 'center',
      alignItems: 'center',
      borderWidth: 1,
      borderColor: Colors.coltsNavyLight,
    },
    inboxCardTitleBlock: {
      flex: 1,
      gap: 2,
    },
    inboxCardKicker: {
      fontFamily: Fonts.stats,
      fontSize: 8,
      fontWeight: '900',
      color: Colors.hofYellow,
      letterSpacing: 1.5,
    },
    inboxCardSender: {
      fontFamily: Fonts.headings,
      fontSize: 14,
      fontWeight: 'bold',
      color: Colors.primaryAccent,
    },
    inboxCardHighlighted: {
      borderColor: Colors.hofYellow,
      borderWidth: 2.5,
      shadowColor: Colors.hofYellow,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.4,
      shadowRadius: 10,
      elevation: 8,
    },
    tickerWrapper: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#EF8354', // Vibrant Coral accent from user color palette
      borderRadius: 8,
      paddingHorizontal: Spacing.two,
      paddingVertical: Spacing.two,
      marginBottom: Spacing.three,
      overflow: 'hidden',
      borderWidth: 1.5,
      borderColor: '#BFC0C0',
      elevation: 3,
      shadowColor: '#000000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.15,
      shadowRadius: 4,
    },
    tickerBadge: {
      backgroundColor: '#2D3142', // Dark Slate Blue contrast
      paddingHorizontal: Spacing.two,
      paddingVertical: 4,
      borderRadius: 4,
      marginRight: Spacing.two,
      zIndex: 10,
    },
    tickerBadgeText: {
      fontFamily: Fonts.headings,
      fontSize: 10,
      fontWeight: '900',
      color: '#FFFFFF', // High-contrast White
      letterSpacing: 1.5,
    },
    marqueeOuter: {
      flex: 1,
      overflow: 'hidden',
      flexDirection: 'row',
      alignItems: 'center',
    },
    marqueeInner: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    marqueeText: {
      fontFamily: Fonts.stats,
      fontSize: 11,
      fontWeight: 'bold',
      color: '#000000', // Solid black text on energetic Coral background (WCAG 2.2 AAA Contrast >7:1)
      letterSpacing: 0.8,
      paddingRight: 40, // Separator gap between loops
    },
    instantSyncBtn: {
      backgroundColor: '#EF8354', // Vibrant Coral accent
      paddingHorizontal: Spacing.three,
      paddingVertical: Spacing.one + 2,
      borderRadius: 6,
      justifyContent: 'center',
      alignItems: 'center',
    },
    instantSyncBtnPressed: {
      opacity: 0.85,
      transform: [{ scale: 0.97 }],
    },
    instantSyncBtnDisabled: {
      opacity: 0.6,
      backgroundColor: '#BFC0C0',
    },
    instantSyncBtnText: {
      fontFamily: Fonts.headings,
      fontSize: 10,
      fontWeight: '900',
      color: '#000000', // Crisp high contrast text
      letterSpacing: 1,
    },
    telemetryClockRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: Spacing.one,
    },
    telemetryClockCol: {
      flex: 1,
      alignItems: 'center',
      gap: 2,
    },
    telemetryClockLabel: {
      fontFamily: Fonts.stats,
      fontSize: 8,
      fontWeight: '800',
      color: Colors.secondaryAccent,
      letterSpacing: 1,
    },
    telemetryClockValue: {
      fontFamily: Fonts.stats,
      fontSize: 14,
      fontWeight: 'bold',
      color: '#EF8354', // Vibrant Coral accent
    },
    telemetryCard: {
      backgroundColor: Colors.surface,
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1,
      borderRadius: 12,
      padding: Spacing.four,
      marginBottom: Spacing.four,
      gap: Spacing.three,
      ...Colors.shadows,
    },
    telemetryHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    telemetryTitle: {
      fontFamily: Fonts.headings,
      fontSize: 10,
      fontWeight: '900',
      color: Colors.primaryAccent,
      letterSpacing: 1.5,
    },
    telemetryStatusGroup: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
    },
    telemetryGreenDot: {
      width: 6,
      height: 6,
      borderRadius: 3,
      backgroundColor: '#10b981',
    },
    telemetryStatusText: {
      fontFamily: Fonts.stats,
      fontSize: 8,
      fontWeight: 'bold',
      color: Colors.secondaryAccent,
      letterSpacing: 1,
    },
    telemetryStatsGrid: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: Spacing.one,
    },
    telemetryStatCol: {
      flex: 1,
      alignItems: 'center',
      gap: 2,
    },
    telemetryStatLabel: {
      fontFamily: Fonts.stats,
      fontSize: 8,
      fontWeight: '800',
      color: Colors.secondaryAccent,
      letterSpacing: 1,
    },
    telemetryStatValue: {
      fontFamily: Fonts.headings,
      fontSize: 22,
      fontWeight: 'bold',
      color: Colors.coltsNavy,
    },
    telemetryStatSub: {
      fontFamily: Fonts.body,
      fontSize: 8.5,
      fontWeight: '600',
      color: Colors.secondaryAccent,
      opacity: 0.8,
    },
    telemetryStatDivider: {
      width: 1,
      height: 36,
      backgroundColor: Colors.coltsNavyLight,
    },
    telemetryDivider: {
      height: 1,
      backgroundColor: Colors.coltsNavyLight,
      marginHorizontal: -Spacing.four,
    },
    timelineLabel: {
      fontFamily: Fonts.stats,
      fontSize: 8,
      fontWeight: '900',
      color: Colors.secondaryAccent,
      letterSpacing: 1,
    },
    timelineScrollView: {
      marginTop: 2,
    },
    timelineScrollContent: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 6,
      paddingHorizontal: 2,
      gap: 0,
    },
    timelineNodeContainer: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    timelineLineConnector: {
      width: 20,
      height: 2,
      backgroundColor: Colors.coltsNavyLight,
    },
    timelineNodeCircle: {
      width: 38,
      height: 38,
      borderRadius: 19,
      backgroundColor: Colors.surfaceLifted,
      borderWidth: 1.5,
      borderColor: Colors.coltsNavyLight,
      justifyContent: 'center',
      alignItems: 'center',
    },
    timelineNodeCircleActive: {
      backgroundColor: Colors.coltsNavy,
      borderColor: Colors.hofYellow,
    },
    timelineNodeCirclePressed: {
      transform: [{ scale: 0.94 }],
    },
    timelineNodeText: {
      fontFamily: Fonts.stats,
      fontSize: 9,
      fontWeight: 'bold',
      color: Colors.secondaryAccent,
    },
    timelineNodeTextActive: {
      color: '#FFFFFF',
      fontWeight: '800',
    },
    cardDivider: {
      height: 1,
      backgroundColor: Colors.coltsNavyLight,
      marginHorizontal: -Spacing.four,
    },
    dualCtaRow: {
      flexDirection: 'row',
      gap: Spacing.three,
      marginTop: 2,
    },
    acceptBtn: {
      flex: 1,
      backgroundColor: Colors.coltsNavy,
      borderRadius: 8,
      height: 38,
      justifyContent: 'center',
      alignItems: 'center',
    },
    acceptBtnPressed: {
      opacity: 0.85,
    },
    acceptBtnText: {
      fontFamily: Fonts.headings,
      fontSize: 12,
      color: '#FFFFFF',
      fontWeight: 'bold',
      letterSpacing: 0.5,
    },
    declineBtn: {
      flex: 1,
      backgroundColor: 'transparent',
      borderColor: Colors.coltsNavy,
      borderWidth: 1.5,
      borderRadius: 8,
      height: 38,
      justifyContent: 'center',
      alignItems: 'center',
    },
    declineBtnPressed: {
      backgroundColor: 'rgba(224, 49, 34, 0.05)',
    },
    declineBtnText: {
      fontFamily: Fonts.headings,
      fontSize: 12,
      color: Colors.coltsNavy,
      fontWeight: 'bold',
      letterSpacing: 0.5,
    },

    // Settings Profile summary card
    profileSummaryCard: {
      backgroundColor: Colors.surface,
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1,
      borderRadius: 12,
      padding: Spacing.four,
      flexDirection: 'row',
      alignItems: 'center',
      gap: Spacing.three,
      ...Colors.shadows,
      marginBottom: Spacing.two,
    },
    profileInitialsCircle: {
      width: 48,
      height: 48,
      borderRadius: 24,
      backgroundColor: Colors.coltsNavy,
      justifyContent: 'center',
      alignItems: 'center',
    },
    profileInitialsText: {
      fontFamily: Fonts.headings,
      fontSize: 18,
      fontWeight: 'bold',
      color: '#FFFFFF',
    },
    profileDetailsBlock: {
      flex: 1,
      gap: 2,
    },
    profileCoachName: {
      fontFamily: Fonts.headings,
      fontSize: 16,
      fontWeight: 'bold',
      color: Colors.primaryAccent,
    },
    profileCoachEmail: {
      fontFamily: Fonts.body,
      fontSize: 11,
      color: Colors.secondaryAccent,
      opacity: 0.8,
    },

    // Settings rows section styles
    settingsSection: {
      gap: Spacing.two,
      marginTop: Spacing.two,
    },
    settingsSectionHeader: {
      fontFamily: Fonts.stats,
      fontSize: 9,
      fontWeight: '900',
      color: Colors.coltsNavy,
      letterSpacing: 1.5,
      paddingLeft: 4,
    },
    settingsRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      backgroundColor: Colors.surface,
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1,
      borderRadius: 10,
      paddingVertical: Spacing.three,
      paddingHorizontal: Spacing.three,
      minHeight: 52, // HIG Vertical Target Compliant
    },
    settingsRowPressed: {
      backgroundColor: Colors.surfaceLifted,
    },
    settingsSwitchRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      backgroundColor: Colors.surface,
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1,
      borderRadius: 10,
      paddingVertical: Spacing.three,
      paddingHorizontal: Spacing.three,
      minHeight: 52,
    },
    settingsRowLeft: {
      flex: 1,
      gap: 2,
      paddingRight: 8,
    },
    settingsRowTitle: {
      fontFamily: Fonts.headings,
      fontSize: 13,
      fontWeight: 'bold',
      color: Colors.primaryAccent,
    },
    settingsRowSubtitle: {
      fontFamily: Fonts.body,
      fontSize: 10,
      color: Colors.secondaryAccent,
      opacity: 0.8,
    },
    strategyExpandableContainer: {
      backgroundColor: Colors.surfaceLifted,
      borderColor: Colors.coltsNavyLight,
      borderWidth: 0.5,
      borderRadius: 10,
      padding: Spacing.three,
      gap: Spacing.two,
      marginTop: -2,
    },
    strategyPanelDesc: {
      fontFamily: Fonts.body,
      fontSize: 10,
      color: Colors.secondaryAccent,
      opacity: 0.8,
      lineHeight: 14,
      marginBottom: 2,
    },
    strategyCapsuleRow: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 8,
    },
    strategyCapsuleChip: {
      paddingHorizontal: Spacing.three,
      paddingVertical: 8,
      backgroundColor: Colors.surface,
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1,
      borderRadius: 18,
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: 36, // HIG touch target compliant
    },
    strategyCapsuleChipActive: {
      backgroundColor: Colors.coltsNavy,
      borderColor: Colors.coltsNavy,
      borderWidth: 1,
    },
    strategyCapsuleText: {
      fontFamily: Fonts.headings,
      fontSize: 10,
      color: Colors.secondaryAccent,
      fontWeight: 'bold',
    },
    strategyCapsuleTextActive: {
      color: '#ffffff',
    },
    btnPressed: {
      opacity: 0.7,
    },
    featureDescription: {
      fontFamily: Fonts.body,
      fontSize: 12,
      color: Colors.secondaryAccent,
      lineHeight: 18,
      opacity: 0.9,
    },
    featureVersionBadge: {
      backgroundColor: Colors.coltsNavyLight,
      borderRadius: 4,
      paddingHorizontal: 6,
      paddingVertical: 2,
    },
    featureVersionText: {
      fontFamily: Fonts.stats,
      fontSize: 9,
      fontWeight: 'bold',
      color: Colors.coltsNavy,
    },
    likeBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: 'transparent',
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1.5,
      borderRadius: 20,
      height: 38,
      paddingHorizontal: 16,
      gap: 6,
    },
    likeBtnActive: {
      backgroundColor: 'rgba(255, 75, 75, 0.08)',
      borderColor: '#ff4b4b',
    },
    likeBtnText: {
      fontFamily: Fonts.headings,
      fontSize: 11,
      color: Colors.secondaryAccent,
      fontWeight: 'bold',
      letterSpacing: 0.5,
    },
    likeBtnTextActive: {
      color: '#ff4b4b',
    },
    profileCoachPhone: {
      fontFamily: Fonts.body,
      fontSize: 10,
      color: Colors.secondaryAccent,
      opacity: 0.8,
      marginTop: 2,
    },
    modalOverlay: {
      ...StyleSheet.absoluteFillObject,
      backgroundColor: 'rgba(9, 9, 11, 0.85)',
      justifyContent: 'center',
      alignItems: 'center',
      padding: Spacing.four,
      zIndex: 10000,
    },
    modalContentCard: {
      backgroundColor: Colors.surface,
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1,
      borderRadius: 12,
      padding: Spacing.four,
      width: '100%',
      maxWidth: 420,
      shadowColor: '#000000',
      shadowOffset: { width: 0, height: 10 },
      shadowOpacity: 0.5,
      shadowRadius: 20,
      elevation: 10,
    },
    modalTitle: {
      fontFamily: Fonts.headings,
      fontSize: 14,
      fontWeight: 'bold',
      color: Colors.primaryAccent,
      letterSpacing: 1,
    },
    modalDesc: {
      fontFamily: Fonts.body,
      fontSize: 10.5,
      color: Colors.secondaryAccent,
      lineHeight: 15,
      marginBottom: Spacing.three,
      opacity: 0.85,
    },
    modalErrorBox: {
      backgroundColor: 'rgba(239, 68, 68, 0.1)',
      borderColor: Colors.status.danger,
      borderWidth: 1,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 12,
      marginBottom: Spacing.three,
    },
    modalErrorText: {
      fontFamily: Fonts.body,
      fontSize: 10.5,
      color: Colors.status.danger,
      fontWeight: 'bold',
      textAlign: 'center',
    },
    modalSuccessBox: {
      backgroundColor: 'rgba(34, 197, 94, 0.1)',
      borderColor: Colors.status.success,
      borderWidth: 1,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 12,
      marginBottom: Spacing.three,
    },
    modalSuccessText: {
      fontFamily: Fonts.body,
      fontSize: 10.5,
      color: Colors.status.success,
      fontWeight: 'bold',
      textAlign: 'center',
    },
    modalFormGroup: {
      gap: 6,
      marginBottom: Spacing.three,
      width: '100%',
    },
    modalFormLabel: {
      fontFamily: Fonts.stats,
      fontSize: 8,
      color: Colors.secondaryAccent,
      letterSpacing: 1.2,
      fontWeight: 'bold',
    },
    modalSingleLineInput: {
      height: 40,
      backgroundColor: Colors.surfaceLifted,
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1,
      borderRadius: 8,
      paddingHorizontal: 12,
      fontSize: 13,
      color: Colors.primaryAccent,
      fontFamily: Fonts.body,
    },
    modalActionRow: {
      flexDirection: 'row',
      gap: 8,
      justifyContent: 'flex-end',
      marginTop: Spacing.two,
    },
    modalBtn: {
      height: 38,
      borderRadius: 8,
      paddingHorizontal: 16,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: 'transparent',
      borderColor: Colors.coltsNavyLight,
      borderWidth: 1,
    },
    modalBtnPrimary: {
      backgroundColor: Colors.coltsNavy,
      borderColor: Colors.coltsNavy,
      borderWidth: 1,
      flex: 1,
    },
    modalBtnText: {
      fontFamily: Fonts.stats,
      fontSize: 9.5,
      fontWeight: 'bold',
      color: Colors.secondaryAccent,
      letterSpacing: 0.5,
    },
    modalBtnTextPrimary: {
      fontFamily: Fonts.stats,
      fontSize: 9.5,
      fontWeight: 'bold',
      color: '#ffffff',
      letterSpacing: 0.5,
    },
  });
}

// Precompile lightStyles and darkStyles at module evaluation time
const lightStyles = createStyles(require('@/constants/theme').LightColors);
const darkStyles = createStyles(require('@/constants/theme').DarkColors);

// Create the dynamic Proxy styles dispatcher
const styles = new Proxy({}, {
  get(target, prop) {
    const theme = useThemeStore.getState().theme;
    return theme === 'dark' ? darkStyles[prop as keyof typeof darkStyles] : lightStyles[prop as keyof typeof lightStyles];
  }
}) as ReturnType<typeof createStyles>;
