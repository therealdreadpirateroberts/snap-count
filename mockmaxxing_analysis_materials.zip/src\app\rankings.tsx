import React, { useMemo, useState, useRef, useEffect, useCallback } from 'react';
import { StyleSheet, View, Text, TextInput, Pressable, FlatList, ScrollView, Image, Clipboard, PanResponder, Animated, Platform, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useMockMaxxingStore } from '@/store/useMockMaxxingStore';
import { Player, getTeamLogoUrl } from '@/store/mockData';
import { Colors, Fonts, Spacing, MaxContentWidth, useColors, LightColors, DarkColors } from '@/constants/theme';
import { useThemeStore } from '@/store/useThemeStore';
import BackgroundTexture from '@/components/BackgroundTexture';
import AppHeader from '@/components/AppHeader';
import Svg, { Path, Circle } from 'react-native-svg';
import AppTabBar from '@/components/AppTabBar';
import * as Haptics from 'expo-haptics';

const triggerHaptic = async (style: Haptics.ImpactFeedbackStyle = Haptics.ImpactFeedbackStyle.Light) => {
  if (Platform.OS !== 'web') {
    try {
      await Haptics.impactAsync(style);
    } catch (err) {
      console.warn('Haptics failed:', err);
    }
  }
};

// Map players to direct ESPN player IDs for premium headshots
const getPlayerHeadshotUrl = (espnId: number | null, position: string, team?: string) => {
  if (position === 'DST' && team) {
    return getTeamLogoUrl(team);
  }
  if (espnId) {
    return `https://a.espncdn.com/i/headshots/nfl/players/full/${espnId}.png`;
  }
  return `https://a.espncdn.com/combiner/i?img=/i/headshots/nfl/players/full/default.png&w=350&h=254`;
};

// Position-specific tiers helper
const getPlayerTierInfo = (player: Player, filter: string, listIndex: number) => {
  const posIndex = parseInt(player.posRank.replace(/^[A-Z]+/i, ''), 10) || (listIndex + 1);
  const oneBasedListIndex = listIndex + 1;
  const overallRank = player.rank;

  if (filter === 'ALL') {
    if (overallRank <= 5) return { tier: 1, label: 'TIER 1 (ELITE)', color: '#ef4444' };
    if (overallRank <= 15) return { tier: 2, label: 'TIER 2 (STRONG STARTERS)', color: '#fbbf24' };
    if (overallRank <= 30) return { tier: 3, label: 'TIER 3 (SOLID OPTIONS)', color: '#fb923c' };
    if (overallRank <= 50) return { tier: 4, label: 'TIER 4 (FLEX / DEEP STARTERS)', color: '#60a5fa' };
    if (overallRank <= 75) return { tier: 5, label: 'TIER 5 (BENCH / UPSIDE)', color: '#4ade80' };
    if (overallRank <= 100) return { tier: 6, label: 'TIER 6 (BACKUPS)', color: '#c084fc' };
    if (overallRank <= 125) return { tier: 7, label: 'TIER 7 (DEEP ROSTER)', color: '#a7f3d0' };
    return { tier: 8, label: 'TIER 8 (DART THROWS)', color: '#94a3b8' };
  }

  if (filter === 'QB') {
    if (posIndex <= 3) return { tier: 1, label: 'TIER 1 (ELITE QB1)', color: '#ef4444' };
    if (posIndex <= 8) return { tier: 2, label: 'TIER 2 (STRONG QB1)', color: '#fbbf24' };
    if (posIndex <= 12) return { tier: 3, label: 'TIER 3 (LOW-END QB1)', color: '#fb923c' };
    if (posIndex <= 18) return { tier: 4, label: 'TIER 4 (STREAMER / HIGH QB2)', color: '#60a5fa' };
    if (posIndex <= 24) return { tier: 5, label: 'TIER 5 (LOW-END QB2)', color: '#4ade80' };
    return { tier: 6, label: 'TIER 6 (BACKUPS)', color: '#c084fc' };
  }

  if (filter === 'RB') {
    if (posIndex <= 4) return { tier: 1, label: 'TIER 1 (ELITE RB1)', color: '#ef4444' };
    if (posIndex <= 12) return { tier: 2, label: 'TIER 2 (STRONG RB1)', color: '#fbbf24' };
    if (posIndex <= 20) return { tier: 3, label: 'TIER 3 (SOLID RB2)', color: '#fb923c' };
    if (posIndex <= 30) return { tier: 4, label: 'TIER 4 (FLEX / RB3)', color: '#60a5fa' };
    if (posIndex <= 42) return { tier: 5, label: 'TIER 5 (UPSIDE BENCH)', color: '#4ade80' };
    return { tier: 6, label: 'TIER 6 (HANDCUFFS)', color: '#c084fc' };
  }

  if (filter === 'WR') {
    if (posIndex <= 5) return { tier: 1, label: 'TIER 1 (ELITE WR1)', color: '#ef4444' };
    if (posIndex <= 15) return { tier: 2, label: 'TIER 2 (STRONG WR1/2)', color: '#fbbf24' };
    if (posIndex <= 25) return { tier: 3, label: 'TIER 3 (SOLID WR2)', color: '#fb923c' };
    if (posIndex <= 40) return { tier: 4, label: 'TIER 4 (WR3 / FLEX)', color: '#60a5fa' };
    if (posIndex <= 60) return { tier: 5, label: 'TIER 5 (BENCH WR)', color: '#4ade80' };
    return { tier: 6, label: 'TIER 6 (DEEP ROSTER)', color: '#c084fc' };
  }

  if (filter === 'TE') {
    if (posIndex <= 3) return { tier: 1, label: 'TIER 1 (ELITE TE1)', color: '#ef4444' };
    if (posIndex <= 7) return { tier: 2, label: 'TIER 2 (STRONG STARTERS)', color: '#fbbf24' };
    if (posIndex <= 12) return { tier: 3, label: 'TIER 3 (STREAMERS / TE2)', color: '#fb923c' };
    return { tier: 4, label: 'TIER 4 (BACKUPS)', color: '#60a5fa' };
  }

  if (filter === 'FLEX') {
    if (oneBasedListIndex <= 10) return { tier: 1, label: 'TIER 1 (ELITE FLEX STARTERS)', color: '#ef4444' };
    if (oneBasedListIndex <= 25) return { tier: 2, label: 'TIER 2 (STRONG FLEX)', color: '#fbbf24' };
    if (oneBasedListIndex <= 50) return { tier: 3, label: 'TIER 3 (SOLID FLEX)', color: '#fb923c' };
    if (oneBasedListIndex <= 80) return { tier: 4, label: 'TIER 4 (FLEX OPTION)', color: '#60a5fa' };
    if (oneBasedListIndex <= 120) return { tier: 5, label: 'TIER 5 (BENCH FLEX)', color: '#4ade80' };
    return { tier: 6, label: 'TIER 6 (DEEP BENCH)', color: '#c084fc' };
  }

  if (filter === 'K' || filter === 'DST') {
    if (posIndex <= 3) return { tier: 1, label: 'TIER 1 (ELITE)', color: '#ef4444' };
    if (posIndex <= 8) return { tier: 2, label: 'TIER 2 (STRONG)', color: '#fbbf24' };
    if (posIndex <= 12) return { tier: 3, label: 'TIER 3 (STREAMER)', color: '#fb923c' };
    return { tier: 4, label: 'TIER 4 (OTHERS)', color: '#60a5fa' };
  }

  return { tier: 1, label: 'TIER 1', color: '#ef4444' };
};

const PlayerRow = React.memo(({
  item,
  isCurrentlyDragged,
  isDrafted,
  isSuggestion,
  showTierHeader,
  tierLabel,
  tierColor,
  boardType,
  panHandlers,
  dragY,
  onAddPlayer,
  Colors,
  styles
}: {
  item: Player;
  isCurrentlyDragged: boolean;
  isDrafted: boolean;
  isSuggestion: boolean;
  showTierHeader: boolean;
  tierLabel: string;
  tierColor: string;
  boardType: string;
  panHandlers: any;
  dragY: Animated.Value;
  onAddPlayer: (player: Player) => void;
  Colors: any;
  styles: any;
}) => {
  const ppg = Math.round((item.projectedPoints || 0) / 17);

  const rowContent = (
    <View style={[
      styles.rankingsRowItem, 
      isDrafted && styles.rankingsRowItemDrafted,
      isSuggestion && styles.rankingsRowItemSuggestion,
      isCurrentlyDragged && styles.rankingsRowItemDragging
    ]}>
      <View style={styles.rankingsRowLeftSection}>
        <View style={styles.normalRankSquare}>
          <Text style={styles.normalRankText}>{isSuggestion ? '—' : item.rank}</Text>
        </View>
        <View style={[styles.posRankBadge, { backgroundColor: Colors.positions[item.position as keyof typeof Colors.positions] }]}>
          <Text style={styles.posRankBadgeText}>{item.posRank}</Text>
        </View>
      </View>
      <Image 
        source={{ uri: getPlayerHeadshotUrl(item.espnId, item.position, item.team) }} 
        style={styles.rankingsRowHeadshot} 
      />
      <View style={styles.rankingsRowInfo}>
        <Text style={[styles.rankingsRowName, isDrafted && styles.playerNameDrafted]} numberOfLines={1}>
          {item.name}
        </Text>
        <Text style={styles.rankingsRowMeta}>
          {item.team} · Bye {item.bye} · {ppg} PPG {isSuggestion && '· Suggested'}
          {isDrafted && ` · (${item.draftedBy})`}
        </Text>
      </View>
      {isSuggestion ? (
        <Pressable 
          style={styles.addBtn}
          onPress={() => onAddPlayer(item)}
        >
          <Text style={styles.addBtnText}>+ ADD</Text>
        </Pressable>
      ) : boardType === 'custom' ? (
        <View style={styles.reorderContainer}>
          <View 
            style={styles.dragHandleSquare} 
            {...panHandlers}
          >
            <Svg width={14} height={14} viewBox="0 0 24 24" fill="none" pointerEvents="none">
              <Path d="M4 6H20M4 12H20M4 18H20" stroke="#a1a1aa" strokeWidth={2.5} strokeLinecap="round" />
            </Svg>
          </View>
        </View>
      ) : (
        <View style={styles.byeCol}>
          <View style={styles.byeTag}>
            <Text style={styles.byeText}>{item.bye}</Text>
          </View>
        </View>
      )}
    </View>
  );

  return (
    <View>
      {showTierHeader && (
        <View style={[styles.tierHeader, { borderBottomColor: tierColor }]}>
          <Text style={[styles.tierHeaderText, { color: tierColor }]}>{tierLabel}</Text>
        </View>
      )}
      <Animated.View 
        style={
          isCurrentlyDragged 
            ? { transform: [{ translateY: dragY }], zIndex: 1000 } 
            : undefined
        }
      >
        {rowContent}
      </Animated.View>
    </View>
  );
});

export default function RankingsScreen() {
  const Colors = useColors();
  const router = useRouter();
  
  const players = useMockMaxxingStore((state) => state.players);
  const myRanks = useMockMaxxingStore((state) => state.myRanks);
  const myRanksName = useMockMaxxingStore((state) => state.myRanksName);
  const initializeMyRanks = useMockMaxxingStore((state) => state.initializeMyRanks);
  const reorderMyRanks = useMockMaxxingStore((state) => state.reorderMyRanks);
  const resetMyRanks = useMockMaxxingStore((state) => state.resetMyRanks);
  const setMyRanks = useMockMaxxingStore((state) => state.setMyRanks);
  const updateSetup = useMockMaxxingStore((state) => state.updateSetup);

  const [boardType, setBoardType] = useState<'consensus' | 'custom'>('consensus');
  const [format, setFormat] = useState<'Standard' | 'Half-PPR' | 'Full PPR' | 'Dynasty'>('Standard');
  const [searchQuery, setSearchQuery] = useState('');
  const [positionFilter, setPositionFilter] = useState<'ALL' | 'QB' | 'RB' | 'WR' | 'TE' | 'FLEX' | 'K' | 'DST'>('ALL');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('saved');

  // Modals state
  const [activeModal, setActiveModal] = useState<'import' | 'export' | null>(null);
  const [modalText, setModalText] = useState('');
  const [copyFeedback, setCopyFeedback] = useState(false);

  // Naming Copy Modal state
  const [namingTemplateId, setNamingTemplateId] = useState<'consensus' | 'Andy' | 'Mike' | 'Jason' | 'blank' | 'import' | 'rename' | null>(null);
  const [customSheetName, setCustomSheetName] = useState('');
  const [tempImportedPlayers, setTempImportedPlayers] = useState<Player[] | null>(null);

  // Local rankings state for smooth, zero-latency drag-and-drop
  const [activeMyRanks, setActiveMyRanks] = useState<Player[]>([]);
  const [draggedPlayerName, setDraggedPlayerName] = useState<string | null>(null);
  const [scrollEnabled, setScrollEnabled] = useState(true);

  // Animation ref for smooth Y transformation of floating item
  const dragY = useRef(new Animated.Value(0)).current;

  // Refs to track drag indices dynamically
  const dragStartIndexRef = useRef<number>(-1);
  const dragCurrentIndexRef = useRef<number>(-1);
  const activeMyRanksRef = useRef<Player[]>([]);
  const flatListRef = useRef<FlatList<any>>(null);

  // Animated scroll and search visibility state
  const scrollY = useRef(new Animated.Value(0)).current;
  const [searchVisible, setSearchVisible] = useState(false);

  // Constant collapsible header height to maximize player density
  const HEADER_MAX_HEIGHT = 212;
  const clampedScrollY = Animated.diffClamp(scrollY, 0, HEADER_MAX_HEIGHT);
  const headerTranslateY = clampedScrollY.interpolate({
    inputRange: [0, HEADER_MAX_HEIGHT],
    outputRange: [0, -HEADER_MAX_HEIGHT],
    extrapolate: 'clamp',
  });
  const headerMaxHeight = HEADER_MAX_HEIGHT;

  // Keep activeMyRanksRef in sync for PanResponder callbacks
  useEffect(() => {
    activeMyRanksRef.current = activeMyRanks;
  }, [activeMyRanks]);

  // Synchronize local rankings with Zustand store changes (initial load, reset, imports)
  useEffect(() => {
    if (myRanks) {
      setActiveMyRanks(myRanks);
    } else {
      setActiveMyRanks([]);
    }
  }, [myRanks]);

  // Ref map to store stable PanResponder instances per player to prevent gesture resets on re-renders
  const panRespondersMapRef = useRef<Record<string, any>>({});

  // Clean up cached PanResponders if myRanks changes/resets to avoid leaking memory or capturing stale values
  useEffect(() => {
    panRespondersMapRef.current = {};
  }, [myRanks]);

  // Synchronous filter helper to avoid race conditions during dragging
  const getFilteredListSync = (ranksList: Player[]) => {
    return ranksList.filter((player) => {
      const matchesPosition = positionFilter === 'ALL' || 
        (positionFilter === 'FLEX' ? ['RB', 'WR', 'TE'].includes(player.position) : player.position === positionFilter);
      const matchesSearch = player.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            player.team.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesPosition && matchesSearch;
    });
  };

  // Get or create stable PanResponder for a given player item
  const getPanResponder = (player: Player) => {
    if (!panRespondersMapRef.current[player.name]) {
      panRespondersMapRef.current[player.name] = PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onStartShouldSetPanResponderCapture: () => true,
        onMoveShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponderCapture: () => true,
        onPanResponderTerminationRequest: () => false,
        onPanResponderGrant: () => {
          triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
          
          if (Platform.OS === 'web' && flatListRef.current) {
            const node = flatListRef.current.getScrollableNode() as any;
            if (node) {
              node.style.overflowY = 'hidden';
            }
          }
          
          // Use up-to-date master ranks synchronously
          const currentMaster = activeMyRanksRef.current;
          const filteredList = getFilteredListSync(currentMaster);
          const currentIdx = filteredList.findIndex(p => p.name === player.name);
          if (currentIdx === -1) return;

          dragStartIndexRef.current = currentIdx;
          dragCurrentIndexRef.current = currentIdx;
          setDraggedPlayerName(player.name);
          
          if (Platform.OS !== 'web') {
            setScrollEnabled(false);
          }
          dragY.setValue(0);
        },
        onPanResponderMove: (evt, gestureState) => {
          // Read activeMyRanksRef synchronously to prevent race conditions during high-frequency drag events
          const currentMaster = activeMyRanksRef.current;
          const filteredList = getFilteredListSync(currentMaster);
          const startIndex = dragStartIndexRef.current;
          const currentIndex = dragCurrentIndexRef.current;
          if (startIndex === -1 || currentIndex === -1) return;

          const ROW_HEIGHT = 66; // 58px height + 8px margin
          const dy = gestureState.dy;

          // Calculate offset in rows
          const offset = Math.round(dy / ROW_HEIGHT);
          let targetIndex = startIndex + offset;

          // Bound targetIndex
          targetIndex = Math.max(0, Math.min(filteredList.length - 1, targetIndex));

          if (targetIndex !== currentIndex) {
            triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
            // Perform real-time swap in the filtered list
            const newFiltered = [...filteredList];
            const [movedItem] = newFiltered.splice(currentIndex, 1);
            newFiltered.splice(targetIndex, 0, movedItem);

            // Map the new order back to the master list
            let updatedMaster;
            if (filteredList.length === currentMaster.length) {
              updatedMaster = newFiltered;
            } else {
              const filteredSet = new Set(filteredList.map(p => p.name));
              let filteredIdx = 0;
              updatedMaster = currentMaster.map(p => {
                if (filteredSet.has(p.name)) {
                  return newFiltered[filteredIdx++];
                }
                return p;
              });
            }

            // Update ranks and posRanks sequentially in the list, keeping original references where possible to enable React.memo
            const posCounts: Record<string, number> = {};
            const finalMaster = updatedMaster.map((p, idx) => {
              const pos = p.position;
              posCounts[pos] = (posCounts[pos] || 0) + 1;
              const newRank = idx + 1;
              const newPosRank = `${pos}${posCounts[pos]}`;
              if (p.rank === newRank && p.posRank === newPosRank) {
                return p; // Keep original reference
              }
              return {
                ...p,
                rank: newRank,
                posRank: newPosRank,
              };
            });

            // Synchronously update ref and state
            activeMyRanksRef.current = finalMaster;
            setActiveMyRanks(finalMaster);
            dragCurrentIndexRef.current = targetIndex;
          }

          // Apply visual translateY compensation
          const compensation = targetIndex - startIndex;
          dragY.setValue(dy - compensation * ROW_HEIGHT);
        },
        onPanResponderRelease: () => {
          triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
          setSaveStatus('saving');
          // Save the final local rankings to the Zustand store
          setMyRanks(activeMyRanksRef.current);
          
          setDraggedPlayerName(null);
          if (Platform.OS === 'web' && flatListRef.current) {
            const node = flatListRef.current.getScrollableNode() as any;
            if (node) {
              node.style.overflowY = '';
            }
          } else {
            setScrollEnabled(true);
          }
          dragStartIndexRef.current = -1;
          dragCurrentIndexRef.current = -1;
          
          setTimeout(() => {
            setSaveStatus('saved');
          }, 800);
        },
        onPanResponderTerminate: () => {
          setDraggedPlayerName(null);
          if (Platform.OS === 'web' && flatListRef.current) {
            const node = flatListRef.current.getScrollableNode() as any;
            if (node) {
              node.style.overflowY = '';
            }
          } else {
            setScrollEnabled(true);
          }
          dragStartIndexRef.current = -1;
          dragCurrentIndexRef.current = -1;
        }
      });
    }
    return panRespondersMapRef.current[player.name];
  };

  // Dynamic sorting & re-ranking by scoring format
  const rankedPlayers = useMemo(() => {
    const formatKey = format === 'Half-PPR' ? 'halfPpr' : format === 'Standard' ? 'halfPpr' : format === 'Full PPR' ? 'ppr' : 'dynasty';
    const sorted = [...players].sort((a, b) => {
      const rankA = a.ranks?.[formatKey] ?? a.rank;
      const rankB = b.ranks?.[formatKey] ?? b.rank;
      return rankA - rankB;
    });
    
    const posCounts: Record<string, number> = {};
    return sorted.map((player, index) => {
      const pos = player.position;
      posCounts[pos] = (posCounts[pos] || 0) + 1;
      return {
        ...player,
        rank: index + 1,
        posRank: `${pos}${posCounts[pos]}`,
      };
    });
  }, [players, format]);

  // Determine active board players
  const activeBoardPlayers = useMemo(() => {
    if (boardType === 'custom') {
      const draftedMap = new Map(players.map(p => [p.name, p.draftedBy]));
      return activeMyRanks.map(p => ({
        ...p,
        draftedBy: draftedMap.get(p.name) || null
      }));
    }
    return rankedPlayers;
  }, [boardType, activeMyRanks, rankedPlayers, players]);

  // Dynamic position counts including FLEX - based on stable myRanks store state to decouple drag-induced header tab re-renders
  const counts = useMemo(() => {
    const baseList = (boardType === 'custom') ? (myRanks || []) : rankedPlayers;
    return {
      ALL: baseList.length,
      QB: baseList.filter(p => p.position === 'QB').length,
      RB: baseList.filter(p => p.position === 'RB').length,
      WR: baseList.filter(p => p.position === 'WR').length,
      TE: baseList.filter(p => p.position === 'TE').length,
      FLEX: baseList.filter(p => ['RB', 'WR', 'TE'].includes(p.position)).length,
      K: baseList.filter(p => p.position === 'K').length,
      DST: baseList.filter(p => p.position === 'DST').length,
    };
  }, [boardType, myRanks, rankedPlayers]);

  // Filter & search logic with FLEX support and fuzzy matching search suggestions
  const filteredPlayers = useMemo(() => {
    if (boardType === 'custom') {
      const ranksList = activeMyRanks;
      const matchedMyRanks = ranksList.filter((player) => {
        const matchesPosition = positionFilter === 'ALL' || 
          (positionFilter === 'FLEX' ? ['RB', 'WR', 'TE'].includes(player.position) : player.position === positionFilter);
        const matchesSearch = player.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                              player.team.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesPosition && matchesSearch;
      });

      // Find search suggestions from consensus master list (rankedPlayers)
      // Suggest players that are NOT already in activeMyRanks.
      const existingNames = new Set(ranksList.map(p => p.name));
      const suggestions = rankedPlayers
        .filter(player => !existingNames.has(player.name))
        .filter(player => {
          const matchesPosition = positionFilter === 'ALL' || 
            (positionFilter === 'FLEX' ? ['RB', 'WR', 'TE'].includes(player.position) : player.position === positionFilter);
          const matchesSearch = player.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                player.team.toLowerCase().includes(searchQuery.toLowerCase());
          return matchesPosition && matchesSearch;
        });

      let finalSuggestions: any[] = [];
      if (searchQuery.trim() !== '') {
        finalSuggestions = suggestions.map(p => ({ ...p, isSearchSuggestion: true }));
      } else if (ranksList.length === 0) {
        // Blank slate: show top 15 consensus players as suggestions to add
        finalSuggestions = suggestions.slice(0, 15).map(p => ({ ...p, isSearchSuggestion: true }));
      }

      return [...matchedMyRanks, ...finalSuggestions];
    }

    // Consensus Board Mode
    return activeBoardPlayers.filter((player) => {
      const matchesPosition = positionFilter === 'ALL' || 
        (positionFilter === 'FLEX' ? ['RB', 'WR', 'TE'].includes(player.position) : player.position === positionFilter);
      const matchesSearch = player.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            player.team.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesPosition && matchesSearch;
    });
  }, [boardType, activeMyRanks, activeBoardPlayers, rankedPlayers, positionFilter, searchQuery]);

  const filteredPlayersRef = useRef<Player[]>([]);
  useEffect(() => {
    filteredPlayersRef.current = filteredPlayers;
  }, [filteredPlayers]);

  // Back button helper
  const handleBack = () => {
    router.back();
  };

  const handleHome = () => {
    router.replace('/');
  };

  // Helper to add player to custom rankings
  const handleAddPlayerToMyRanks = (player: Player) => {
    const list = activeMyRanks || [];
    if (list.some(p => p.name === player.name)) return;
    
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    setSaveStatus('saving');
    // Create new player entry
    const newPlayer: Player = {
      ...player,
      rank: list.length + 1,
      draftedBy: null,
    };
    
    const newList = [...list, newPlayer];
    setActiveMyRanks(newList);
    setMyRanks(newList);
    
    setTimeout(() => {
      setSaveStatus('saved');
    }, 800);
  };

  // CSV Import Parser
  const parseAndImportCSV = (text: string) => {
    if (!text.trim()) {
      alert("Please paste some rankings first.");
      return;
    }

    const lines = text.split('\n');
    const matchedPlayers: Player[] = [];
    const unmatchedNames: string[] = [];
    const masterPlayers = [...players];

    lines.forEach((line) => {
      let rawName = line.trim();
      if (!rawName) return;

      // Try to split by comma
      const parts = rawName.split(',');
      if (parts.length > 1) {
        // Look at first column. If it is a number, the name is likely in the second column.
        const firstIsNumber = /^\d+$/.test(parts[0].trim());
        if (firstIsNumber) {
          rawName = parts[1].trim();
        } else {
          rawName = parts[0].trim();
        }
      } else {
        // Strip leading number if present (e.g., "1. Christian McCaffrey" or "1) Christian McCaffrey")
        rawName = rawName.replace(/^\d+[\s\.\)\-,\/]+/, '').trim();
      }

      // Remove surrounding quotes
      rawName = rawName.replace(/^["']|["']$/g, '').trim();

      if (!rawName) return;

      // Clean name for lookup
      const cleanLookup = rawName.toLowerCase()
        .replace(/\s+(jr\.|sr\.|iii|ii|iv|v|v\.|ii\.|iii\.|jr|sr)$/g, '')
        .replace(/['`\-\.\s]/g, '');

      // Try to find exact clean match
      let found = masterPlayers.find((p) => {
        const cleanMasterName = p.name.toLowerCase()
          .replace(/\s+(jr\.|sr\.|iii|ii|iv|v|v\.|ii\.|iii\.|jr|sr)$/g, '')
          .replace(/['`\-\.\s]/g, '');
        return cleanMasterName === cleanLookup;
      });

      // If exact clean match fails, try partial/includes match
      if (!found) {
        found = masterPlayers.find((p) => {
          const cleanMasterName = p.name.toLowerCase()
            .replace(/\s+(jr\.|sr\.|iii|ii|iv|v|v\.|ii\.|iii\.|jr|sr)$/g, '')
            .replace(/['`\-\.\s]/g, '');
          return cleanMasterName.includes(cleanLookup) || cleanLookup.includes(cleanMasterName);
        });
      }

      if (found) {
        if (!matchedPlayers.some(p => p.name === found!.name)) {
          matchedPlayers.push(found);
        }
      } else {
        unmatchedNames.push(rawName);
      }
    });

    if (matchedPlayers.length === 0) {
      alert("Could not match any players in the pasted rankings. Please verify the player names.");
      return;
    }

    if (myRanks) {
      setSaveStatus('saving');
      // If we already have initialized myRanks, we keep the existing name
      setMyRanks(matchedPlayers, myRanksName || 'My Custom Cheat Sheet');
      setActiveModal(null);
      setModalText('');
      setTimeout(() => {
        setSaveStatus('saved');
      }, 800);
    } else {
      // If it is a new cheat sheet, prompt for a name first
      setTempImportedPlayers(matchedPlayers);
      setNamingTemplateId('import');
      setCustomSheetName('My Imported Cheat Sheet');
      setActiveModal(null);
      setModalText('');
    }

    if (unmatchedNames.length > 0) {
      alert(`Imported ${matchedPlayers.length} players.\n\nCould not find matches for: ${unmatchedNames.slice(0, 5).join(', ')}${unmatchedNames.length > 5 ? ` and ${unmatchedNames.length - 5} more` : ''}.`);
    }
  };

  // CSV Export String Generator
  const generateExportCSV = (): string => {
    if (!activeMyRanks || activeMyRanks.length === 0) return '';
    const rows = activeMyRanks.map(p => `${p.rank},${p.name},${p.position},${p.team}`);
    return `Rank,Name,Position,Team\n` + rows.join('\n');
  };

  const handleOpenExport = () => {
    const csv = generateExportCSV();
    setModalText(csv);
    setCopyFeedback(false);
    setActiveModal('export');
  };

  const handleOpenImport = () => {
    setModalText('');
    setActiveModal('import');
  };

  const handleCopyToClipboard = () => {
    Clipboard.setString(modalText);
    setCopyFeedback(true);
    setTimeout(() => {
      setCopyFeedback(false);
    }, 2000);
  };

  const handleConfirmNaming = () => {
    const finalName = customSheetName.trim();
    if (!finalName) return;

    setSaveStatus('saving');
    if (namingTemplateId === 'rename') {
      setMyRanks(myRanks || [], finalName);
    } else if (namingTemplateId === 'import') {
      if (tempImportedPlayers) {
        setMyRanks(tempImportedPlayers, finalName);
      }
    } else {
      initializeMyRanks(namingTemplateId!, finalName);
    }

    setNamingTemplateId(null);
    setCustomSheetName('');
    setTempImportedPlayers(null);
    
    setTimeout(() => {
      setSaveStatus('saved');
    }, 800);
  };

  const handleCancelNaming = () => {
    setNamingTemplateId(null);
    setCustomSheetName('');
    setTempImportedPlayers(null);
  };

  const handleResetRankings = useCallback(() => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    const performReset = () => {
      setSaveStatus('saving');
      resetMyRanks();
      setTimeout(() => {
        setSaveStatus('saved');
      }, 800);
    };

    if (Platform.OS === 'web') {
      if (window.confirm("Are you sure you want to reset your cheat sheet? This will restore it to the default Consensus rankings.")) {
        performReset();
      }
    } else {
      Alert.alert(
        "Reset Cheat Sheet",
        "Are you sure you want to reset your cheat sheet? This will restore it to the default Consensus rankings.",
        [
          { text: "Cancel", style: "cancel" },
          { text: "Reset", style: "destructive", onPress: performReset }
        ]
      );
    }
  }, [resetMyRanks]);

  const renderListHeader = useCallback(() => {
    if (boardType !== 'custom') return null;

    return (
      <View style={{ paddingHorizontal: Spacing.four, marginTop: Spacing.two, marginBottom: Spacing.two }}>
        {/* Status banner with Cheat Sheet Name and Edit Icon */}
        <View style={styles.myRanksStatusBanner}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 }}>
            <Text style={styles.myRanksStatusText} numberOfLines={1}>
              {myRanksName || 'My Custom Cheat Sheet'}
            </Text>
            <Pressable 
              onPress={() => {
                triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                setCustomSheetName(myRanksName || 'My Custom Cheat Sheet');
                setNamingTemplateId('rename');
              }}
              style={{ padding: 4 }}
            >
              <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
                <Path d="M11 4H4C2.89543 4 2 4.89543 2 6V20C2 21.1046 2.89543 22 4 22H18C19.1046 22 20 21.1046 20 20V13" stroke={Colors.primaryAccent} strokeWidth={2.5} strokeLinecap="round" />
                <Path d="M18.5 2.5C19.3284 1.67157 20.6716 1.67157 21.5 2.5C22.3284 3.32843 22.3284 4.67157 21.5 5.5L12 15L8 16L9 12L18.5 2.5Z" stroke={Colors.primaryAccent} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
              </Svg>
            </Pressable>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: saveStatus === 'saved' ? '#10b981' : '#f59e0b' }} />
            <Text style={styles.myRanksStatusHint}>
              {saveStatus === 'saving' ? 'Saving...' : 'Auto-Saved'}
            </Text>
          </View>
        </View>

        {/* Action Buttons row */}
        <View style={[styles.actionBar, { marginHorizontal: 0, marginTop: Spacing.two }]}>
          <Pressable 
            style={styles.actionBtn} 
            onPress={() => {
              triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
              handleOpenImport();
            }}
          >
            <Text style={styles.actionBtnText}>IMPORT CSV</Text>
          </Pressable>
          <Pressable 
            style={styles.actionBtn} 
            onPress={() => {
              triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
              handleOpenExport();
            }}
          >
            <Text style={styles.actionBtnText}>EXPORT CSV</Text>
          </Pressable>
          <Pressable 
            style={[styles.actionBtn, styles.actionBtnDanger]} 
            onPress={handleResetRankings}
          >
            <Text style={styles.actionBtnTextDanger}>RESET SHEET</Text>
          </Pressable>
        </View>
      </View>
    );
  }, [boardType, myRanksName, saveStatus, Colors, handleResetRankings]);

  // Render a player item row in high-density table format - memoized with useCallback
  const renderPlayerRow = useCallback(({ item, index }: { item: Player; index: number }) => {
    const isDrafted = item.draftedBy !== null;
    const isSuggestion = (item as any).isSearchSuggestion;

    // Inject dynamic, position-specific Tier Headings based on position tab and index
    let showTierHeader = false;
    let tierLabel = '';
    let tierColor = '#ef4444'; // Red

    if (searchQuery === '' && !isSuggestion) {
      const currentTierInfo = getPlayerTierInfo(item, positionFilter, index);
      if (index === 0) {
        showTierHeader = true;
        tierLabel = currentTierInfo.label;
        tierColor = currentTierInfo.color;
      } else {
        const prevItem = filteredPlayers[index - 1];
        if (prevItem && !(prevItem as any).isSearchSuggestion) {
          const prevTierInfo = getPlayerTierInfo(prevItem, positionFilter, index - 1);
          if (prevTierInfo.tier !== currentTierInfo.tier) {
            showTierHeader = true;
            tierLabel = currentTierInfo.label;
            tierColor = currentTierInfo.color;
          }
        }
      }
    }

    return (
      <PlayerRow
        item={item}
        isCurrentlyDragged={item.name === draggedPlayerName}
        isDrafted={isDrafted}
        isSuggestion={isSuggestion}
        showTierHeader={showTierHeader}
        tierLabel={tierLabel}
        tierColor={tierColor}
        boardType={boardType}
        panHandlers={isSuggestion ? null : getPanResponder(item).panHandlers}
        dragY={dragY}
        onAddPlayer={handleAddPlayerToMyRanks}
        Colors={Colors}
        styles={styles}
      />
    );
  }, [draggedPlayerName, boardType, searchQuery, positionFilter, filteredPlayers, Colors, styles]);

  const templates = [
    { id: 'consensus', name: 'Consensus ECR (Top 250)', desc: 'Pre-populate with the consensus expert rankings' },
    { id: 'Andy', name: "Andy Holloway's Board", desc: "Start with Fantasy Footballers expert Andy Holloway's rankings" },
    { id: 'Mike', name: "Mike Wright's Board", desc: "Start with Fantasy Footballers expert Mike Wright's rankings" },
    { id: 'Jason', name: "Jason Moore's Board", desc: "Start with Fantasy Footballers expert Jason Moore's rankings" },
    { id: 'blank', name: 'Blank Slate', desc: 'Start with a completely empty board and add players manually' },
    { id: 'import', name: 'Import from CSV', desc: 'Paste a list of names or comma-separated rows to load your ranks' }
  ] as const;

  return (
    <View style={styles.container}>
      <BackgroundTexture />
      <SafeAreaView style={styles.safeArea} edges={['top', 'bottom']}>
        
        {/* ABSOLUTE COLLAPSIBLE HEADER CONTAINER */}
        <Animated.View style={[
          styles.headerAbsoluteContainer,
          { transform: [{ translateY: headerTranslateY }] }
        ]}>
          {/* UNIFIED HEADER BAR */}
          <AppHeader
            showBack={true}
            backAction={handleBack}
            title="CHEAT SHEETS"
          />

          {/* BOARD TYPE TOGGLE (CONSENSUS BOARD vs MY CHEAT SHEET) */}
          <View style={styles.boardTypeToggleContainer}>
            <Pressable
              style={[
                styles.boardTypeOption,
                boardType === 'consensus' && styles.activeBoardTypeOption
              ]}
              onPress={() => {
                triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                setBoardType('consensus');
              }}
            >
              <Text
                style={[
                  styles.boardTypeOptionText,
                  boardType === 'consensus' && styles.activeBoardTypeOptionText
                ]}
              >
                CONSENSUS BOARD
              </Text>
            </Pressable>
            <Pressable
              style={[
                styles.boardTypeOption,
                boardType === 'custom' && styles.activeBoardTypeOption
              ]}
              onPress={() => {
                triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                if (!myRanks || myRanks.length === 0) {
                  initializeMyRanks('consensus', 'My Custom Top 250');
                }
                setBoardType('custom');
              }}
            >
              <Text
                style={[
                  styles.boardTypeOptionText,
                  boardType === 'custom' && styles.activeBoardTypeOptionText
                ]}
              >
                MY CHEAT SHEET
              </Text>
            </Pressable>
          </View>

          {/* POSITION CAPSULES SCROLL TAB BAR & SEARCH TOGGLE */}
          <View style={styles.filterAndSearchHeaderRow}>
            {searchVisible ? (
              <View style={styles.inlineSearchWrapper}>
                <Svg width={14} height={14} viewBox="0 0 24 24" fill="none" style={styles.inlineSearchIcon}>
                  <Circle cx={11} cy={11} r={8} stroke="#64748b" strokeWidth={2.5} />
                  <Path d="M21 21L16.65 16.65" stroke="#64748b" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
                </Svg>
                <TextInput
                  style={styles.inlineSearchInput}
                  placeholder="Search players..."
                  placeholderTextColor="#64748b"
                  value={searchQuery}
                  onChangeText={setSearchQuery}
                  autoFocus={true}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                {searchQuery.length > 0 && (
                  <Pressable 
                    onPress={() => {
                      triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                      setSearchQuery('');
                    }} 
                    style={styles.inlineClearBtn}
                  >
                    <Text style={{color: '#64748b', fontSize: 11, fontWeight: '900'}}>✕</Text>
                  </Pressable>
                )}
                <Pressable 
                  style={styles.inlineCancelBtn}
                  onPress={() => {
                    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                    setSearchQuery('');
                    setSearchVisible(false);
                  }}
                >
                  <Text style={styles.inlineCancelText}>Cancel</Text>
                </Pressable>
              </View>
            ) : (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.filterScroll}
                style={styles.filterScrollViewStyle}
              >
                {/* Magnifying Glass Search Toggle on the left of ALL */}
                <Pressable
                  style={styles.searchToggleChip}
                  onPress={() => {
                    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                    setSearchVisible(true);
                  }}
                >
                  <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
                    <Circle cx={11} cy={11} r={8} stroke={Colors.secondaryAccent} strokeWidth={2.5} />
                    <Path d="M21 21L16.65 16.65" stroke={Colors.secondaryAccent} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
                  </Svg>
                </Pressable>

                {(['ALL', 'QB', 'RB', 'WR', 'TE', 'FLEX', 'K', 'DST'] as const).map((pos) => {
                  const active = positionFilter === pos;
                  const count = counts[pos];
                  return (
                    <Pressable
                      key={pos}
                      style={[styles.filterChip, active && styles.activeFilterChip]}
                      onPress={() => {
                        triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                        setPositionFilter(pos);
                      }}
                    >
                      <Text style={[styles.filterChipText, active && styles.activeFilterChipText]}>
                        {pos} <Text style={styles.chipCount}>{count}</Text>
                      </Text>
                    </Pressable>
                  );
                })}
              </ScrollView>
            )}
          </View>
        </Animated.View>

        {/* STICKY TABLE COLUMN HEADERS */}
        <Animated.View style={[
          styles.tableHeaderRow,
          {
            position: 'absolute',
            top: headerMaxHeight,
            left: 0,
            right: 0,
            zIndex: 99,
            transform: [{ translateY: headerTranslateY }],
            backgroundColor: Colors.background,
            marginTop: 0,
            marginBottom: 0,
            paddingBottom: 8,
          }
        ]}>
          <View style={styles.rankHeaderCol}>
            <Text style={styles.tableHeaderLabel}>RK</Text>
          </View>
          <View style={styles.playerHeaderCol}>
            <Text style={styles.tableHeaderLabel}>PLAYER</Text>
          </View>
          <View style={styles.byeHeaderCol}>
            <Text style={styles.tableHeaderLabel}>{boardType === 'custom' ? 'MOVE' : 'BYE'}</Text>
          </View>
        </Animated.View>

        {/* DENSE TABLE FLATLIST */}
        <FlatList
          ref={flatListRef}
          scrollEnabled={scrollEnabled}
          data={filteredPlayers}
          renderItem={renderPlayerRow}
          ListHeaderComponent={renderListHeader}
          keyExtractor={(item) => {
            const isSuggestion = (item as any).isSearchSuggestion;
            return isSuggestion ? `suggest-${item.name}` : `myrank-${item.name}`;
          }}
          contentContainerStyle={[styles.listContent, { paddingTop: headerMaxHeight + 34 }]}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event(
            [{ nativeEvent: { contentOffset: { y: scrollY } } }],
            { useNativeDriver: true }
          )}
          scrollEventThrottle={16}
          ListEmptyComponent={
            <View style={styles.emptyView}>
              <Text style={styles.emptyText}>
                {boardType === 'custom' && (!myRanks || myRanks.length === 0) 
                  ? "Your board is empty. Search above to add players!" 
                  : "No players match your search filter."}
              </Text>
            </View>
          }
        />
        
      </SafeAreaView>

      {/* CSV MODAL OVERLAY */}
      {activeModal !== null && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContentCard}>
            <Text style={styles.modalTitle}>
              {activeModal === 'import' ? 'IMPORT CHEAT SHEET' : 'EXPORT CHEAT SHEET'}
            </Text>
            <Text style={styles.modalDesc}>
              {activeModal === 'import' 
                ? 'Paste a list of player names (one per line) or comma-separated CSV rows. We will fuzzy match them against the database.'
                : 'Copy this text to save your custom rankings elsewhere. You can paste it back to import them anytime.'}
            </Text>
            
            <TextInput
              style={styles.modalTextArea}
              multiline={true}
              numberOfLines={8}
              value={modalText}
              onChangeText={setModalText}
              placeholder={activeModal === 'import' ? 'Paste rankings here...\ne.g.\nChristian McCaffrey\nCeeDee Lamb\n...' : ''}
              placeholderTextColor="#71717a"
              editable={activeModal === 'import'}
              selectTextOnFocus={true}
              autoCapitalize="none"
              autoCorrect={false}
            />
            
            <View style={styles.modalActionRow}>
              {activeModal === 'import' ? (
                <>
                  <Pressable style={[styles.modalBtn, styles.modalBtnPrimary]} onPress={() => parseAndImportCSV(modalText)}>
                    <Text style={styles.modalBtnTextPrimary}>PARSE & IMPORT</Text>
                  </Pressable>
                  <Pressable style={styles.modalBtn} onPress={() => setActiveModal(null)}>
                    <Text style={styles.modalBtnText}>CANCEL</Text>
                  </Pressable>
                </>
              ) : (
                <>
                  <Pressable style={[styles.modalBtn, styles.modalBtnPrimary]} onPress={handleCopyToClipboard}>
                    <Text style={styles.modalBtnTextPrimary}>
                      {copyFeedback ? 'COPIED!' : 'COPY TO CLIPBOARD'}
                    </Text>
                  </Pressable>
                  <Pressable style={styles.modalBtn} onPress={() => setActiveModal(null)}>
                    <Text style={styles.modalBtnText}>CLOSE</Text>
                  </Pressable>
                </>
              )}
            </View>
          </View>
        </View>
      )}

      {/* NAMING COPY MODAL OVERLAY */}
      {namingTemplateId !== null && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContentCard}>
            <Text style={styles.modalTitle}>
              {namingTemplateId === ('rename' as any) ? 'RENAME YOUR CHEAT SHEET' : 'NAME YOUR CHEAT SHEET'}
            </Text>
            <Text style={styles.modalDesc}>
              {namingTemplateId === ('rename' as any)
                ? 'Choose a new name for your personalized cheat sheet.'
                : 'Give your personalized cheat sheet a unique name to start customization. The master list remains locked and protected.'}
            </Text>
            
            <TextInput
              style={styles.modalSingleLineInput}
              value={customSheetName}
              onChangeText={setCustomSheetName}
              placeholder="e.g. My Sleeper Ranks 2026"
              placeholderTextColor="#71717a"
              autoFocus={true}
              autoCapitalize="words"
              autoCorrect={false}
              maxLength={40}
            />
            
            <View style={styles.modalActionRow}>
              <Pressable 
                style={[styles.modalBtn, styles.modalBtnPrimary, !customSheetName.trim() && styles.modalBtnDisabled]} 
                onPress={handleConfirmNaming}
                disabled={!customSheetName.trim()}
              >
                <Text style={[styles.modalBtnTextPrimary, !customSheetName.trim() && styles.modalBtnTextDisabled]}>
                  {namingTemplateId === ('rename' as any) ? 'SAVE NEW NAME' : 'CREATE UNIQUE COPY'}
                </Text>
              </Pressable>
              <Pressable style={styles.modalBtn} onPress={handleCancelNaming}>
                <Text style={styles.modalBtnText}>CANCEL</Text>
              </Pressable>
            </View>
          </View>
        </View>
      )}

      <AppTabBar />
    </View>
  );
}

function createStyles(Colors: typeof LightColors) {
  return StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
    alignSelf: 'center',
    width: '100%',
    maxWidth: MaxContentWidth,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.four,
    paddingVertical: Spacing.two,
    backgroundColor: Colors.background,
    borderBottomWidth: 1,
    borderBottomColor: Colors.coltsNavyLight,
    minHeight: 52,
  },
  backBtn: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
  homeBtn: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'flex-end',
  },
  headerTitleContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontFamily: Fonts.headings,
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    letterSpacing: 1,
  },
  filterWrapper: {
    marginTop: Spacing.three,
  },
  headerAbsoluteContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
    backgroundColor: Colors.background,
    paddingBottom: Spacing.three,
  },
  filterAndSearchHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Spacing.three,
    paddingRight: Spacing.four,
  },
  filterScrollViewStyle: {
    flex: 1,
  },
  searchToggleChip: {
    width: 32,
    height: 28,
    borderRadius: 14,
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 2,
  },
  inlineSearchWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 14,
    height: 28,
    paddingHorizontal: 10,
    marginHorizontal: Spacing.four,
  },
  inlineSearchIcon: {
    marginRight: 6,
  },
  inlineSearchInput: {
    flex: 1,
    fontFamily: Fonts.body,
    fontSize: 12,
    color: '#ffffff',
    padding: 0,
    height: '100%',
  },
  inlineClearBtn: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 4,
  },
  inlineCancelBtn: {
    paddingLeft: 12,
    justifyContent: 'center',
    height: '100%',
  },
  inlineCancelText: {
    fontFamily: Fonts.stats,
    fontSize: 11,
    color: Colors.secondaryAccent,
    fontWeight: '700',
  },
  filterScroll: {
    paddingHorizontal: Spacing.four,
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 12,
    height: 28,
    borderRadius: 14,
    backgroundColor: Colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.coltsNavyLight,
  },
  activeFilterChip: {
    backgroundColor: Colors.secondaryAccent,
    borderColor: Colors.secondaryAccent,
    borderWidth: 1,
  },
  filterChipText: {
    fontFamily: Fonts.stats,
    fontSize: 10,
    color: Colors.secondaryAccent,
    fontWeight: '700',
  },
  activeFilterChipText: {
    color: Colors.primaryAccent === '#2c2c2c' ? '#ffffff' : '#000000',
  },
  chipCount: {
    fontSize: 9,
    opacity: 0.8,
    marginLeft: 2,
  },
  tableHeaderRow: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.four,
    marginTop: Spacing.three,
    borderBottomWidth: 1,
    borderBottomColor: Colors.surfaceLifted,
    paddingBottom: 8,
    marginBottom: 8,
  },
  tableHeaderLabel: {
    fontFamily: Fonts.stats,
    fontSize: 10,
    color: Colors.secondaryAccent,
    fontWeight: 'bold',
  },
  listContent: {
    paddingHorizontal: Spacing.four,
    paddingBottom: 120,
  },
  rankingsRowItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.glassSurface,
    borderColor: Colors.glassBorder,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: Spacing.two,
    gap: 8,
    height: 58,
    marginBottom: 8,
    shadowColor: Colors.shadows.shadowColor,
    shadowOffset: Colors.shadows.shadowOffset,
    shadowOpacity: Colors.shadows.shadowOpacity,
    shadowRadius: Colors.shadows.shadowRadius,
    elevation: Colors.shadows.elevation,
  },
  rankingsRowItemDrafted: {
    opacity: 0.4,
    backgroundColor: 'rgba(24, 24, 27, 0.5)',
  },
  rankingsRowItemSuggestion: {
    borderColor: 'rgba(63, 63, 70, 0.5)',
    backgroundColor: 'rgba(24, 24, 27, 0.3)',
  },
  rankingsRowLeftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  normalRankSquare: {
    width: 36,
    height: 20,
    borderRadius: 5,
    backgroundColor: Colors.surfaceLifted,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.coltsNavyLight,
  },
  normalRankText: {
    fontFamily: Fonts.stats,
    fontSize: 10,
    color: Colors.secondaryAccent,
    fontWeight: 'bold',
  },
  posRankBadge: {
    width: 36,
    height: 20,
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  posRankBadgeText: {
    fontFamily: Fonts.stats,
    fontSize: 8.5,
    color: '#000000',
    fontWeight: '900',
  },
  rankingsRowHeadshot: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },
  rankingsRowInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  rankingsRowName: {
    fontFamily: Fonts.body,
    fontSize: 13,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
  },
  rankingsRowMeta: {
    fontFamily: Fonts.body,
    fontSize: 10,
    color: Colors.secondaryAccent,
  },
  tierHeader: {
    borderBottomWidth: 1.5,
    paddingBottom: 4,
    marginTop: Spacing.two,
    marginBottom: Spacing.one,
  },
  tierHeaderText: {
    fontFamily: Fonts.stats,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 2,
  },
  rankCol: {
    width: 76,
    justifyContent: 'center',
  },
  playerCol: {
    flex: 1,
    justifyContent: 'center',
  },
  byeCol: {
    width: 64,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankHeaderCol: {
    width: 76,
    alignItems: 'center',
    justifyContent: 'center',
  },
  playerHeaderCol: {
    flex: 1,
    paddingLeft: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  byeHeaderCol: {
    width: 64,
    alignItems: 'center',
    justifyContent: 'center',
  },
  byeTag: {
    backgroundColor: Colors.surfaceLifted,
    borderWidth: 1,
    borderColor: Colors.coltsNavyLight,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
    minWidth: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  playerNameDrafted: {
    textDecorationLine: 'line-through',
    opacity: 0.6,
  },
  byeText: {
    fontFamily: Fonts.stats,
    fontSize: 10.5,
    color: Colors.secondaryAccent,
    fontWeight: 'bold',
  },
  emptyView: {
    alignItems: 'center',
    paddingVertical: Spacing.five,
  },
  emptyText: {
    fontFamily: Fonts.body,
    fontSize: 14,
    color: Colors.secondaryAccent,
  },
  formatToggleContainer: {
    flexDirection: 'row',
    backgroundColor: Colors.surface,
    borderRadius: 20,
    marginHorizontal: Spacing.four,
    marginTop: Spacing.three,
    padding: 3,
    borderWidth: 1,
    borderColor: Colors.coltsNavyLight,
  },
  formatToggleOption: {
    flex: 1,
    height: 32,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeFormatToggleOption: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  formatToggleText: {
    fontFamily: Fonts.stats,
    fontSize: 11,
    color: Colors.secondaryAccent,
    fontWeight: '700',
  },
  activeFormatToggleText: {
    color: '#ffffff',
  },
  reorderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    width: 64,
    justifyContent: 'center',
  },
  dragHandleSquare: {
    width: 32,
    height: 32,
    borderRadius: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    ...Platform.select({
      web: {
        cursor: 'grab',
        userSelect: 'none',
        touchAction: 'none',
      },
      default: {},
    }),
  },
  rankingsRowItemDragging: {
    backgroundColor: '#27272a',
    borderColor: '#ffffff',
    borderWidth: 1.5,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
    opacity: 0.95,
    ...Platform.select({
      web: {
        cursor: 'grabbing',
        touchAction: 'none',
      },
      default: {},
    }),
  },
  reorderBtn: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  reorderBtnDisabled: {
    opacity: 0.3,
  },
  boardTypeToggleContainer: {
    flexDirection: 'row',
    backgroundColor: '#18181b',
    borderRadius: 8,
    marginHorizontal: Spacing.four,
    marginTop: Spacing.three,
    padding: 3,
    borderWidth: 1,
    borderColor: '#27272a',
  },
  boardTypeOption: {
    flex: 1,
    height: 36,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeBoardTypeOption: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  boardTypeOptionText: {
    fontFamily: Fonts.stats,
    fontSize: 11,
    color: '#71717a',
    fontWeight: '700',
    letterSpacing: 1,
  },
  activeBoardTypeOptionText: {
    color: '#ffffff',
  },
  ctaScrollView: {
    flex: 1,
    marginTop: Spacing.two,
  },
  ctaContainer: {
    paddingHorizontal: Spacing.four,
    paddingBottom: 120,
    justifyContent: 'center',
    alignItems: 'center',
    flexGrow: 1,
  },
  ctaCard: {
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: Spacing.three,
    paddingVertical: Spacing.three,
    alignItems: 'center',
    width: '100%',
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 8,
  },
  ctaHeaderContainer: {
    display: 'none',
  },
  ctaTitle: {
    fontFamily: Fonts.headings,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
    letterSpacing: 1,
    marginBottom: Spacing.three,
  },
  ctaDesc: {
    display: 'none',
  },
  templatesWrapper: {
    width: '100%',
    gap: 8,
  },
  templateOptionCard: {
    width: '100%',
    backgroundColor: Colors.surfaceLifted,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  templateOptionInfo: {
    flex: 1,
    marginRight: 12,
  },
  templateOptionName: {
    fontFamily: Fonts.body,
    fontSize: 12.5,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
    marginBottom: 2,
  },
  templateOptionDesc: {
    fontFamily: Fonts.body,
    fontSize: 10,
    color: Colors.secondaryAccent,
    lineHeight: 13,
  },
  templateOptionArrow: {
    opacity: 0.6,
  },
  myRanksActionsWrapper: {
    marginHorizontal: Spacing.four,
    marginTop: Spacing.three,
    gap: 10,
  },
  primaryActionsRow: {
    flexDirection: 'row',
    gap: 10,
  },
  primaryActionBtn: {
    flex: 1,
    height: 40,
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  },
  renameBtn: {
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
  },
  useInDraftBtn: {
    backgroundColor: Colors.hofYellow,
    borderColor: Colors.hofYellow,
  },
  primaryActionBtnText: {
    fontFamily: Fonts.headings,
    fontSize: 12,
    fontWeight: 'bold',
    color: Colors.primaryAccent, // Dark text for rename button
    letterSpacing: 1,
  },
  primaryActionBtnTextDark: {
    fontFamily: Fonts.headings,
    fontSize: 12,
    fontWeight: 'bold',
    color: '#000000', // Solid black text on yellow button for perfect contrast (12.6:1)
    letterSpacing: 1,
  },
  secondaryActionsRow: {
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'space-between',
  },
  secondaryActionBtn: {
    flex: 1,
    height: 32,
    borderRadius: 6,
    backgroundColor: Colors.surfaceLifted,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  secondaryActionBtnText: {
    fontFamily: Fonts.stats,
    fontSize: 9,
    fontWeight: 'bold',
    color: Colors.secondaryAccent,
    letterSpacing: 0.5,
  },
  myRanksStatusBanner: {
    backgroundColor: Colors.surfaceLifted,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 2,
    flexWrap: 'wrap',
    gap: 6,
  },
  myRanksStatusText: {
    fontFamily: Fonts.body,
    fontSize: 11,
    fontWeight: '600',
    color: Colors.primaryAccent,
  },
  myRanksStatusHint: {
    fontFamily: Fonts.body,
    fontSize: 10,
    color: '#10b981',
    fontWeight: '500',
  },
  actionBar: {
    flexDirection: 'row',
    marginHorizontal: Spacing.four,
    marginTop: Spacing.three,
    gap: 8,
    justifyContent: 'space-between',
  },
  actionBtn: {
    flex: 1,
    height: 34,
    borderRadius: 6,
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionBtnDanger: {
    borderColor: 'rgba(239, 68, 68, 0.4)',
    backgroundColor: 'rgba(239, 68, 68, 0.05)',
  },
  actionBtnText: {
    fontFamily: Fonts.stats,
    fontSize: 9.5,
    fontWeight: 'bold',
    color: '#ffffff',
    letterSpacing: 0.5,
  },
  actionBtnTextDanger: {
    fontFamily: Fonts.stats,
    fontSize: 9.5,
    fontWeight: 'bold',
    color: '#ef4444',
    letterSpacing: 0.5,
  },
  addBtn: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 1,
    borderRadius: 6,
    height: 28,
    paddingHorizontal: 12,
    justifyContent: 'center',
    alignItems: 'center',
    width: 64,
  },
  addBtnText: {
    fontFamily: Fonts.stats,
    fontSize: 9,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  modalOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(9, 9, 11, 0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.four,
    zIndex: 1000,
  },
  modalContentCard: {
    backgroundColor: '#18181b',
    borderColor: '#27272a',
    borderWidth: 1,
    borderRadius: 12,
    padding: Spacing.four,
    width: '100%',
    maxWidth: 500,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 10,
  },
  modalTitle: {
    fontFamily: Fonts.headings,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
    letterSpacing: 1,
    marginBottom: 8,
  },
  modalDesc: {
    fontFamily: Fonts.body,
    fontSize: 11,
    color: '#a1a1aa',
    lineHeight: 16,
    marginBottom: Spacing.three,
  },
  modalTextArea: {
    backgroundColor: Colors.surfaceLifted,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    color: Colors.primaryAccent,
    fontFamily: Fonts.stats,
    fontSize: 11,
    height: 160,
    textAlignVertical: 'top',
    marginBottom: Spacing.four,
  },
  modalActionRow: {
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'flex-end',
  },
  modalBtn: {
    height: 38,
    borderRadius: 6,
    paddingHorizontal: 16,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.surfaceLifted,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
  },
  modalBtnPrimary: {
    backgroundColor: Colors.coltsNavy, // Primary action Colts Blue
    borderColor: Colors.coltsNavy,
    flex: 1,
  },
  modalBtnText: {
    fontFamily: Fonts.stats,
    fontSize: 10,
    fontWeight: 'bold',
    color: Colors.secondaryAccent,
  },
  modalBtnTextPrimary: {
    fontFamily: Fonts.stats,
    fontSize: 10,
    fontWeight: 'bold',
    color: '#ffffff', // High contrast white text on Colts Blue
  },
  modalSingleLineInput: {
    backgroundColor: Colors.surfaceLifted,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: Colors.primaryAccent,
    fontFamily: Fonts.body,
    fontSize: 13,
    marginBottom: Spacing.four,
  },
  modalBtnDisabled: {
    backgroundColor: '#27272a',
    borderColor: '#27272a',
  },
  modalBtnTextDisabled: {
    color: '#71717a',
  },
  fabContainer: {
    position: 'absolute',
    bottom: Platform.OS === 'ios' ? 104 : 96,
    right: 16,
    zIndex: 999999,
  },
  fabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.hofYellow,
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 30,
    borderWidth: 1.5,
    borderColor: '#ffffff',
    minHeight: 48,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 6,
  },
  fabButtonPressed: {
    opacity: 0.9,
  },
  fabText: {
    fontFamily: Fonts.headings,
    fontSize: 14,
    fontWeight: 'bold',
    color: '#040b1f',
    letterSpacing: 0.8,
  },
});
}

const lightStyles = createStyles(LightColors);
const darkStyles = createStyles(DarkColors as any);
const styles = new Proxy({}, {
  get(target, prop) {
    const theme = useThemeStore.getState().theme;
    return theme === 'dark' ? darkStyles[prop as keyof typeof darkStyles] : lightStyles[prop as keyof typeof lightStyles];
  }
}) as ReturnType<typeof createStyles>;
