# Implementation Plan: Fix Swipe-Down Gesture Reset & Layout Collapse

We will resolve the critical bug where swiping down to minimize the player suggestions bottom sheet in `active.tsx` clears the draft board, resets the draft room state, and triggers a "cpu is picking" lock. 

---

## User Review Required

> [!IMPORTANT]
> **Defensive Gesture Clamping**:
> We will clamp the bottom sheet height dynamically during vertical drag interactions. The sheet height will strictly satisfy `80 <= height <= SCREEN_HEIGHT * 0.92`.
> This completely prevents negative CSS layout heights and margins in `react-native-web` (which causes layout engine panic and unmount/state resets).
>
> **PanResponder Termination Handlers**:
> Consistent with Apple HIG fluid physics-based motion guidelines, we will implement custom termination handlers. If a gesture is interrupted (such as during viewport scrolls or drag bounces), the bottom sheet will smoothly snap back to its target resting height.
>
> **Setup-State Redirect safety net**:
> If the draft engine is ever reset (or the browser reloaded), `draftStatus` transitions to `'setup'`. We will add a reactive redirect hook in `active.tsx` that immediately sends the user to `/wizard/setup` rather than leaving them stranded on a blank draft room saying "cpu is picking".

---

## Proposed Changes

### 1. Gesture Clamping & PanResponder Refinement
#### [MODIFY] [active.tsx](file:///c:/Users/loubr/.gemini/antigravity/scratch/snap-count/src/app/wizard/active.tsx)

- **Move handler clamp**:
  - In `onPanResponderMove`, clamp `newHeight` immediately to prevent any values below `80` (collapsed height) or above `SCREEN_HEIGHT * 0.92` (full height).
  ```typescript
  // Clamp values to prevent negative heights or out of bounds layout issues
  const clampedHeight = Math.max(80, Math.min(fullHeight, newHeight));
  sheetHeightAnim.setValue(clampedHeight);
  ```

- **Add termination handlers**:
  - Implement `onPanResponderTerminationRequest` to return `true`.
  - Implement `onPanResponderTerminate` to cleanly animate the sheet to its target height (either `80` or `fullHeight`) based on the active `sheetModeRef.current` mode.

- **Add Draft Setup Redirect**:
  - Add a dedicated `useEffect` hook to redirect the user to `/wizard/setup` if `draftStatus === 'setup'` is ever detected.

### 2. Store Verification Logging
#### [MODIFY] [useMockMaxxingStore.ts](file:///c:/Users/loubr/.gemini/antigravity/scratch/snap-count/src/store/useMockMaxxingStore.ts)

- **Draft Reset Trace**:
  - Add standard console log tracing to `resetDraft` inside the store to help trace if it is ever triggered during a layout render sweep.

---

## Verification Plan

### Automated Tests
- Run typescript validation check:
  ```powershell
  node node_modules/typescript/bin/tsc --noEmit
  ```

### Manual Verification
1. Launch Metro server and open the mobile web simulator in Chrome.
2. Select a pick position and click **"MOCK NOW"** to start drafting.
3. Open the player suggestions sheet fully (`sheetMode = 'full'`).
4. Perform a fast manual swipe-down gesture starting from the sheet header to the bottom of the screen.
5. Verify that the sheet collapses cleanly and animates to exactly `80px` height.
6. Verify that the draft board remains fully populated, the pick number stays correct, and the header says "Your Pick" when it is the user's turn.
7. Attempt to drag the sheet handle far off the bottom of the screen (simulating excessive swipe-down distance). Verify that the sheet is strictly clamped at the `80px` boundary without any layout collapse or crash.
