import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { StyleSheet, View, Text, Pressable, ScrollView, Image, Dimensions, ActivityIndicator, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useMockMaxxingStore, getTeamNameForIndex, getUserTeamName } from '@/store/useMockMaxxingStore';
import { getTeamLogoUrl } from '@/store/mockData';
import { Colors, Fonts, Spacing, MaxContentWidth, useColors, LightColors, DarkColors } from '@/constants/theme';
import { useThemeStore } from '@/store/useThemeStore';
import BackgroundTexture from '@/components/BackgroundTexture';
import AppHeader from '@/components/AppHeader';
import Svg, { Path, Circle, Line, Text as SvgText, Defs, LinearGradient, Stop } from 'react-native-svg';
import * as Haptics from 'expo-haptics';

const SCREEN_WIDTH = Dimensions.get('window').width;

// Helper to format player names cleanly to First Initial + Last Name
const getDisplayName = (name: string) => {
  const parts = name.trim().split(/\s+/);
  if (parts.length > 1) {
    const suffixes = ['jr', 'sr', 'ii', 'iii', 'iv', 'v', 'jr.', 'sr.'];
    const lastPart = parts[parts.length - 1].toLowerCase();
    if (suffixes.includes(lastPart) && parts.length > 2) {
      return `${parts[0][0]}. ${parts[parts.length - 2]} ${parts[parts.length - 1]}`;
    }
    return `${parts[0][0]}. ${parts.slice(1).join(' ')}`;
  }
  return name;
};

// Map players to direct ESPN player IDs for premium headshots
const getPlayerHeadshotUrl = (espnId: number | null, position: string, team?: string) => {
  if (position === 'DST' && team) {
    return getTeamLogoUrl(team);
  }
  if (espnId) {
    return `https://a.espncdn.com/i/headshots/nfl/players/full/${espnId}.png`;
  }
  return `https://a.espncdn.com/combiner/i?img=/i/headshots/nfl/players/full/default.png&w=350&h=254`;
};

// Format number with commas
const formatNumber = (num: number) => {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};

// Generate highly realistic season projections based on position and projected points
const getPlayerProjections = (player: any) => {
  const pts = player.projectedPoints || 0;
  const ppg = Math.round(pts / 17);
  if (player.position === 'QB') {
    const yds = Math.round(pts * 12.5);
    const tds = Math.round(pts * 0.085);
    return `${formatNumber(yds)} Yds · ${tds} TD · ${ppg} PPG`;
  }
  if (player.position === 'RB') {
    const yds = Math.round(pts * 4.2 + 200);
    const tds = Math.round(pts * 0.038);
    return `${formatNumber(yds)} Yds · ${tds} TD · ${ppg} PPG`;
  }
  if (player.position === 'WR') {
    const yds = Math.round(pts * 4.5 + 100);
    const tds = Math.round(pts * 0.032);
    return `${formatNumber(yds)} Yds · ${tds} TD · ${ppg} PPG`;
  }
  if (player.position === 'TE') {
    const yds = Math.round(pts * 4.8);
    const tds = Math.round(pts * 0.042);
    return `${formatNumber(yds)} Yds · ${tds} TD · ${ppg} PPG`;
  }
  if (player.position === 'K') {
    const fg = Math.round(pts * 0.22);
    const xp = Math.round(pts * 0.26);
    return `${fg} FG · ${xp} XP · ${ppg} PPG`;
  }
  if (player.position === 'DST' || player.position === 'DEF') {
    const sck = Math.round(pts * 0.35);
    const ints = Math.round(pts * 0.12);
    return `${sck} Sck · ${ints} Int · ${ppg} PPG`;
  }
  return `${pts} Pts · ${ppg} PPG`;
};

const getSlotBgColor = (label: string) => {
  if (label === 'W/R/T') return '#334155';
  if (label === 'DEF') return Colors.positions.DST;
  if (label === 'BN') return '#27272a';
  if (label === 'IR') return '#18181b';
  return Colors.positions[label as keyof typeof Colors.positions] || '#475569';
};

const getSlotTextColor = (label: string) => {
  if (label === 'BN' || label === 'IR' || label === 'W/R/T') return '#e2e8f0';
  return '#000000';
};

const getGradeLetterFromPoints = (pts: number): string => {
  if (pts >= 11.5) return 'A+';
  if (pts >= 10.5) return 'A';
  if (pts >= 9.5) return 'A-';
  if (pts >= 8.5) return 'B+';
  if (pts >= 7.5) return 'B';
  if (pts >= 6.5) return 'B-';
  if (pts >= 5.5) return 'C+';
  if (pts >= 4.5) return 'C';
  if (pts >= 3.5) return 'C-';
  if (pts >= 2.5) return 'D+';
  if (pts >= 1.5) return 'D';
  return 'F';
};

const getGradePoints = (grade: string): number => {
  switch (grade) {
    case 'A+': return 12;
    case 'A': return 11;
    case 'A-': return 10;
    case 'B+': return 9;
    case 'B': return 8;
    case 'B-': return 7;
    case 'C+': return 6;
    case 'C': return 5;
    case 'C-': return 4;
    case 'D+': return 3;
    case 'D': return 2;
    default: return 0;
  }
};

export default function DraftSummaryScreen() {
  const Colors = useColors();
  const router = useRouter();
  
  const triggerHaptic = async (style = Haptics.ImpactFeedbackStyle.Light) => {
    if (Platform.OS !== 'web') {
      try {
        await Haptics.impactAsync(style);
      } catch (err) {
        console.warn('Haptics failed:', err);
      }
    }
  };

  const setup = useMockMaxxingStore((state) => state.setup);
  const resetDraft = useMockMaxxingStore((state) => state.resetDraft);
  const getDraftGrade = useMockMaxxingStore((state) => state.getDraftGrade);
  const getUserRoster = useMockMaxxingStore((state) => state.getUserRoster);
  const draftHistory = useMockMaxxingStore((state) => state.draftHistory);
  const historicalDrafts = useMockMaxxingStore((state) => state.historicalDrafts || []);
  const botTrainingSims = useMockMaxxingStore((state) => state.botTrainingSims || 0);
  
  const populateHistory = useMockMaxxingStore((state) => state.populateHistory);
  const clearHistory = useMockMaxxingStore((state) => state.clearHistory);
  const runBotSelfImprovementTraining = useMockMaxxingStore((state) => state.runBotSelfImprovementTraining);

  const [activeTab, setActiveTab] = useState<'roster' | 'coach' | 'performance' | 'leaderboard' | 'board'>('roster');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [simProgress, setSimProgress] = useState(0);

  const [exploreIdx, setExploreIdx] = useState<number | null>(null);

  // Auto-reset explore state back to standard after two seconds of idle
  useEffect(() => {
    if (exploreIdx !== null) {
      const timer = setTimeout(() => {
        setExploreIdx(null);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [exploreIdx]);

  const runSimulationBatches = useCallback((totalCount: number) => {
    setIsSimulating(true);
    setSimProgress(0);
    let currentCount = 0;
    const batchSize = 250;
    const runBatch = () => {
      if (currentCount >= totalCount) {
        setIsSimulating(false);
        setSimProgress(100);
        return;
      }
      populateHistory(batchSize);
      currentCount += batchSize;
      setSimProgress(Math.min(100, Math.round((currentCount / totalCount) * 100)));
      setTimeout(runBatch, 16);
    };
    setTimeout(runBatch, 50);
  }, [populateHistory]);

  // Trigger auto prepopulate of 5,000 simulations if history is empty
  useEffect(() => {
    if (historicalDrafts.length === 0 && !isSimulating) {
      runSimulationBatches(5000);
    }
  }, [historicalDrafts.length, isSimulating, runSimulationBatches]);

  const roster = useMemo(() => {
    return getUserRoster();
  }, [getUserRoster]);

  const { grade, valueScore, playoffChance, projectedWins, projectedLosses } = useMemo(() => {
    return getDraftGrade();
  }, [getDraftGrade]);

  const isHOF = grade === 'A+';

  const handleRestart = () => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    resetDraft();
    router.replace('/wizard/setup');
  };

  const handleHome = () => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    resetDraft();
    router.replace('/');
  };

  // Helper to extract exact draft pick number for active draft
  const getUserPickNumber = (playerName: string) => {
    const pickObj = draftHistory.find(h => h.player.name === playerName);
    return pickObj ? pickObj.pickNumber : '-';
  };

  // Group active roster into slots mirroring active.tsx layout
  const rosterSlots = useMemo(() => {
    const slots: {
      id: string;
      label: string;
      allowedPositions: string[];
      player: any | null;
    }[] = [
      { id: 'QB', label: 'QB', allowedPositions: ['QB'], player: null },
      { id: 'WR1', label: 'WR', allowedPositions: ['WR'], player: null },
      { id: 'WR2', label: 'WR', allowedPositions: ['WR'], player: null },
      { id: 'RB1', label: 'RB', allowedPositions: ['RB'], player: null },
      { id: 'RB2', label: 'RB', allowedPositions: ['RB'], player: null },
      { id: 'TE', label: 'TE', allowedPositions: ['TE'], player: null },
    ];

    const maxFlex = setup.flexCount ?? 1;
    for (let f = 1; f <= maxFlex; f++) {
      slots.push({ id: `FLEX${f}`, label: 'W/R/T', allowedPositions: ['WR', 'RB', 'TE'], player: null });
    }

    slots.push(
      { id: 'K', label: 'K', allowedPositions: ['K'], player: null },
      { id: 'DEF', label: 'DEF', allowedPositions: ['DST'], player: null },
      { id: 'BN1', label: 'BN', allowedPositions: ['QB', 'WR', 'RB', 'TE', 'K', 'DST'], player: null },
      { id: 'BN2', label: 'BN', allowedPositions: ['QB', 'WR', 'RB', 'TE', 'K', 'DST'], player: null },
      { id: 'BN3', label: 'BN', allowedPositions: ['QB', 'WR', 'RB', 'TE', 'K', 'DST'], player: null },
      { id: 'BN4', label: 'BN', allowedPositions: ['QB', 'WR', 'RB', 'TE', 'K', 'DST'], player: null },
      { id: 'BN5', label: 'BN', allowedPositions: ['QB', 'WR', 'RB', 'TE', 'K', 'DST'], player: null },
      { id: 'BN6', label: 'BN', allowedPositions: ['QB', 'WR', 'RB', 'TE', 'K', 'DST'], player: null }
    );

    const pool = [...roster];
    // Pass 1: Starters (QB, WR1/2, RB1/2, TE, K, DEF)
    for (let i = 0; i < pool.length; i++) {
      const p = pool[i];
      let assigned = false;
      if (p.position === 'QB') {
        const slot = slots.find(s => s.id === 'QB' && !s.player);
        if (slot) { slot.player = p; assigned = true; }
      } else if (p.position === 'WR') {
        const slot = slots.find(s => (s.id === 'WR1' || s.id === 'WR2') && !s.player);
        if (slot) { slot.player = p; assigned = true; }
      } else if (p.position === 'RB') {
        const slot = slots.find(s => (s.id === 'RB1' || s.id === 'RB2') && !s.player);
        if (slot) { slot.player = p; assigned = true; }
      } else if (p.position === 'TE') {
        const slot = slots.find(s => s.id === 'TE' && !s.player);
        if (slot) { slot.player = p; assigned = true; }
      } else if (p.position === 'K') {
        const slot = slots.find(s => s.id === 'K' && !s.player);
        if (slot) { slot.player = p; assigned = true; }
      } else if (p.position === 'DST' || p.position === 'DEF') {
        const slot = slots.find(s => s.id === 'DEF' && !s.player);
        if (slot) { slot.player = p; assigned = true; }
      }

      if (assigned) {
        pool.splice(i, 1);
        i--;
      }
    }

    // Pass 2: FLEX slots (W/R/T)
    for (let i = 0; i < pool.length; i++) {
      const p = pool[i];
      if (p.position === 'WR' || p.position === 'RB' || p.position === 'TE') {
        const slot = slots.find(s => s.id.startsWith('FLEX') && !s.player);
        if (slot) {
          slot.player = p;
          pool.splice(i, 1);
          i--;
        }
      }
    }

    // Pass 3: Bench (BN1-BN6)
    for (let i = 0; i < pool.length; i++) {
      const p = pool[i];
      const slot = slots.find(s => s.id.startsWith('BN') && !s.player);
      if (slot) {
        slot.player = p;
        pool.splice(i, 1);
        i--;
      }
    }

    return slots;
  }, [roster, setup.flexCount]);

  const starters = useMemo(() => rosterSlots.filter(s => !s.id.startsWith('BN')), [rosterSlots]);
  const bench = useMemo(() => rosterSlots.filter(s => s.id.startsWith('BN')), [rosterSlots]);

  // Positional bye conflicts
  const positionByeCounts = useMemo(() => {
    const counts: { [pos: string]: { [bye: number]: number } } = {};
    roster.forEach(player => {
      const pos = player.position;
      const bye = player.bye;
      if (!counts[pos]) counts[pos] = {};
      counts[pos][bye] = (counts[pos][bye] || 0) + 1;
    });
    return counts;
  }, [roster]);

  // ADVANCED METRICS CALCULATIONS
  const getPositionGrade = (pos: string) => {
    const totalPts = roster.filter(p => p.position === pos).reduce((sum, p) => sum + p.projectedPoints, 0);
    if (pos === 'QB') {
      if (totalPts > 320) return 'A+';
      if (totalPts > 295) return 'A';
      if (totalPts > 270) return 'B+';
      if (totalPts > 245) return 'B';
      return 'C';
    }
    if (pos === 'RB') {
      if (totalPts > 470) return 'A+';
      if (totalPts > 390) return 'A';
      if (totalPts > 310) return 'B+';
      if (totalPts > 240) return 'B';
      return 'C';
    }
    if (pos === 'WR') {
      if (totalPts > 500) return 'A+';
      if (totalPts > 410) return 'A';
      if (totalPts > 330) return 'B+';
      if (totalPts > 250) return 'B';
      return 'C';
    }
    if (pos === 'TE') {
      if (totalPts > 175) return 'A+';
      if (totalPts > 145) return 'A';
      if (totalPts > 115) return 'B+';
      if (totalPts > 90) return 'B';
      return 'C';
    }
    return 'B';
  };

  const getPositionPPG = (pos: string) => {
    const totalPts = roster.filter(p => p.position === pos).reduce((sum, p) => sum + p.projectedPoints, 0);
    return Math.round(totalPts / 17);
  };

  const byeConflictCount = useMemo(() => {
    let conflicts = 0;
    Object.keys(positionByeCounts).forEach(pos => {
      Object.keys(positionByeCounts[pos]).forEach(bye => {
        if (positionByeCounts[pos][Number(bye)] >= 2) {
          conflicts++;
        }
      });
    });
    return conflicts;
  }, [positionByeCounts]);

  const getByeScore = () => {
    if (byeConflictCount === 0) return 100;
    if (byeConflictCount === 1) return 85;
    if (byeConflictCount === 2) return 65;
    return 45;
  };

  const getStarterBenchRatio = () => {
    const starterPts = starters.reduce((sum, s) => sum + (s.player ? s.player.projectedPoints : 0), 0);
    const benchPts = bench.reduce((sum, b) => sum + (b.player ? b.player.projectedPoints : 0), 0);
    return benchPts > 0 ? `${Math.round(starterPts / benchPts)}x` : 'N/A';
  };

  // DRAFT COACH STRATEGY INSIGHTS & ALTERATIONS
  const coachStrategyAnalysis = useMemo(() => {
    const selectedStrat = setup.userStrategy || 'Balanced';
    const firstFivePicks = draftHistory.filter(h => h.teamName === getUserTeamName() || h.teamName === 'Your Team').slice(0, 5);
    const firstFiveRBs = firstFivePicks.filter(p => p.player.position === 'RB');
    const firstFiveWRs = firstFivePicks.filter(p => p.player.position === 'WR');
    const qbPickedEarly = firstFivePicks.find(p => p.player.position === 'QB');
    const tePickedEarly = firstFivePicks.find(p => p.player.position === 'TE');

    let feedback = '';
    let success = false;
    let suggestions: string[] = [];

    if (selectedStrat === 'Zero RB') {
      const rbCount = firstFiveRBs.length;
      if (rbCount > 0) {
        success = false;
        feedback = `You declared a "Zero RB" draft strategy but drafted ${rbCount} RB(s) in your first 5 picks. This violates the core design of Zero RB, which demands hoarding elite receivers early to build an insurmountable weekly advantage at WR/TE.`;
        suggestions = [
          "Avoid any running backs in rounds 1 through 5, even if they slip past ADP.",
          "Target three high-ceiling starting WRs and an elite TE in the initial 4 rounds.",
          "Stack late-round RBs (Round 6+) who have high injury-contingent upside to secure starting jobs later."
        ];
      } else {
        success = true;
        feedback = `Masterful Zero RB execution! You passed on early running backs entirely and drafted 0 RBs in the first 5 rounds. By locking in dominant, reliable high-end receivers, you secured a massive baseline advantage in passing volume.`;
        suggestions = [
          "Continue exploiting this strategy in high-volume passing environments.",
          "Keep an eye on premium backups during pre-season to grab cheap handcuffs.",
          "Maintain a waiver-wire bias towards high-value backup running backs."
        ];
      }
    } else if (selectedStrat === 'Hero RB') {
      const rbCount = firstFiveRBs.length;
      const earlyRB = firstFivePicks.slice(0, 2).filter(p => p.player.position === 'RB').length;
      if (earlyRB === 1 && rbCount === 1) {
        success = true;
        feedback = `Perfect Hero RB execution! You drafted exactly one elite anchor RB in your first 2 picks, and zero RBs in rounds 3-5. This allows your superstar anchor to carry the running back floor while you load up on high-value WRs.`;
        suggestions = [
          "Look to fill your RB2 slot with a robust committee in rounds 7-10.",
          "Use your strong WR capital to dominate Flex slots and bye week coverages."
        ];
      } else if (earlyRB === 0) {
        success = false;
        feedback = `Hero RB strategy requires securing a single elite anchor RB in Round 1 or Round 2. Since you did not draft an RB early, your roster misses the reliable superstar foundation needed to anchor the position.`;
        suggestions = [
          "Lock in one Tier 1/2 running back inside the first 2 rounds.",
          "Strictly avoid drafting any additional RBs until Round 6 or 7.",
          "Hoard elite pass catchers once your anchor RB is secured."
        ];
      } else {
        success = false;
        feedback = `You selected Hero RB but hoarded ${rbCount} early running backs. Drafting multiple RBs in the first 5 rounds dilutes your ability to build an elite WR room, turning your roster into a standard balanced build instead.`;
        suggestions = [
          "Draft only ONE running back in your first 5 picks.",
          "Trust your single anchor RB to carry the load, and focus heavily on receivers.",
          "Add positional depth RBs much later (Rounds 8+)."
        ];
      }
    } else if (selectedStrat === 'Late QB/TE Focus') {
      if (qbPickedEarly || tePickedEarly) {
        success = false;
        const earlyPos = qbPickedEarly && tePickedEarly ? 'QB and TE' : qbPickedEarly ? 'QB' : 'TE';
        const earlyRound = qbPickedEarly ? qbPickedEarly.round : tePickedEarly?.round;
        feedback = `You declared a "Late QB/TE" strategy but reached for a ${earlyPos} in Round ${earlyRound}. Waiting on single-starter positions is crucial for packing your starting lineup and bench with high-volume RBs and WRs.`;
        suggestions = [
          "Strictly ignore quarterbacks and tight ends during the first 8 rounds.",
          "Value premium WR/RB depth over minor positional tier jumps at QB/TE.",
          "Target high-upside late-round dual-threat QBs (e.g. rushing floor QBs) in Round 9+."
        ];
      } else {
        success = true;
        feedback = `Disciplined execution of Late QB/TE! You avoided early single-starter selections, hoarding prime running backs and wide receivers instead. You successfully maximized your flex scoring potential.`;
        suggestions = [
          "Exploit late-round rushing QBs and athletic developmental tight ends.",
          "Stream matchups at QB/TE weekly to optimize positional efficiency."
        ];
      }
    } else {
      // Balanced
      const positionalConcentration = roster.filter(p => p.position === 'WR').length >= 4 && roster.filter(p => p.position === 'RB').length >= 4;
      if (positionalConcentration) {
        success = true;
        feedback = `Excellent Balanced draft! You navigated value boards efficiently, spreading capital across RBs and WRs. This robust structure eliminates catastrophic single-injury vulnerabilities.`;
        suggestions = [
          "Let ECR and ADP value drops dictate your picks rather than forcing roster slots.",
          "Optimize starting grids based on weekly matchups rather than positional loyalty."
        ];
      } else {
        success = true;
        feedback = `Solid value-based draft. You stayed highly adaptable, tracking ADP slippage to secure quality assets. Your draft grade reflects an efficient capitalization on opponent reaches.`;
        suggestions = [
          "In future drafts, try specializing in a concentrated strategy (like Hero RB) if draft spot allows.",
          "Monitor pre-season target shares to adjust your bench value."
        ];
      }
    }

    return { success, feedback, suggestions, selectedStrat };
  }, [setup.userStrategy, draftHistory, roster]);

  // EXPECTED PERFORMANCE GAME-BY-GAME & QUARTER-BY-QUARTER
  const performanceTelemetry = useMemo(() => {
    // Generate a game-by-game projected schedule with floor, median, and ceiling
    const avgScore = 100 + (valueScore * 0.8) + (grade === 'A+' ? 15 : grade === 'A' ? 10 : grade.startsWith('B') ? 5 : 0);
    const weeklyProjections = Array.from({ length: 14 }, (_, idx) => {
      const week = idx + 1;
      const seed = week * 17 + projectedWins;
      const randNoise = ((seed % 19) - 9) * 1.5; // realistic pseudo-randomness
      const median = Math.round(avgScore + randNoise);
      const floor = Math.round(median - 15 - (seed % 5));
      const ceiling = Math.round(median + 18 + (seed % 7));

      // Simulate match outcome
      const oppAvg = 105 + ((seed % 13) - 6);
      const isWin = median > oppAvg;
      
      const botNames = ['Andy', 'Mike', 'Jason', 'Sarah', 'David', 'Jessica', 'Michael', 'Emily', 'James', 'Ashley', 'Robert'];
      const opponentName = botNames[(idx + setup.userPosition) % botNames.length];

      return {
        week,
        floor,
        median,
        ceiling,
        opponent: opponentName,
        isWin,
        oppScore: Math.round(oppAvg)
      };
    });

    const ptsScored = Number((avgScore * 14).toFixed(0));
    const ptsAllowed = Number((105 * 14 - valueScore * 5).toFixed(0));

    return {
      avgScore,
      weeklyProjections,
      ptsScored,
      ptsAllowed
    };
  }, [valueScore, grade, projectedWins, setup.userPosition]);

  // HISTORICAL STANDINGS LEADERBOARD REAL-TIME AGGREGATION
  const leaderboardData = useMemo(() => {
    const acc: { [name: string]: any } = {};

    // Initialize standings with the human and all 11 default bots
    const botNames = ['Andy', 'Mike', 'Jason', 'Sarah', 'David', 'Jessica', 'Michael', 'Emily', 'James', 'Ashley', 'Robert'];
    
    const userTeamName = getUserTeamName();
    acc[userTeamName] = {
      name: userTeamName,
      isHuman: true,
      strategyCamp: setup.userStrategy || 'Balanced',
      expertPreference: setup.rankingsBase || 'ECR Consensus',
      totalWins: 0,
      totalLosses: 0,
      playoffChanceSum: 0,
      playoffCount: 0,
      gradePointsSum: 0,
      draftCount: 0
    };

    botNames.forEach(name => {
      const profile = useMockMaxxingStore.getState().botProfiles[name] || { strategyCamp: 'Balanced', expertPreference: 'ECR Consensus' };
      acc[name] = {
        name,
        isHuman: false,
        strategyCamp: profile.strategyCamp,
        expertPreference: profile.expertPreference,
        totalWins: 0,
        totalLosses: 0,
        playoffChanceSum: 0,
        playoffCount: 0,
        gradePointsSum: 0,
        draftCount: 0
      };
    });

    // Aggregate from historicalDrafts list
    historicalDrafts.forEach(draft => {
      draft.teams.forEach(team => {
        const teamName = team.teamName;
        // Handle name mapping for user
        const key = (teamName === userTeamName || teamName === 'Your Team') ? userTeamName : teamName;
        
        if (!acc[key]) {
          acc[key] = {
            name: key,
            isHuman: key === userTeamName,
            strategyCamp: team.strategyCamp,
            expertPreference: team.expertPreference,
            totalWins: 0,
            totalLosses: 0,
            playoffChanceSum: 0,
            playoffCount: 0,
            gradePointsSum: 0,
            draftCount: 0
          };
        }

        acc[key].totalWins += team.wins;
        acc[key].totalLosses += team.losses;
        acc[key].playoffChanceSum += team.playoffChance;
        if (team.playoffChance >= 50) acc[key].playoffCount++;
        acc[key].gradePointsSum += getGradePoints(team.grade);
        acc[key].draftCount++;
      });
    });

    const rows = Object.values(acc).map(item => {
      const totalGames = item.totalWins + item.totalLosses;
      const winRate = totalGames > 0 ? (item.totalWins / totalGames) : 0;
      const avgPlayoff = item.draftCount > 0 ? (item.playoffChanceSum / item.draftCount) : 0;
      const avgGradePoints = item.draftCount > 0 ? (item.gradePointsSum / item.draftCount) : 8.0; // B default
      const avgGrade = getGradeLetterFromPoints(avgGradePoints);

      return {
        ...item,
        winRate,
        avgPlayoff: Math.round(avgPlayoff),
        avgGrade
      };
    });

    // Sort by win rate descending, then average playoff chance
    return rows.sort((a, b) => b.winRate - a.winRate || b.avgPlayoff - a.avgPlayoff);
  }, [historicalDrafts, setup.userStrategy, setup.rankingsBase]);

  // Interactive 5,000 simulations button handler
  const handlePopulateSims = () => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Heavy);
    runSimulationBatches(5000);
  };

  const handleClearHistory = () => {
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(() => {});
    }
    clearHistory();
  };

  // Bot Self-Improvement curve coordinates helper
  const drawBotLearningCurve = (width: number, height: number) => {
    const points: { x: number; y: number }[] = [];
    const maxSims = 10000;
    
    for (let i = 0; i <= 10; i++) {
      const simulatedPoints = i * 1000;
      // botLearningAccuracy curve function: accuracy = initial + (0.98 - initial) * (1 - exp(-sims/3000))
      const growth = (0.98 - 0.50) * (1 - Math.exp(-simulatedPoints / 3000));
      const accuracy = 0.50 + growth;
      
      const x = 25 + (i * (width - 50)) / 10;
      // Map accuracy (0.50 - 1.00) to height coordinates (Y climbs upwards, so invert it)
      const y = height - 20 - ((accuracy - 0.50) / 0.50) * (height - 40);
      points.push({ x, y });
    }

    let pathString = `M ${points[0].x} ${points[0].y}`;
    for (let i = 1; i < points.length; i++) {
      pathString += ` L ${points[i].x} ${points[i].y}`;
    }

    // Coordinates for current learning state dot
    const curGrowth = (0.98 - 0.50) * (1 - Math.exp(-botTrainingSims / 3000));
    const curAccuracy = 0.50 + curGrowth;
    const curX = 25 + (botTrainingSims / maxSims) * (width - 50);
    const curY = height - 20 - ((curAccuracy - 0.50) / 0.50) * (height - 40);

    return { pathString, curX, curY, curAccuracy, points };
  };

  const { pathString, curX, curY, curAccuracy, points } = useMemo(() => {
    return drawBotLearningCurve(320, 100);
  }, [botTrainingSims]);

  // Dynamic selector for touch coordinate lookup
  const exploredPoints = useMemo(() => {
    if (exploreIdx === null) return null;
    const simulatedPoints = exploreIdx * 1000;
    const growth = (0.98 - 0.50) * (1 - Math.exp(-simulatedPoints / 3000));
    const accuracy = 0.50 + growth;
    return {
      sims: simulatedPoints,
      accuracy: Math.round(accuracy * 100),
      x: points[exploreIdx]?.x ?? 25,
      y: points[exploreIdx]?.y ?? 80,
    };
  }, [exploreIdx, points]);

  // Touch event coordinate mapping handler
  const handleTouch = (event: any) => {
    const touchX = event.nativeEvent.locationX;
    // Map touchX (bounding box 25 to 310) to the nearest index (0 to 10)
    const relativeX = (touchX - 25) / (320 - 50);
    const idx = Math.max(0, Math.min(10, Math.round(relativeX * 10)));
    if (idx !== exploreIdx) {
      setExploreIdx(idx);
      triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  return (
    <View style={styles.container}>
      <BackgroundTexture />
      <SafeAreaView style={styles.safeArea} edges={['top', 'bottom']}>
        
        {/* TOP COMPACT HEADER */}
        <AppHeader
          title="DRAFT SCORECARD"
          subtitle="HIGH-FIDELITY ANALYTICS SUITE"
        />

        {/* COMPACT SUMMARY HEADER CARD */}
        <View style={[styles.gradeCard, isHOF && styles.hofGradeCard]}>
          <View style={styles.gradeBoxRow}>
            <View style={styles.gradeCircle}>
              <Text style={[styles.gradeLetterText, isHOF && styles.hofText]}>{grade}</Text>
            </View>
            <View style={styles.gradeHeaderMeta}>
              <Text style={styles.gradeHeaderKicker}>{isHOF ? '🏆 HALL OF FAME RATING' : 'DRAFT GRADE'}</Text>
              <Text style={styles.gradeHeaderRecord}>{Math.round(projectedWins)} - {Math.round(projectedLosses)} Projected</Text>
              <Text style={styles.gradeHeaderPlayoff}>{Math.round(playoffChance)}% Playoff Probability</Text>
            </View>
          </View>
          <Text style={styles.gradeHeaderSummaryText}>
            {grade === 'A+' && 'Masterful. You captured immense draft value across almost every single round.'}
            {grade === 'A' && 'Outstanding. You navigated positional scarcity perfectly and built deep lineups.'}
            {grade.startsWith('B') && 'Strong draft. Solid roster balance with very minor ADP slips.'}
            {grade === 'C' && 'Average draft. Reached on several positions; depth could be highly vulnerable.'}
            {grade === 'D' && 'Tough draft board. We recommend monitoring active news to adjust starters.'}
          </Text>
        </View>

        {/* DYNAMIC DASHBOARD TAB HEADER */}
        <View style={styles.tabSwitcher}>
          <Pressable 
            style={[styles.tabButton, activeTab === 'roster' && styles.tabButtonActive]}
            onPress={() => { setActiveTab('roster'); triggerHaptic(Haptics.ImpactFeedbackStyle.Light); }}
          >
            <Text style={[styles.tabButtonText, activeTab === 'roster' && styles.tabButtonTextActive]}>ROSTER</Text>
          </Pressable>
          <Pressable 
            style={[styles.tabButton, activeTab === 'coach' && styles.tabButtonActive]}
            onPress={() => { setActiveTab('coach'); triggerHaptic(Haptics.ImpactFeedbackStyle.Light); }}
          >
            <Text style={[styles.tabButtonText, activeTab === 'coach' && styles.tabButtonTextActive]}>COACH</Text>
          </Pressable>
          <Pressable 
            style={[styles.tabButton, activeTab === 'performance' && styles.tabButtonActive]}
            onPress={() => { setActiveTab('performance'); triggerHaptic(Haptics.ImpactFeedbackStyle.Light); }}
          >
            <Text style={[styles.tabButtonText, activeTab === 'performance' && styles.tabButtonTextActive]}>PERFORMANCE</Text>
          </Pressable>
          <Pressable 
            style={[styles.tabButton, activeTab === 'leaderboard' && styles.tabButtonActive]}
            onPress={() => { setActiveTab('leaderboard'); triggerHaptic(Haptics.ImpactFeedbackStyle.Light); }}
          >
            <Text style={[styles.tabButtonText, activeTab === 'leaderboard' && styles.tabButtonTextActive]}>LEADERBOARD</Text>
          </Pressable>
          <Pressable 
            style={[styles.tabButton, activeTab === 'board' && styles.tabButtonActive]}
            onPress={() => { setActiveTab('board'); triggerHaptic(Haptics.ImpactFeedbackStyle.Light); }}
          >
            <Text style={[styles.tabButtonText, activeTab === 'board' && styles.tabButtonTextActive]}>BOARD</Text>
          </Pressable>
        </View>

        {isSimulating && (
          <View style={styles.simulatingOverlay}>
            <ActivityIndicator size="large" color={Colors.hofYellow} />
            <Text style={styles.simulatingText}>Training AI Bots... {simProgress}%</Text>
            <View style={styles.overlayProgressBarBg}>
              <View style={[styles.overlayProgressBarFill, { width: `${simProgress}%` }]} />
            </View>
            <Text style={{ fontFamily: Fonts.body, fontSize: 11, color: '#94a3b8', marginTop: 4 }}>
              Simulating 5,000 leagues to optimize strategy weights
            </Text>
          </View>
        )}

        <ScrollView 
          contentContainerStyle={styles.scrollContent} 
          showsVerticalScrollIndicator={false}
        >
          {/* TAB A: ROSTER GRID TAB */}
          {activeTab === 'roster' && (
            <View style={styles.rosterSection}>
              {/* STARTERS GRID */}
              <View style={styles.columnHeaderRow}>
                <View style={[styles.rankingsRowLeftSection, { width: 76, justifyContent: 'center' }]}>
                  <Text style={styles.columnHeaderText}>SLOT/BYE</Text>
                </View>
                <View style={{ width: 32 }} />
                <View style={styles.rankingsRowInfo}>
                  <Text style={styles.columnHeaderText}>STARTER SLOTS</Text>
                </View>
              </View>

              <View style={styles.gridContainer}>
                {starters.map((slot) => (
                  <View key={slot.id} style={styles.rankingsRowItem}>
                    <View style={styles.rankingsRowLeftSection}>
                      <View style={[
                        styles.posRankBadge, 
                        { backgroundColor: getSlotBgColor(slot.label) }
                      ]}>
                        <Text style={[
                          styles.posRankBadgeText, 
                          { color: getSlotTextColor(slot.label) }
                        ]}>
                          {slot.label}
                        </Text>
                      </View>
                      {slot.player && (
                        <View style={[
                          styles.posRankBadge, 
                          { 
                            backgroundColor: '#ffffff',
                          }
                        ]}>
                          <Text style={[
                            styles.posRankBadgeText, 
                            { color: '#000000', fontWeight: 'bold' }
                          ]}>
                            {slot.player.bye}
                          </Text>
                        </View>
                      )}
                    </View>
                    {slot.player ? (
                      <>
                        <Image
                          source={{ uri: getPlayerHeadshotUrl(slot.player.espnId, slot.player.position, slot.player.team) }}
                          style={styles.rankingsRowHeadshot}
                        />
                        <View style={styles.rankingsRowInfo}>
                          <Text style={styles.rankingsRowName} numberOfLines={1}>
                            {getDisplayName(slot.player.name)}
                          </Text>
                          <Text style={styles.rankingsRowMeta}>
                            {slot.player.team} · {getPlayerProjections(slot.player)}
                          </Text>
                        </View>
                        <View style={styles.pickDetails}>
                          <Text style={styles.pickLabel}>PICK</Text>
                          <Text style={styles.pickVal}>#{getUserPickNumber(slot.player.name)}</Text>
                        </View>
                      </>
                    ) : (
                      <View style={styles.emptySlotContainer}>
                        <Text style={styles.emptySlotText}>Empty Starting Slot</Text>
                      </View>
                    )}
                  </View>
                ))}
              </View>

              {/* BENCH GRID */}
              <View style={[styles.columnHeaderRow, { marginTop: Spacing.four }]}>
                <View style={[styles.rankingsRowLeftSection, { width: 76, justifyContent: 'center' }]}>
                  <Text style={styles.columnHeaderText}>SLOT/BYE</Text>
                </View>
                <View style={{ width: 32 }} />
                <View style={styles.rankingsRowInfo}>
                  <Text style={styles.columnHeaderText}>BENCH SLOTS</Text>
                </View>
              </View>

              <View style={styles.gridContainer}>
                {bench.map((slot) => (
                  <View key={slot.id} style={styles.rankingsRowItem}>
                    <View style={styles.rankingsRowLeftSection}>
                      <View style={[
                        styles.posRankBadge, 
                        { backgroundColor: getSlotBgColor(slot.label) }
                      ]}>
                        <Text style={[
                          styles.posRankBadgeText, 
                          { color: getSlotTextColor(slot.label) }
                        ]}>
                          {slot.label}
                        </Text>
                      </View>
                      {slot.player && (
                        <View style={[
                          styles.posRankBadge, 
                          { 
                            backgroundColor: '#ffffff',
                          }
                        ]}>
                          <Text style={[
                            styles.posRankBadgeText, 
                            { color: '#000000', fontWeight: 'bold' }
                          ]}>
                            {slot.player.bye}
                          </Text>
                        </View>
                      )}
                    </View>
                    {slot.player ? (
                      <>
                        <Image
                          source={{ uri: getPlayerHeadshotUrl(slot.player.espnId, slot.player.position, slot.player.team) }}
                          style={styles.rankingsRowHeadshot}
                        />
                        <View style={styles.rankingsRowInfo}>
                          <Text style={styles.rankingsRowName} numberOfLines={1}>
                            {getDisplayName(slot.player.name)}
                          </Text>
                          <Text style={styles.rankingsRowMeta}>
                            {slot.player.team} · {getPlayerProjections(slot.player)}
                          </Text>
                        </View>
                        <View style={styles.pickDetails}>
                          <Text style={styles.pickLabel}>PICK</Text>
                          <Text style={styles.pickVal}>#{getUserPickNumber(slot.player.name)}</Text>
                        </View>
                      </>
                    ) : (
                      <View style={styles.emptySlotContainer}>
                        <Text style={styles.emptySlotText}>Empty Bench Slot</Text>
                      </View>
                    )}
                  </View>
                ))}
              </View>

              {/* ADVANCED METRICS SUB-VIEW OPTIONS */}
              <Pressable 
                style={[styles.advancedToggleBtn, showAdvanced && styles.advancedToggleBtnActive]}
                onPress={() => setShowAdvanced(!showAdvanced)}
              >
                <Text style={styles.advancedToggleBtnText}>
                  {showAdvanced ? '🔽 HIDE ADVANCED ROSTER METRICS' : '➕ ANALYZE ADVANCED ROSTER METRICS'}
                </Text>
              </Pressable>

              {showAdvanced && (
                <View style={styles.advancedMetricsCard}>
                  <Text style={styles.advancedTitle}>ROSTER STRENGTH REPORT</Text>
                  
                  <View style={styles.advancedRow}>
                    <View style={styles.advancedCell}>
                      <Text style={[styles.posBadge, { backgroundColor: Colors.positions.QB }]}>QB</Text>
                      <Text style={styles.advancedGradeText}>{getPositionGrade('QB')}</Text>
                      <Text style={styles.advancedSubtext}>{getPositionPPG('QB')} PPG Avg</Text>
                    </View>
                    <View style={styles.advancedCell}>
                      <Text style={[styles.posBadge, { backgroundColor: Colors.positions.RB }]}>RB</Text>
                      <Text style={styles.advancedGradeText}>{getPositionGrade('RB')}</Text>
                      <Text style={styles.advancedSubtext}>{getPositionPPG('RB')} PPG Avg</Text>
                    </View>
                    <View style={styles.advancedCell}>
                      <Text style={[styles.posBadge, { backgroundColor: Colors.positions.WR }]}>WR</Text>
                      <Text style={styles.advancedGradeText}>{getPositionGrade('WR')}</Text>
                      <Text style={styles.advancedSubtext}>{getPositionPPG('WR')} PPG Avg</Text>
                    </View>
                    <View style={styles.advancedCell}>
                      <Text style={[styles.posBadge, { backgroundColor: Colors.positions.TE }]}>TE</Text>
                      <Text style={styles.advancedGradeText}>{getPositionGrade('TE')}</Text>
                      <Text style={styles.advancedSubtext}>{getPositionPPG('TE')} PPG Avg</Text>
                    </View>
                  </View>

                  <View style={styles.metricStatsRow}>
                    <View style={styles.metricStatsCard}>
                      <Text style={styles.metricStatsLabel}>BYE COVERAGE SCORE</Text>
                      <Text style={styles.metricStatsValue}>{getByeScore()}%</Text>
                      <Text style={styles.metricStatsFeedback}>
                        {byeConflictCount === 0 ? 'Perfect bye distribution.' : `${byeConflictCount} overlap conflict(s) found.`}
                      </Text>
                    </View>

                    <View style={styles.metricStatsCard}>
                      <Text style={styles.metricStatsLabel}>STARTER/BENCH VALUE</Text>
                      <Text style={styles.metricStatsValue}>{getStarterBenchRatio()}</Text>
                      <Text style={styles.metricStatsFeedback}>Capital starter concentration</Text>
                    </View>
                  </View>
                </View>
              )}
            </View>
          )}

          {/* TAB B: STRATEGY COACH */}
          {activeTab === 'coach' && (
            <View style={styles.coachContainer}>
              <View style={styles.coachBubble}>
                <Text style={styles.coachTitle}>STRATEGY COACH FEEDBACK</Text>
                <Text style={[styles.coachStatus, coachStrategyAnalysis.success ? styles.coachSuccess : styles.coachWarning]}>
                  {coachStrategyAnalysis.success ? '🏆 MASTERFUL EXECUTION' : '⚠️ STRATEGIC DEVIATION'}
                </Text>
                <Text style={styles.coachFeedback}>{coachStrategyAnalysis.feedback}</Text>

                <Text style={styles.coachSubHeader}>SUGGESTED STRATEGY ALTERATIONS:</Text>
                {coachStrategyAnalysis.suggestions.map((sug, i) => (
                  <Text key={i} style={styles.coachSuggestionItem}>
                    • {sug}
                  </Text>
                ))}
              </View>

              {/* VALUE VS ADP COMPARISON LIST */}
              <Text style={styles.coachSectionTitle}>ROUND-BY-ROUND DRAFT VALUE</Text>
              <View style={styles.valueList}>
                {draftHistory.filter(h => h.teamName === getUserTeamName() || h.teamName === 'Your Team').map((pick) => {
                  const val = pick.player.adp - pick.pickNumber;
                  const isSteal = val > 0;
                  const isReach = val < 0;

                  return (
                    <View key={pick.pickNumber} style={styles.valueRow}>
                      <View style={styles.valueRoundBadge}>
                        <Text style={styles.valueRoundText}>RD {pick.round}</Text>
                        <Text style={styles.valuePickText}>PK {pick.pickNumber}</Text>
                      </View>
                      
                      <Image 
                        source={{ uri: getPlayerHeadshotUrl(pick.player.espnId, pick.player.position, pick.player.team) }} 
                        style={styles.valueHeadshot}
                      />

                      <View style={styles.valueInfo}>
                        <Text style={styles.valueName} numberOfLines={1}>{getDisplayName(pick.player.name)}</Text>
                        <Text style={styles.valueMeta}>{pick.player.position} · {pick.player.team} · ECR #{pick.player.rank}</Text>
                      </View>

                      <View style={[
                        styles.valBadge, 
                        isSteal && styles.valSteal, 
                        isReach && styles.valReach
                      ]}>
                        <Text style={[
                          styles.valBadgeText, 
                          isSteal && styles.valStealText, 
                          isReach && styles.valReachText
                        ]}>
                          {val === 0 ? 'ON ADP' : val > 0 ? `+${val} VAL` : `${val} REACH`}
                        </Text>
                      </View>
                    </View>
                  );
                })}
              </View>
            </View>
          )}

          {/* TAB C: EXPECTED PERFORMANCE */}
          {activeTab === 'performance' && (
            <View style={styles.perfContainer}>
              
              {/* Telemetry Stats Card */}
              <View style={styles.telemetryCard}>
                <Text style={styles.telemetryCardTitle}>SEASON TELEMETRY REPORT</Text>
                <View style={styles.telemetryStatsRow}>
                  <View style={styles.telemetryStat}>
                    <Text style={styles.telemetryStatLabel}>AVG WEEKLY SCORE</Text>
                    <Text style={styles.telemetryStatVal}>{Math.round(performanceTelemetry.avgScore)}</Text>
                  </View>
                  <View style={styles.telemetryStat}>
                    <Text style={styles.telemetryStatLabel}>TOTAL POINTS FOR</Text>
                    <Text style={styles.telemetryStatVal}>{performanceTelemetry.ptsScored}</Text>
                  </View>
                  <View style={styles.telemetryStat}>
                    <Text style={styles.telemetryStatLabel}>TOTAL POINTS AGAINST</Text>
                    <Text style={styles.telemetryStatVal}>{performanceTelemetry.ptsAllowed}</Text>
                  </View>
                </View>
              </View>

              {/* EXCELS/FAILS SECTION */}
              <View style={styles.routineGrid}>
                <View style={[styles.routineCard, { borderColor: '#22c55e33' }]}>
                  <Text style={styles.routineHeading}>🌟 EXCELS ROUTINELY AT</Text>
                  <Text style={styles.routineBullet}>• Positional bye-week optimization</Text>
                  <Text style={styles.routineBullet}>
                    {valueScore >= 0 
                      ? '• Capturing premium ADP value slips' 
                      : '• Stacking high-efficiency starter floor'}
                  </Text>
                  <Text style={styles.routineBullet}>• Drafting elite WR vertical weapons</Text>
                </View>

                <View style={[styles.routineCard, { borderColor: '#ef444433' }]}>
                  <Text style={styles.routineHeading}>⚠️ FAILS ROUTINELY AT</Text>
                  <Text style={styles.routineBullet}>• Over-valuing secondary defense/kicker assets</Text>
                  <Text style={styles.routineBullet}>
                    {byeConflictCount >= 2 
                      ? '• Tolerating bye-week roster lockouts' 
                      : '• Early round reached positional capitalization'}
                  </Text>
                  <Text style={styles.routineBullet}>• Neglecting late-round backup QB insurance</Text>
                </View>
              </View>

              {/* Game-by-Game Weekly telemetry ranges */}
              <Text style={styles.perfSectionTitle}>PROJECTED MATCH PLAYOUTS (14 WEEKS)</Text>
              <View style={styles.weeklyList}>
                {performanceTelemetry.weeklyProjections.map((match) => (
                  <View key={match.week} style={styles.weeklyRow}>
                    <View style={styles.weeklyRoundLabel}>
                      <Text style={styles.weeklyRoundText}>WK {match.week}</Text>
                    </View>
                    
                    <View style={styles.weeklyRangeContainer}>
                      <Text style={styles.weeklyRangeLabelText}>VS {match.opponent.toUpperCase()}</Text>
                      <View style={styles.rangeBarBg}>
                        <View style={[
                          styles.rangeBarFill,
                          {
                            left: `${Math.max(0, (match.floor - 80) * 100 / 80)}%`,
                            width: `${Math.max(10, (match.ceiling - match.floor) * 100 / 80)}%`
                          }
                        ]} />
                        {/* Dot representing median projected score */}
                        <View style={[
                          styles.rangeDot,
                          { left: `${Math.max(0, (match.median - 80) * 100 / 80)}%` }
                        ]} />
                      </View>
                      <Text style={styles.weeklyScoreDetail}>
                        Range: {match.floor} - {match.ceiling} pts · Median: {match.median} pts
                      </Text>
                    </View>

                    <View style={[styles.matchOutcomeBadge, match.isWin ? styles.matchWin : styles.matchLoss]}>
                      <Text style={[styles.matchOutcomeText, match.isWin ? styles.matchWinText : styles.matchLossText]}>
                        {match.isWin ? `W (${match.median}-${match.oppScore})` : `L (${match.median}-${match.oppScore})`}
                      </Text>
                    </View>
                  </View>
                ))}
              </View>

              {/* QUARTER-BY-QUARTER telemetry */}
              <Text style={styles.perfSectionTitle}>QUARTER-BY-QUARTER TELEMETRY</Text>
              <View style={styles.quarterGrid}>
                {/* Q1 */}
                <View style={styles.quarterCard}>
                  <Text style={styles.quarterTitle}>Q1 (WEEKS 1-4)</Text>
                  <Text style={styles.quarterSubtitle}>"Early-Season Burst"</Text>
                  <Text style={styles.quarterStat}>STRENGTH: ELITE (94%)</Text>
                  <Text style={styles.quarterBody}>Your healthy starters carry extreme high-end ADP strength to capture massive early momentum.</Text>
                </View>

                {/* Q2 */}
                <View style={styles.quarterCard}>
                  <Text style={styles.quarterTitle}>Q2 (WEEKS 5-8)</Text>
                  <Text style={styles.quarterSubtitle}>"Bye Week Navigation"</Text>
                  <Text style={styles.quarterStat}>
                    RATING: {getByeScore()}%
                  </Text>
                  <Text style={styles.quarterBody}>
                    {byeConflictCount >= 2 
                      ? 'Roster contains severe overlapping positional byes. Waiver-wire streams required.' 
                      : 'Excellent bye dispersion gives you an immense advantage during heavy bye weeks.'}
                  </Text>
                </View>

                {/* Q3 */}
                <View style={styles.quarterCard}>
                  <Text style={styles.quarterTitle}>Q3 (WEEKS 9-12)</Text>
                  <Text style={styles.quarterSubtitle}>"Mid-Season Consolidation"</Text>
                  <Text style={styles.quarterStat}>STRENGTH: STABLE (88%)</Text>
                  <Text style={styles.quarterBody}>Projected starter metrics are locked in. Roster capital guarantees highly consistent double-digit outputs.</Text>
                </View>

                {/* Q4 */}
                <View style={styles.quarterCard}>
                  <Text style={styles.quarterTitle}>Q4 (WEEKS 13-17)</Text>
                  <Text style={styles.quarterSubtitle}>"Late-Season Playoff Push"</Text>
                  <Text style={styles.quarterStat}>
                    DEPTH: {bench.filter(b => b.player).length >= 5 ? 'DEEP (92%)' : 'THIN (64%)'}
                  </Text>
                  <Text style={styles.quarterBody}>
                    {bench.filter(b => b.player).length >= 5
                      ? 'Your deep bench ensures you survive late-season attrition and locking playoff runs.'
                      : 'Roster is thin. A single starting injury severely risks late playoff competitiveness.'}
                  </Text>
                </View>
              </View>

            </View>
          )}

          {/* TAB D: LEADERBOARD & TRENDS */}
          {activeTab === 'leaderboard' && (
            <View style={styles.lobbyContainer}>
              
              {/* Bot Learning / Prepopulate Action Panel */}
              <View style={styles.aiPanel}>
                <Text style={styles.aiPanelTitle}>🤖 BOT MANAGER AI COGNITIVE TELEMETRY</Text>
                
                {/* Visual SVG Curve Chart */}
                <View 
                  style={[styles.chartWrapper, { position: 'relative' }]}
                  onStartShouldSetResponder={() => true}
                  onMoveShouldSetResponder={() => true}
                  onResponderGrant={handleTouch}
                  onResponderMove={handleTouch}
                >
                  <Svg width="100%" height="100" viewBox="0 0 320 100">
                    <Defs>
                      <LinearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                        <Stop offset="0%" stopColor={Colors.hofYellow} stopOpacity="0.35" />
                        <Stop offset="100%" stopColor={Colors.hofYellow} stopOpacity="0.0" />
                      </LinearGradient>
                      <LinearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
                        <Stop offset="0%" stopColor={Colors.hofYellow} stopOpacity="0.6" />
                        <Stop offset="50%" stopColor="#ffb03a" stopOpacity="0.9" />
                        <Stop offset="100%" stopColor={Colors.hofYellow} stopOpacity="1" />
                      </LinearGradient>
                    </Defs>

                    {/* Grid lines */}
                    <Line x1="25" y1="10" x2="310" y2="10" stroke={Colors.glassBorder} strokeWidth="0.5" strokeDasharray="4 4" />
                    <Line x1="25" y1="30" x2="310" y2="30" stroke={Colors.glassBorder} strokeWidth="0.5" strokeDasharray="4 4" />
                    <Line x1="25" y1="50" x2="310" y2="50" stroke={Colors.glassBorder} strokeWidth="0.5" strokeDasharray="4 4" />
                    <Line x1="25" y1="80" x2="310" y2="80" stroke={Colors.glassBorder} strokeWidth="0.5" strokeDasharray="4 4" />
                    
                    <Line x1="25" y1="80" x2="25" y2="10" stroke={Colors.glassBorder} strokeWidth="0.5" />
                    <Line x1="310" y1="80" x2="310" y2="10" stroke={Colors.glassBorder} strokeWidth="0.5" />

                    {/* Shaded Area Under the Curve */}
                    <Path 
                      d={`${pathString} L ${points[points.length - 1]?.x ?? 310} 80 L ${points[0]?.x ?? 25} 80 Z`} 
                      fill="url(#areaGradient)" 
                    />

                    {/* Curving Line Path */}
                    <Path d={pathString} fill="none" stroke="url(#lineGradient)" strokeWidth="3" />
                    
                    {/* Glowing coordinate dot for current training sims */}
                    <Circle cx={curX} cy={curY} r="5" fill={Colors.hofYellow} />
                    <Circle cx={curX} cy={curY} r="9" fill="none" stroke={Colors.hofYellow} strokeWidth="1.5" opacity="0.6" />
                    
                    {/* Explore line and dot if active */}
                    {exploredPoints && (
                      <>
                        <Line 
                          x1={exploredPoints.x} 
                          y1="10" 
                          x2={exploredPoints.x} 
                          y2="80" 
                          stroke="rgba(255, 224, 102, 0.4)" 
                          strokeWidth="1" 
                          strokeDasharray="2 2" 
                        />
                        <Circle cx={exploredPoints.x} cy={exploredPoints.y} r="6" fill="#ffffff" />
                        <Circle cx={exploredPoints.x} cy={exploredPoints.y} r="10" fill="none" stroke="#ffffff" strokeWidth="1" opacity="0.5" />
                      </>
                    )}

                    <SvgText x="32" y="22" fill="#94a3b8" fontSize="8" fontFamily={Fonts.stats}>98% Target</SvgText>
                    <SvgText x="32" y="76" fill="#94a3b8" fontSize="8" fontFamily={Fonts.stats}>50% Initial</SvgText>
                  </Svg>

                  {/* Explore point overlay card */}
                  {exploredPoints && (
                    <View style={styles.exploreTooltip}>
                      <Text style={styles.exploreTooltipText}>
                        📈 SIMS: {exploredPoints.sims.toLocaleString()} | ACCURACY: {exploredPoints.accuracy}%
                      </Text>
                    </View>
                  )}

                  {/* Green circle progress indicator badge */}
                  <View style={[
                    styles.greenProgressCircleBadge,
                    isSimulating && styles.greenProgressCircleBadgeActive
                  ]}>
                    <Text style={styles.greenProgressCircleBadgeText}>
                      {isSimulating ? `${simProgress}%` : `${Math.round((botTrainingSims / 10000) * 100)}%`}
                    </Text>
                    <Text style={styles.greenProgressCircleBadgeSubText}>
                      {isSimulating ? 'TRAINING' : botTrainingSims >= 10000 ? 'COMPLETE' : 'TRAINED'}
                    </Text>
                  </View>
                </View>

                <View style={styles.aiProgressMetaRow}>
                  <View>
                    <Text style={styles.aiProgressLabel}>SIMULATION RUNS</Text>
                    <Text style={styles.aiProgressVal}>{botTrainingSims.toLocaleString()} / 10,000</Text>
                  </View>
                  <View style={{ alignItems: 'flex-end' }}>
                    <Text style={styles.aiProgressLabel}>STRATEGY DECISION ACCURACY</Text>
                    <Text style={[styles.aiProgressVal, { color: Colors.hofYellow }]}>{Math.round(curAccuracy * 100)}%</Text>
                  </View>
                </View>

                {/* Progress bar */}
                <View style={styles.aiProgressBarBg}>
                  <View style={[styles.aiProgressBarFill, { width: `${(botTrainingSims / 10000) * 100}%` }]} />
                </View>

                <Text style={styles.aiProgressExplanation}>
                  {botTrainingSims >= 10000 
                    ? '🏆 Bots are fully trained! Selection noise is minimized and strategy weights are fully optimized.' 
                    : '⚡ Bots are currently training. Running simulations decreases decision noise and refines positional strategy parameters.'}
                </Text>

                <View style={styles.aiActionRow}>
                  <Pressable style={styles.aiActionBtn} onPress={handlePopulateSims}>
                    <Text style={styles.aiActionBtnText}>SIMULATE 5,000 LEAGUES</Text>
                  </Pressable>
                  <Pressable style={[styles.aiActionBtn, styles.aiClearBtn]} onPress={handleClearHistory}>
                    <Text style={styles.aiActionBtnTextClear}>RESET DATABASE</Text>
                  </Pressable>
                </View>
              </View>

              {/* STANDINGS LEADERBOARD TABLE */}
              <Text style={styles.lobbySectionTitle}>HISTORICAL STANDINGS LOBBY ({historicalDrafts.length.toLocaleString()} DRAFTS)</Text>
              
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ width: '100%' }}>
                <View style={styles.tableContainer}>
                  {/* Table Header */}
                  <View style={styles.tableHeaderRow}>
                    <Text style={[styles.tableHeaderCell, { width: 36, textAlign: 'center' }]}>RK</Text>
                    <Text style={[styles.tableHeaderCell, { width: 90 }]}>MANAGER</Text>
                    <Text style={[styles.tableHeaderCell, { width: 100 }]}>STRATEGY CAMP</Text>
                    <Text style={[styles.tableHeaderCell, { width: 80, textAlign: 'center' }]}>RECORD</Text>
                    <Text style={[styles.tableHeaderCell, { width: 60, textAlign: 'center' }]}>WIN %</Text>
                    <Text style={[styles.tableHeaderCell, { width: 60, textAlign: 'center' }]}>PLAYOFF%</Text>
                    <Text style={[styles.tableHeaderCell, { width: 60, textAlign: 'center' }]}>AVG GRADE</Text>
                  </View>

                  {/* Table Body Rows */}
                  {leaderboardData.map((row, idx) => {
                    const isHuman = row.name === getUserTeamName() || row.name === 'Your Team';
                    return (
                      <View 
                        key={row.name} 
                        style={[
                          styles.tableRow, 
                          isHuman && styles.tableRowHuman
                        ]}
                      >
                        <Text style={[styles.tableCell, { width: 36, textAlign: 'center', fontWeight: 'bold', color: isHuman ? Colors.hofYellow : '#94a3b8' }]}>
                          #{idx + 1}
                        </Text>
                        <View style={[styles.tableNameCell, { width: 90 }]}>
                          <Text style={[styles.tableCellText, isHuman && styles.tableCellHumanText]} numberOfLines={1}>
                            {row.name}
                          </Text>
                          {!isHuman && <Text style={styles.cpuSubLabel}>[CPU]</Text>}
                        </View>
                        <Text style={[styles.tableCell, { width: 100, color: '#e2e8f0' }]} numberOfLines={1}>
                          {row.strategyCamp}
                        </Text>
                        <Text style={[styles.tableCell, { width: 80, textAlign: 'center', fontFamily: Fonts.stats, fontSize: 10 }]}>
                          {Math.round(row.totalWins)} - {Math.round(row.totalLosses)}
                        </Text>
                        <Text style={[styles.tableCell, { width: 60, textAlign: 'center', fontWeight: 'bold', color: isHuman ? Colors.hofYellow : '#22c55e' }]}>
                          {Math.round(row.winRate * 100)}%
                        </Text>
                        <Text style={[styles.tableCell, { width: 60, textAlign: 'center' }]}>
                          {row.avgPlayoff}%
                        </Text>
                        <Text style={[styles.tableCell, { width: 60, textAlign: 'center', fontWeight: 'bold', color: row.avgGrade.startsWith('A') ? Colors.hofYellow : '#ffffff' }]}>
                          {row.avgGrade}
                        </Text>
                      </View>
                    );
                  })}
                </View>
              </ScrollView>
              
            </View>
          )}

          {/* TAB E: BOARD VIEW */}
          {activeTab === 'board' && (
            <View style={styles.boardSection}>
              <View style={styles.boardHeaderCard}>
                <Text style={styles.boardHeaderTitle}>FULL DRAFT BOARD</Text>
                <Text style={styles.boardHeaderSub}>
                  Review the entire 15-round, pick-by-pick league selections. Swipe horizontally to see all teams.
                </Text>
              </View>

              <ScrollView horizontal={true} showsHorizontalScrollIndicator={true}>
                <View style={styles.boardGridContainer}>
                  {/* Column Headers: Teams */}
                  <View style={styles.boardRow}>
                    {/* Corner round index placeholder */}
                    <View style={styles.boardRoundHeaderCell}>
                      <Text style={styles.boardRoundHeaderText}>ROUND</Text>
                    </View>
                    {Array.from({ length: setup.leagueSize }, (_, idx) => {
                      const name = getTeamNameForIndex(idx, setup.userPosition);
                      const isUser = name === getUserTeamName() || name === 'Your Team';
                      return (
                        <View 
                          key={idx} 
                          style={[
                            styles.boardTeamHeaderCell, 
                            isUser && styles.boardTeamHeaderCellUser
                          ]}
                        >
                          <Text style={[styles.boardTeamHeaderText, isUser && styles.boardTeamHeaderTextUser]} numberOfLines={1}>
                            {isUser ? 'YOUR TEAM' : name.toUpperCase()}
                          </Text>
                          <Text style={styles.boardTeamSubText}>
                            Pick {idx + 1}
                          </Text>
                        </View>
                      );
                    })}
                  </View>

                  {/* Grid Rows: Rounds */}
                  {Array.from({ length: setup.rounds || 15 }, (_, rIdx) => {
                    const roundNum = rIdx + 1;
                    return (
                      <View key={rIdx} style={styles.boardRow}>
                        {/* Round Row Header */}
                        <View style={styles.boardRoundCell}>
                          <Text style={styles.boardRoundCellText}>RD {roundNum}</Text>
                        </View>

                        {/* Each Team's cell in this round */}
                        {Array.from({ length: setup.leagueSize }, (_, tIdx) => {
                          const pick = draftHistory.find(
                            h => h.round === roundNum && h.teamIndex === tIdx
                          );
                          const cellTeamName = getTeamNameForIndex(tIdx, setup.userPosition);
                          const isUser = cellTeamName === getUserTeamName() || cellTeamName === 'Your Team';

                          if (!pick) {
                            return (
                              <View key={tIdx} style={styles.boardPlayerCellEmpty}>
                                <Text style={styles.boardPlayerTextEmpty}>-</Text>
                              </View>
                            );
                          }

                          const player = pick.player;
                          const posColor = Colors.positions[player.position as keyof typeof Colors.positions] || '#94a3b8';

                          return (
                            <View 
                              key={tIdx} 
                              style={[
                                styles.boardPlayerCell,
                                isUser && styles.boardPlayerCellUser,
                                { borderLeftColor: posColor, borderLeftWidth: 4 }
                              ]}
                            >
                              <View style={styles.boardCellTopRow}>
                                <View style={[styles.boardCellPosBadge, { backgroundColor: posColor }]}>
                                  <Text style={styles.boardCellPosText}>{player.position}</Text>
                                </View>
                                <Text style={styles.boardCellPickNumber}>
                                  #{pick.pickNumber}
                                </Text>
                              </View>
                              <Text style={styles.boardCellName} numberOfLines={1}>
                                {getDisplayName(player.name)}
                              </Text>
                              <Text style={styles.boardCellMeta}>
                                {player.team || 'FA'} · Bye {player.bye || '-'}
                              </Text>
                            </View>
                          );
                        })}
                      </View>
                    );
                  })}
                </View>
              </ScrollView>
            </View>
          )}

          {/* PERSISTENT BOTTOM ACTIONS */}
          <View style={styles.actionContainer}>
            <Pressable 
              style={({ pressed }) => [styles.primaryBtn, pressed && styles.btnPressed]} 
              onPress={handleRestart}
            >
              <Text style={styles.primaryBtnText}>START NEW MOCK DRAFT</Text>
            </Pressable>

            <Pressable 
              style={({ pressed }) => [styles.secondaryBtn, pressed && styles.btnPressed]} 
              onPress={handleHome}
            >
              <Text style={styles.secondaryBtnText}>EXIT TO LOBBY</Text>
            </Pressable>
          </View>

        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

function createStyles(Colors: typeof LightColors) {
  const isDark = (Colors.primaryAccent as string) === '#FFFFFF';
  return StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  safeArea: {
    flex: 1,
    alignSelf: 'center',
    width: '100%',
    maxWidth: MaxContentWidth,
  },
  scrollContent: {
    paddingHorizontal: Spacing.four,
    paddingTop: Spacing.two,
    paddingBottom: 120, // Expanded padding bottom to clear bottom floating tabs safely
    gap: Spacing.four,
  },
  header: {
    alignItems: 'center',
    paddingVertical: Spacing.two,
  },
  title: {
    fontFamily: Fonts.headings,
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontFamily: Fonts.stats,
    fontSize: 9,
    color: Colors.secondaryAccent, 
    letterSpacing: 2,
  },
  
  // Compact summary header card
  gradeCard: {
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 12,
    padding: Spacing.three,
    marginHorizontal: Spacing.four,
    ...Colors.shadows,
  },
  hofGradeCard: {
    borderColor: Colors.hofYellow,
    borderWidth: 2,
    backgroundColor: Colors.surface,
    shadowColor: Colors.hofYellow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
  },
  gradeBoxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.three,
  },
  gradeCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: Colors.surfaceLifted,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  gradeLetterText: {
    fontFamily: Fonts.headings,
    fontSize: 32,
    fontWeight: '900',
    color: Colors.primaryAccent,
  },
  hofText: {
    color: isDark ? Colors.hofYellow : Colors.primaryAccent,
    fontWeight: 'bold',
  },
  gradeHeaderMeta: {
    flex: 1,
    gap: 2,
  },
  gradeHeaderKicker: {
    fontFamily: Fonts.stats,
    fontSize: 8,
    color: Colors.secondaryAccent,
    letterSpacing: 1.5,
    fontWeight: 'bold',
  },
  gradeHeaderRecord: {
    fontFamily: Fonts.body,
    fontSize: 14,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
  },
  gradeHeaderPlayoff: {
    fontFamily: Fonts.body,
    fontSize: 11,
    color: '#22c55e',
  },
  gradeHeaderSummaryText: {
    fontFamily: Fonts.body,
    fontSize: 12,
    color: Colors.secondaryAccent,
    marginTop: Spacing.two,
    lineHeight: 16,
  },

  // Dynamic Dashboard tabs switcher (Apple Segmented Control aesthetics)
  tabSwitcher: {
    flexDirection: 'row',
    backgroundColor: isDark ? Colors.background : '#E2E8F0',
    borderColor: isDark ? Colors.coltsNavyLight : '#CBD5E1',
    borderWidth: 1,
    borderRadius: 10,
    padding: 4,
    minHeight: 46,
    marginHorizontal: Spacing.four,
  },
  tabButton: {
    flex: 1,
    height: 38,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8,
  },
  tabButtonActive: {
    backgroundColor: Colors.surface,
    borderColor: isDark ? Colors.coltsNavyLight : '#E2E8F0',
    borderWidth: 1,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  tabButtonText: {
    fontFamily: Fonts.headings,
    fontSize: 12,
    color: isDark ? Colors.secondaryAccent : '#64748b',
    letterSpacing: 0.5,
  },
  tabButtonTextActive: {
    color: Colors.primaryAccent,
    fontWeight: 'bold',
  },

  // Roster Tab Slots layout
  rosterSection: {
    gap: Spacing.two,
  },
  columnHeaderRow: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.two,
    paddingBottom: 4,
  },
  columnHeaderText: {
    fontFamily: Fonts.stats,
    fontSize: 9,
    fontWeight: '800',
    color: Colors.secondaryAccent,
    letterSpacing: 1.5,
  },
  gridContainer: {
    gap: 6,
  },
  rankingsRowItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: Spacing.two,
    gap: 8,
    height: 58,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  rankingsRowLeftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  posRankBadge: {
    width: 36,
    height: 20,
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  posRankBadgeText: {
    fontFamily: Fonts.stats,
    fontSize: 8.5,
    color: '#000000',
    fontWeight: '900',
  },
  rankingsRowHeadshot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.surfaceLifted,
  },
  rankingsRowInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  rankingsRowName: {
    fontFamily: Fonts.body,
    fontSize: 13,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
  },
  rankingsRowMeta: {
    fontFamily: Fonts.body,
    fontSize: 10,
    color: Colors.secondaryAccent,
  },
  pickDetails: {
    alignItems: 'flex-end',
    justifyContent: 'center',
    paddingRight: 4,
  },
  pickLabel: {
    fontFamily: Fonts.stats,
    fontSize: 6.5,
    color: Colors.secondaryAccent,
    letterSpacing: 0.5,
  },
  pickVal: {
    fontFamily: Fonts.stats,
    fontSize: 10.5,
    color: Colors.primaryAccent,
    fontWeight: 'bold',
  },
  emptySlotContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  emptySlotText: {
    fontFamily: Fonts.body,
    fontSize: 11,
    color: Colors.secondaryAccent,
    fontStyle: 'italic',
  },

  // Advanced Metrics sub-view
  advancedToggleBtn: {
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 8,
    backgroundColor: Colors.surface,
    paddingVertical: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: Spacing.three,
  },
  advancedToggleBtnActive: {
    borderColor: Colors.coltsNavyLight,
    backgroundColor: Colors.surfaceLifted,
  },
  advancedToggleBtnText: {
    fontFamily: Fonts.headings,
    fontSize: 12,
    color: Colors.primaryAccent,
    letterSpacing: 0.5,
  },
  advancedMetricsCard: {
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 12,
    padding: Spacing.three,
    marginTop: Spacing.two,
    gap: Spacing.three,
    ...Colors.shadows,
  },
  advancedTitle: {
    fontFamily: Fonts.headings,
    fontSize: 14,
    color: Colors.primaryAccent,
    letterSpacing: 0.5,
  },
  advancedRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 4,
  },
  advancedCell: {
    flex: 1,
    backgroundColor: Colors.surfaceLifted,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 0.5,
    borderRadius: 8,
    padding: 8,
    alignItems: 'center',
    gap: 4,
  },
  posBadge: {
    fontFamily: Fonts.stats,
    fontSize: 8,
    fontWeight: 'bold',
    color: '#000000',
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 4,
  },
  advancedGradeText: {
    fontFamily: Fonts.headings,
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
  },
  advancedSubtext: {
    fontFamily: Fonts.stats,
    fontSize: 7.5,
    color: Colors.secondaryAccent,
  },
  metricStatsRow: {
    flexDirection: 'row',
    gap: Spacing.two,
  },
  metricStatsCard: {
    flex: 1,
    backgroundColor: Colors.surfaceLifted,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 0.5,
    borderRadius: 8,
    padding: 10,
    gap: 2,
  },
  metricStatsLabel: {
    fontFamily: Fonts.stats,
    fontSize: 7.5,
    color: Colors.secondaryAccent,
    letterSpacing: 0.5,
  },
  metricStatsValue: {
    fontFamily: Fonts.stats,
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
  },
  metricStatsFeedback: {
    fontFamily: Fonts.body,
    fontSize: 9.5,
    color: Colors.secondaryAccent,
  },

  // Coach Feedback styles
  coachContainer: {
    gap: Spacing.three,
  },
  coachBubble: {
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 12,
    padding: Spacing.four,
    gap: Spacing.two,
    ...Colors.shadows,
  },
  coachTitle: {
    fontFamily: Fonts.headings,
    fontSize: 14,
    color: Colors.secondaryAccent,
    letterSpacing: 0.5,
  },
  coachStatus: {
    fontFamily: Fonts.stats,
    fontSize: 10,
    fontWeight: 'bold',
    letterSpacing: 1.5,
  },
  coachSuccess: {
    color: '#22c55e',
  },
  coachWarning: {
    color: '#eab308', // Amber warning for contrast on white
  },
  coachFeedback: {
    fontFamily: Fonts.body,
    fontSize: 13,
    color: Colors.primaryAccent,
    lineHeight: 18,
    opacity: 0.9,
  },
  coachSubHeader: {
    fontFamily: Fonts.stats,
    fontSize: 9,
    fontWeight: 'bold',
    color: Colors.secondaryAccent,
    letterSpacing: 1,
    marginTop: Spacing.two,
  },
  coachSuggestionItem: {
    fontFamily: Fonts.body,
    fontSize: 12,
    color: Colors.secondaryAccent,
    lineHeight: 16,
  },
  coachSectionTitle: {
    fontFamily: Fonts.stats,
    fontSize: 10,
    color: Colors.secondaryAccent,
    letterSpacing: 1.5,
    marginTop: Spacing.two,
  },
  valueList: {
    gap: 6,
  },
  valueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: Spacing.two,
    gap: Spacing.two,
    height: 58, // Up-scaled touch target
  },
  valueRoundBadge: {
    width: 48,
    height: 36,
    borderRadius: 6,
    backgroundColor: Colors.surfaceLifted,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 0.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  valueRoundText: {
    fontFamily: Fonts.stats,
    fontSize: 9,
    fontWeight: 'bold',
    color: Colors.secondaryAccent,
  },
  valuePickText: {
    fontFamily: Fonts.stats,
    fontSize: 7.5,
    color: Colors.secondaryAccent,
  },
  valueHeadshot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.surfaceLifted,
  },
  valueInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  valueName: {
    fontFamily: Fonts.body,
    fontSize: 12,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
  },
  valueMeta: {
    fontFamily: Fonts.body,
    fontSize: 9.5,
    color: Colors.secondaryAccent,
  },
  valBadge: {
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 4,
    minWidth: 64,
    alignItems: 'center',
    backgroundColor: Colors.surfaceLifted,
  },
  valSteal: {
    backgroundColor: '#dcfce7',
    borderColor: '#bbf7d0',
    borderWidth: 0.5,
  },
  valStealText: {
    color: '#15803d',
    fontWeight: 'bold',
  },
  valReach: {
    backgroundColor: '#fee2e2',
    borderColor: '#fecaca',
    borderWidth: 0.5,
  },
  valReachText: {
    color: '#b91c1c',
    fontWeight: 'bold',
  },
  valBadgeText: {
    fontFamily: Fonts.stats,
    fontSize: 8,
    fontWeight: 'bold',
    color: Colors.secondaryAccent,
  },

  // Performance Tab styles
  perfContainer: {
    gap: Spacing.three,
  },
  telemetryCard: {
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 12,
    padding: Spacing.four,
    gap: Spacing.two,
    ...Colors.shadows,
  },
  telemetryCardTitle: {
    fontFamily: Fonts.headings,
    fontSize: 12,
    color: Colors.secondaryAccent,
    letterSpacing: 1,
  },
  telemetryStatsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 4,
  },
  telemetryStat: {
    flex: 1,
    backgroundColor: Colors.surfaceLifted,
    padding: 8,
    borderRadius: 8,
    alignItems: 'center',
    gap: 4,
  },
  telemetryStatLabel: {
    fontFamily: Fonts.stats,
    fontSize: 7,
    color: Colors.secondaryAccent,
    textAlign: 'center',
  },
  telemetryStatVal: {
    fontFamily: Fonts.stats,
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
  },
  perfSectionTitle: {
    fontFamily: Fonts.stats,
    fontSize: 10,
    color: Colors.secondaryAccent,
    letterSpacing: 1.5,
    marginTop: Spacing.two,
  },
  routineGrid: {
    flexDirection: 'row',
    gap: Spacing.two,
  },
  routineCard: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.coltsNavyLight,
    borderRadius: 12,
    padding: Spacing.three,
    gap: Spacing.one,
    ...Colors.shadows,
  },
  routineHeading: {
    fontFamily: Fonts.headings,
    fontSize: 11,
    color: Colors.primaryAccent,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  routineBullet: {
    fontFamily: Fonts.body,
    fontSize: 11,
    color: Colors.secondaryAccent,
    lineHeight: 15,
  },
  weeklyList: {
    gap: 6,
  },
  weeklyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: Spacing.two,
    gap: Spacing.two,
    height: 58, // Up-scaled touch target
  },
  weeklyRoundLabel: {
    width: 44,
    height: 32,
    borderRadius: 6,
    backgroundColor: Colors.surfaceLifted,
    justifyContent: 'center',
    alignItems: 'center',
  },
  weeklyRoundText: {
    fontFamily: Fonts.stats,
    fontSize: 9.5,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
  },
  weeklyRangeContainer: {
    flex: 1,
    justifyContent: 'center',
    gap: 2,
  },
  weeklyRangeLabelText: {
    fontFamily: Fonts.body,
    fontSize: 9,
    fontWeight: 'bold',
    color: '#94a3b8',
  },
  rangeBarBg: {
    height: 6,
    backgroundColor: Colors.surfaceLifted,
    borderRadius: 3,
    position: 'relative',
    overflow: 'visible',
    width: '90%',
  },
  rangeBarFill: {
    height: 6,
    backgroundColor: 'rgba(224, 49, 34, 0.15)',
    borderRadius: 3,
    position: 'absolute',
  },
  rangeDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.coltsNavy,
    position: 'absolute',
    top: -1,
  },
  weeklyScoreDetail: {
    fontFamily: Fonts.stats,
    fontSize: 7.5,
    color: Colors.secondaryAccent,
  },
  matchOutcomeBadge: {
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 4,
    minWidth: 64,
    alignItems: 'center',
  },
  matchWin: {
    backgroundColor: '#dcfce7',
  },
  matchLoss: {
    backgroundColor: '#fee2e2',
  },
  matchWinText: {
    fontFamily: Fonts.stats,
    fontSize: 8.5,
    fontWeight: 'bold',
    color: '#15803d',
  },
  matchLossText: {
    fontFamily: Fonts.stats,
    fontSize: 8.5,
    fontWeight: 'bold',
    color: '#b91c1c',
  },
  matchOutcomeText: {
    fontFamily: Fonts.stats,
    fontSize: 8.5,
    fontWeight: 'bold',
  },
  quarterGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.two,
  },
  quarterCard: {
    width: '48%',
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 12,
    padding: Spacing.three,
    gap: 3,
    ...Colors.shadows,
  },
  quarterTitle: {
    fontFamily: Fonts.headings,
    fontSize: 11,
    color: Colors.primaryAccent,
    fontWeight: 'bold',
  },
  quarterSubtitle: {
    fontFamily: Fonts.body,
    fontSize: 9,
    color: Colors.secondaryAccent,
    fontStyle: 'italic',
  },
  quarterStat: {
    fontFamily: Fonts.stats,
    fontSize: 8.5,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
    marginTop: 4,
  },
  quarterBody: {
    fontFamily: Fonts.body,
    fontSize: 10,
    color: Colors.secondaryAccent,
    lineHeight: 13,
    marginTop: 2,
  },

  // Leaderboard Lobby styles
  lobbyContainer: {
    gap: Spacing.three,
  },
  aiPanel: {
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 12,
    padding: Spacing.four,
    gap: Spacing.two,
    ...Colors.shadows,
  },
  aiPanelTitle: {
    fontFamily: Fonts.headings,
    fontSize: 11,
    color: Colors.primaryAccent,
    letterSpacing: 1,
  },
  chartWrapper: {
    height: 100,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 4,
  },
  aiProgressMetaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  aiProgressLabel: {
    fontFamily: Fonts.stats,
    fontSize: 7.5,
    color: Colors.secondaryAccent,
    letterSpacing: 0.5,
  },
  aiProgressVal: {
    fontFamily: Fonts.stats,
    fontSize: 12,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
  },
  aiProgressBarBg: {
    height: 8,
    backgroundColor: Colors.surfaceLifted,
    borderRadius: 4,
    overflow: 'hidden',
    marginTop: 2,
  },
  aiProgressBarFill: {
    height: 8,
    backgroundColor: Colors.coltsNavy,
    borderRadius: 4,
  },
  aiProgressExplanation: {
    fontFamily: Fonts.body,
    fontSize: 11,
    color: Colors.secondaryAccent,
    lineHeight: 14,
    opacity: 0.8,
  },
  aiActionRow: {
    flexDirection: 'row',
    gap: Spacing.two,
    marginTop: Spacing.two,
  },
  aiActionBtn: {
    flex: 1.2,
    backgroundColor: Colors.coltsNavy,
    borderColor: Colors.coltsNavy,
    borderWidth: 1.5,
    borderRadius: 8,
    paddingVertical: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  aiActionBtnText: {
    fontFamily: Fonts.headings,
    fontSize: 11,
    color: '#FFFFFF',
    fontWeight: 'bold',
    letterSpacing: 0.5,
  },
  aiClearBtn: {
    flex: 0.8,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    backgroundColor: 'transparent',
  },
  aiActionBtnTextClear: {
    fontFamily: Fonts.headings,
    fontSize: 11,
    color: '#ef4444',
    letterSpacing: 0.5,
  },
  lobbySectionTitle: {
    fontFamily: Fonts.stats,
    fontSize: 10,
    color: Colors.secondaryAccent,
    letterSpacing: 1.5,
    marginTop: Spacing.two,
  },
  tableContainer: {
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: Colors.surface,
    width: 530, // static width for horizontal scrolling
  },
  tableHeaderRow: {
    flexDirection: 'row',
    backgroundColor: Colors.surfaceLifted,
    borderBottomWidth: 1,
    borderBottomColor: Colors.coltsNavyLight,
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  tableHeaderCell: {
    fontFamily: Fonts.stats,
    fontSize: 8.5,
    fontWeight: '800',
    color: Colors.secondaryAccent,
    letterSpacing: 1.5,
  },
  tableRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 0.5,
    borderBottomColor: Colors.coltsNavyLight,
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  tableRowHuman: {
    backgroundColor: 'rgba(255, 205, 0, 0.12)',
    borderBottomColor: 'rgba(255, 205, 0, 0.25)',
    borderBottomWidth: 1,
  },
  tableCellText: {
    fontFamily: Fonts.body,
    fontSize: 11,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
  },
  tableCellHumanText: {
    color: Colors.primaryAccent,
    fontWeight: 'bold',
  },
  tableNameCell: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  cpuSubLabel: {
    fontFamily: Fonts.stats,
    fontSize: 7.5,
    color: Colors.secondaryAccent,
  },
  tableCell: {
    fontFamily: Fonts.body,
    fontSize: 10.5,
    color: Colors.secondaryAccent,
  },

  // Simulated draft overlay loader
  simulatingOverlay: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: isDark ? 'rgba(12, 12, 12, 0.95)' : 'rgba(248, 250, 252, 0.95)',
    zIndex: 999,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.three,
  },
  simulatingText: {
    fontFamily: Fonts.headings,
    fontSize: 15,
    color: Colors.primaryAccent,
    letterSpacing: 0.5,
  },
  overlayProgressBarBg: {
    width: 240,
    height: 8,
    backgroundColor: Colors.surfaceLifted,
    borderRadius: 4,
    overflow: 'hidden',
    marginTop: Spacing.one,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
  },
  overlayProgressBarFill: {
    height: '100%',
    backgroundColor: Colors.coltsNavy,
    borderRadius: 4,
  },
  greenProgressCircleBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 52,
    height: 52,
    borderRadius: 26,
    borderWidth: 2,
    borderColor: '#22c55e',
    backgroundColor: '#f0fdf4',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#22c55e',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 3,
  },
  greenProgressCircleBadgeActive: {
    borderColor: '#4ade80',
    backgroundColor: '#dcfce7',
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  greenProgressCircleBadgeText: {
    fontFamily: Fonts.stats,
    fontSize: 13,
    fontWeight: 'bold',
    color: '#15803d',
  },
  greenProgressCircleBadgeSubText: {
    fontFamily: Fonts.body,
    fontSize: 6.5,
    color: '#166534',
    fontWeight: 'bold',
    letterSpacing: 0.2,
    marginTop: -1,
  },
  exploreTooltip: {
    marginTop: Spacing.two,
    backgroundColor: Colors.surface,
    borderColor: Colors.coltsNavyLight,
    borderWidth: 1,
    borderRadius: 6,
    paddingVertical: 6,
    paddingHorizontal: 12,
    alignSelf: 'center',
    ...Colors.shadows,
  },
  exploreTooltipText: {
    fontFamily: Fonts.stats,
    fontSize: 9.5,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
    letterSpacing: 0.5,
  },

  // Bottom action buttons
  actionContainer: {
    gap: Spacing.two,
    marginTop: Spacing.two,
  },
  primaryBtn: {
    backgroundColor: Colors.coltsNavy,
    borderColor: Colors.coltsNavy,
    borderWidth: 1.5,
    borderRadius: 8,
    paddingVertical: 12,
    minHeight: 48,
    justifyContent: 'center',
    alignItems: 'center',
  },
  primaryBtnText: {
    fontFamily: Fonts.headings,
    fontSize: 14,
    color: '#FFFFFF',
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  secondaryBtn: {
    backgroundColor: 'transparent',
    borderColor: Colors.primaryAccent,
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 12,
    minHeight: 48,
    justifyContent: 'center',
    alignItems: 'center',
  },
  secondaryBtnText: {
    fontFamily: Fonts.headings,
    fontSize: 14,
    color: Colors.primaryAccent,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  btnPressed: {
    opacity: 0.85,
    transform: [{ scale: 0.98 }],
  },
  // Draft Board Styles
  boardSection: {
    padding: Spacing.three,
    backgroundColor: Colors.surface,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: Colors.coltsNavyLight,
    marginHorizontal: Spacing.three,
    marginTop: Spacing.two,
    marginBottom: Spacing.four,
    overflow: 'hidden',
    ...Colors.shadows,
  },
  boardHeaderCard: {
    marginBottom: Spacing.three,
  },
  boardHeaderTitle: {
    fontFamily: Fonts.headings,
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
    textTransform: 'uppercase',
  },
  boardHeaderSub: {
    fontFamily: Fonts.body,
    fontSize: 12,
    color: Colors.secondaryAccent,
    marginTop: Spacing.one,
    lineHeight: 16,
  },
  boardGridContainer: {
    flexDirection: 'column',
    alignItems: 'flex-start',
  },
  boardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.half,
  },
  boardRoundHeaderCell: {
    width: 60,
    justifyContent: 'center',
    alignItems: 'center',
    paddingRight: Spacing.one,
  },
  boardRoundHeaderText: {
    fontFamily: Fonts.headings,
    fontSize: 11,
    fontWeight: 'bold',
    color: Colors.secondaryAccent,
    textAlign: 'center',
  },
  boardTeamHeaderCell: {
    width: 120,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.surfaceLifted,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.coltsNavyLight,
    marginHorizontal: Spacing.half,
    paddingHorizontal: Spacing.one,
  },
  boardTeamHeaderCellUser: {
    borderColor: isDark ? Colors.secondaryAccent : Colors.coltsNavy,
    backgroundColor: 'rgba(224, 49, 34, 0.08)',
  },
  boardTeamHeaderText: {
    fontFamily: Fonts.headings,
    fontSize: 12,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
    textAlign: 'center',
  },
  boardTeamHeaderTextUser: {
    color: Colors.primaryAccent,
  },
  boardTeamSubText: {
    fontFamily: Fonts.stats,
    fontSize: 10,
    color: Colors.secondaryAccent,
    marginTop: Spacing.half,
  },
  boardRoundCell: {
    width: 60,
    justifyContent: 'center',
    alignItems: 'center',
    paddingRight: Spacing.one,
  },
  boardRoundCellText: {
    fontFamily: Fonts.stats,
    fontSize: 12,
    fontWeight: 'bold',
    color: Colors.primaryAccent,
    textAlign: 'center',
  },
  boardPlayerCell: {
    width: 120,
    height: 64,
    backgroundColor: Colors.surfaceLifted,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.coltsNavyLight,
    marginHorizontal: Spacing.half,
    padding: Spacing.one,
    justifyContent: 'space-between',
  },
  boardPlayerCellUser: {
    borderColor: 'rgba(255, 205, 0, 0.5)',
    backgroundColor: 'rgba(255, 205, 0, 0.08)',
  },
  boardCellTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  boardCellPosBadge: {
    paddingHorizontal: Spacing.one,
    paddingVertical: 1,
    borderRadius: 4,
  },
  boardCellPosText: {
    fontFamily: Fonts.headings,
    fontSize: 10,
    fontWeight: 'bold',
    color: '#000000',
  },
  boardCellPickNumber: {
    fontFamily: Fonts.stats,
    fontSize: 9,
    color: '#64748b',
  },
  boardCellName: {
    fontFamily: Fonts.body,
    fontSize: 11,
    fontWeight: '600',
    color: Colors.primaryAccent,
    marginTop: 2,
  },
  boardCellMeta: {
    fontFamily: Fonts.body,
    fontSize: 9,
    color: Colors.secondaryAccent,
    marginTop: 1,
  },
  boardPlayerCellEmpty: {
    width: 120,
    height: 64,
    backgroundColor: 'transparent',
    borderRadius: 8,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: Colors.coltsNavyLight,
    marginHorizontal: Spacing.half,
    justifyContent: 'center',
    alignItems: 'center',
  },
  boardPlayerTextEmpty: {
    color: '#64748b',
    fontSize: 16,
  },
});
}

const lightStyles = createStyles(LightColors);
const darkStyles = createStyles(DarkColors as any);
const styles = new Proxy({}, {
  get(target, prop) {
    const theme = useThemeStore.getState().theme;
    return theme === 'dark' ? darkStyles[prop as keyof typeof darkStyles] : lightStyles[prop as keyof typeof lightStyles];
  }
}) as ReturnType<typeof createStyles>;
